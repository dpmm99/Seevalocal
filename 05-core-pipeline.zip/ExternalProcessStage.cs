using System.Diagnostics;
using System.Text;
using System.Text.RegularExpressions;
using Microsoft.Extensions.Logging;
using Seevalocal.Core.Abstractions;
using Seevalocal.Core.Models;

namespace Seevalocal.Core.Stages;

/// <summary>
/// Runs an external program, captures stdout/stderr, and extracts named metrics.
/// Thread-safe: each ExecuteAsync call spawns its own process.
/// </summary>
public sealed class ExternalProcessStage : IEvalStage
{
    private readonly ILogger<ExternalProcessStage> _logger;

    public string StageName { get; init; } = "ExternalProcessStage";

    public string ExecutablePath { get; init; } = "";

    /// <summary>
    /// Arguments string. Supports {StageName.outputKey} placeholder substitution
    /// from prior stage outputs, plus {id} for the item ID.
    /// </summary>
    public string Arguments { get; init; } = "";

    public string? WorkingDirectoryPath { get; init; }
    public double TimeoutSeconds { get; init; } = 30.0;

    /// <summary>Patterns to extract named numeric metrics from stdout.</summary>
    public IReadOnlyList<MetricExtractorConfig> MetricExtractors { get; init; } = [];

    /// <summary>If true, a non-zero exit code is treated as a stage failure.</summary>
    public bool FailOnNonZeroExit { get; init; } = true;

    public ExternalProcessStage(ILogger<ExternalProcessStage> logger)
    {
        _logger = logger;
    }

    public async Task<StageResult> ExecuteAsync(EvalStageContext context)
    {
        var item = context.Item;
        var ct = context.CancellationToken;

        if (string.IsNullOrWhiteSpace(ExecutablePath))
            return StageResult.Failure($"[{StageName}] ExecutablePath is not configured");

        string resolvedArgs = SubstitutePlaceholders(Arguments, item.Id, context.StageOutputs);
        string? workingDir = WorkingDirectoryPath is not null
            ? Path.GetFullPath(SubstitutePlaceholders(WorkingDirectoryPath, item.Id, context.StageOutputs))
            : null;

        _logger.LogDebug("[{StageName}] Launching: {Executable} {Arguments}", StageName, ExecutablePath, resolvedArgs);

        var stdoutSb = new StringBuilder();
        var stderrSb = new StringBuilder();

        using var process = new Process();
        process.StartInfo = new ProcessStartInfo
        {
            FileName = ExecutablePath,
            Arguments = resolvedArgs,
            WorkingDirectory = workingDir,
            UseShellExecute = false,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            CreateNoWindow = true
        };

        process.OutputDataReceived += (_, e) =>
        {
            if (e.Data != null) stdoutSb.AppendLine(e.Data);
        };
        process.ErrorDataReceived += (_, e) =>
        {
            if (e.Data != null) stderrSb.AppendLine(e.Data);
        };

        var sw = Stopwatch.StartNew();

        try
        {
            process.Start();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "[{StageName}] Failed to start process for item {EvalItemId}", StageName, item.Id);
            return StageResult.Failure($"[{StageName}] Failed to start process: {ex.Message}");
        }

        process.BeginOutputReadLine();
        process.BeginErrorReadLine();

        using var timeoutCts = new CancellationTokenSource(TimeSpan.FromSeconds(TimeoutSeconds));
        using var linkedCts = CancellationTokenSource.CreateLinkedTokenSource(ct, timeoutCts.Token);

        try
        {
            await process.WaitForExitAsync(linkedCts.Token);
        }
        catch (OperationCanceledException) when (timeoutCts.IsCancellationRequested)
        {
            try { process.Kill(entireProcessTree: true); } catch { /* best effort */ }
            _logger.LogWarning("[{StageName}] Process timed out after {TimeoutSeconds}s for item {EvalItemId}",
                StageName, TimeoutSeconds, item.Id);
            return StageResult.Failure($"[{StageName}] Process timed out after {TimeoutSeconds}s");
        }

        sw.Stop();

        int exitCode = process.ExitCode;
        string stdout = stdoutSb.ToString();
        string stderr = stderrSb.ToString();

        _logger.LogDebug("[{StageName}] Process exited with code {ExitCode} in {DurationSeconds:F2}s for item {EvalItemId}",
            StageName, exitCode, sw.Elapsed.TotalSeconds, item.Id);

        var outputs = new Dictionary<string, object?>
        {
            [$"{StageName}.stdout"] = stdout,
            [$"{StageName}.stderr"] = stderr,
            [$"{StageName}.exitCode"] = exitCode
        };

        var metrics = new List<MetricValue>
        {
            MetricValue.FromInt("processExitCode", exitCode),
            MetricValue.FromDouble("processDurationSeconds", sw.Elapsed.TotalSeconds)
        };

        // Extract metrics from stdout
        foreach (var extractor in MetricExtractors)
        {
            var extracted = TryExtractMetric(extractor, stdout, item.Id);
            if (extracted is not null)
            {
                metrics.Add(extracted);
                outputs[$"{StageName}.{extractor.MetricName}"] = extracted.AsDouble() ?? (object?)extracted.StringValue;
            }
        }

        if (FailOnNonZeroExit && exitCode != 0)
        {
            _logger.LogWarning("[{StageName}] Non-zero exit code {ExitCode} for item {EvalItemId}",
                StageName, exitCode, item.Id);
            return new StageResult
            {
                Outputs = outputs,
                Metrics = metrics,
                Succeeded = false,
                FailureReason = $"[{StageName}] Process exited with code {exitCode}"
            };
        }

        return StageResult.Success(outputs, metrics);
    }

    private MetricValue? TryExtractMetric(MetricExtractorConfig extractor, string stdout, string evalItemId)
    {
        try
        {
            var match = Regex.Match(stdout, extractor.RegexPattern, RegexOptions.Multiline);
            if (!match.Success || !match.Groups["value"].Success)
            {
                _logger.LogWarning("[{StageName}] Metric extractor '{MetricName}' found no match in stdout for item {EvalItemId}",
                    StageName, extractor.MetricName, evalItemId);
                return null;
            }

            string raw = match.Groups["value"].Value;

            return extractor.Type switch
            {
                MetricType.Double when double.TryParse(raw, System.Globalization.NumberStyles.Any,
                    System.Globalization.CultureInfo.InvariantCulture, out double d)
                    => MetricValue.FromDouble(extractor.MetricName, d),

                MetricType.Int when int.TryParse(raw, out int i)
                    => MetricValue.FromInt(extractor.MetricName, i),

                MetricType.Bool when bool.TryParse(raw, out bool b)
                    => MetricValue.FromBool(extractor.MetricName, b),

                MetricType.String
                    => MetricValue.FromString(extractor.MetricName, raw),

                _ => null
            };
        }
        catch (RegexException ex)
        {
            _logger.LogError(ex, "[{StageName}] Invalid regex pattern for metric '{MetricName}'",
                StageName, extractor.MetricName);
            return null;
        }
    }

    private static string SubstitutePlaceholders(
        string template,
        string itemId,
        IReadOnlyDictionary<string, object?> stageOutputs)
    {
        var result = template.Replace("{id}", itemId, StringComparison.OrdinalIgnoreCase);

        // Replace {StageName.outputKey} placeholders
        return Regex.Replace(result, @"\{([^}]+)\}", m =>
        {
            var key = m.Groups[1].Value;
            if (stageOutputs.TryGetValue(key, out var val) && val is not null)
                return val.ToString() ?? "";
            return m.Value; // leave unreplaced if not found
        });
    }
}

/// <summary>
/// Configuration for extracting a named metric from process stdout using a regex.
/// </summary>
public record MetricExtractorConfig
{
    /// <summary>Metric name. Must include unit suffix per conventions (e.g., "testPassCount").</summary>
    public string MetricName { get; init; } = "";

    /// <summary>Regex pattern with a named capture group "value".</summary>
    public string RegexPattern { get; init; } = "";

    public MetricType Type { get; init; } = MetricType.Double;
}
