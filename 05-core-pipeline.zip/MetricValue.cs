namespace Seevalocal.Core.Models;

/// <summary>
/// The type of a metric value.
/// </summary>
public enum MetricType
{
    Double,
    Int,
    Bool,
    String
}

/// <summary>
/// A typed, named measurement emitted by a pipeline stage.
/// RULE: Name MUST end with a unit suffix (Seconds, Count, Bytes, Ratio, Percent, etc.).
/// See 00-conventions.md §2.1 for the full list.
/// </summary>
public record MetricValue
{
    /// <summary>
    /// Name of the metric. Must include a unit suffix per conventions.
    /// Examples: "llmLatencySeconds", "promptTokenCount", "exactMatch"
    /// </summary>
    public required string Name { get; init; }

    public MetricType Type { get; init; }

    public double? DoubleValue { get; init; }
    public int? IntValue { get; init; }
    public bool? BoolValue { get; init; }
    public string? StringValue { get; init; }

    public static MetricValue FromDouble(string name, double value) =>
        new() { Name = name, Type = MetricType.Double, DoubleValue = value };

    public static MetricValue FromInt(string name, int value) =>
        new() { Name = name, Type = MetricType.Int, IntValue = value };

    public static MetricValue FromBool(string name, bool value) =>
        new() { Name = name, Type = MetricType.Bool, BoolValue = value, IntValue = value ? 1 : 0 };

    public static MetricValue FromString(string name, string value) =>
        new() { Name = name, Type = MetricType.String, StringValue = value };

    /// <summary>Returns the value as a double for aggregation purposes.</summary>
    public double? AsDouble() => Type switch
    {
        MetricType.Double => DoubleValue,
        MetricType.Int => IntValue.HasValue ? (double)IntValue.Value : null,
        MetricType.Bool => BoolValue.HasValue ? (BoolValue.Value ? 1.0 : 0.0) : null,
        _ => null
    };

    public override string ToString() => Type switch
    {
        MetricType.Double => $"{Name}={DoubleValue:G}",
        MetricType.Int => $"{Name}={IntValue}",
        MetricType.Bool => $"{Name}={BoolValue}",
        MetricType.String => $"{Name}={StringValue}",
        _ => $"{Name}=?"
    };
}
