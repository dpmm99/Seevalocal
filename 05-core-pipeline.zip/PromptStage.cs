using System.Diagnostics;
using Microsoft.Extensions.Logging;
using Seevalocal.Core.Abstractions;
using Seevalocal.Core.Models;
using Seevalocal.Server.Models;

namespace Seevalocal.Core.Stages;

/// <summary>
/// Sends the item's SystemPrompt + UserPrompt to the primary LLM endpoint
/// and captures the response and timing metrics.
/// Thread-safe: all mutable state is passed via EvalStageContext.
/// </summary>
public sealed class PromptStage : IEvalStage
{
    private readonly ILogger<PromptStage> _logger;

    public string StageName => "PromptStage";

    /// <summary>Maximum number of completion tokens to request. Null = server default.</summary>
    public int? MaxTokens { get; init; }

    /// <summary>Stop sequences to pass to the model.</summary>
    public IReadOnlyList<string> StopSequences { get; init; } = [];

    public PromptStage(ILogger<PromptStage> logger)
    {
        _logger = logger;
    }

    public async Task<StageResult> ExecuteAsync(EvalStageContext context)
    {
        var item = context.Item;
        var ct = context.CancellationToken;

        var messages = BuildMessages(item);

        var request = new ChatCompletionRequest
        {
            Model = "",   // llama-server uses the loaded model; field may be empty
            Messages = messages,
            MaxTokens = MaxTokens,
            Stop = StopSequences.Count > 0 ? StopSequences : null
        };

        _logger.LogDebug("[PromptStage] Sending request for item {EvalItemId}", item.Id);

        var sw = Stopwatch.StartNew();
        var result = await context.PrimaryClient.ChatCompletionAsync(request, ct);
        sw.Stop();

        if (result.IsFailed)
        {
            var errorMsg = string.Join("; ", result.Errors.Select(e => e.Message));
            _logger.LogError("[PromptStage] Request failed for item {EvalItemId}: {Error}", item.Id, errorMsg);
            return StageResult.Failure($"[PromptStage] LLM request failed: {errorMsg}");
        }

        var response = result.Value;
        var responseText = response.Choices.FirstOrDefault()?.Message?.Content ?? "";

        var outputs = new Dictionary<string, object?>
        {
            ["PromptStage.response"] = responseText,
            ["PromptStage.rawResponse"] = response
        };

        var metrics = BuildMetrics(response, sw.Elapsed.TotalSeconds);

        _logger.LogDebug(
            "[PromptStage] Item {EvalItemId} completed: promptTokens={PromptTokenCount}, completionTokens={CompletionTokenCount}, latency={LatencySeconds:F3}s",
            item.Id,
            response.Usage?.PromptTokens ?? 0,
            response.Usage?.CompletionTokens ?? 0,
            sw.Elapsed.TotalSeconds);

        return StageResult.Success(outputs, metrics);
    }

    private static IReadOnlyList<ChatMessage> BuildMessages(EvalItem item)
    {
        var messages = new List<ChatMessage>();

        if (item.SystemPrompt is not null)
            messages.Add(new ChatMessage { Role = "system", Content = item.SystemPrompt });

        messages.Add(new ChatMessage { Role = "user", Content = item.UserPrompt });

        return messages;
    }

    private static IReadOnlyList<MetricValue> BuildMetrics(ChatCompletionResponse response, double wallClockSeconds)
    {
        var metrics = new List<MetricValue>();

        int promptTokenCount = response.Usage?.PromptTokens ?? 0;
        int completionTokenCount = response.Usage?.CompletionTokens ?? 0;
        int totalTokenCount = response.Usage?.TotalTokens ?? (promptTokenCount + completionTokenCount);

        metrics.Add(MetricValue.FromInt("promptTokenCount", promptTokenCount));
        metrics.Add(MetricValue.FromInt("completionTokenCount", completionTokenCount));
        metrics.Add(MetricValue.FromInt("totalTokenCount", totalTokenCount));

        // Prefer server-reported timing if available; fall back to wall-clock
        double latencySeconds = response.Timings is not null
            ? (response.Timings.PromptMs + response.Timings.PredictedMs) / 1000.0
            : wallClockSeconds;

        metrics.Add(MetricValue.FromDouble("llmLatencySeconds", latencySeconds));

        if (latencySeconds > 0)
        {
            double promptTps = promptTokenCount > 0
                ? promptTokenCount / (response.Timings?.PromptMs / 1000.0 ?? latencySeconds)
                : 0.0;

            double completionTps = completionTokenCount > 0 && response.Timings is not null
                ? completionTokenCount / (response.Timings.PredictedMs / 1000.0)
                : completionTokenCount > 0
                    ? completionTokenCount / latencySeconds
                    : 0.0;

            metrics.Add(MetricValue.FromDouble("promptTokensPerSecond", promptTps));
            metrics.Add(MetricValue.FromDouble("completionTokensPerSecond", completionTps));
        }

        return metrics;
    }
}
