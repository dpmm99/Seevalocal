using Microsoft.Extensions.Logging.Abstractions;
using Seevalocal.Core.Abstractions;
using Seevalocal.Core.Models;
using Seevalocal.Pipelines;
using Xunit;

namespace Seevalocal.Core.Tests;

public class PipelineOrchestratorTests
{
    private static EvalPipeline MakePipeline(params IEvalStage[] stages) =>
        new(NullLogger<EvalPipeline>.Instance)
        {
            PipelineName = "TestPipeline",
            Stages = stages
        };

    private static PipelineOrchestrator MakeOrchestrator(
        IEnumerable<EvalItem> items,
        EvalPipeline pipeline,
        IResultCollector collector,
        IProgress<EvalProgress>? progress = null)
    {
        var serverInfo = new Seevalocal.Server.Models.ServerInfo
        {
            BaseUrl = "http://localhost:8080",
            TotalSlots = 4
        };
        var primaryClient = new Seevalocal.Server.Client.LlamaServerClient(
            serverInfo,
            new HttpClient(),
            NullLogger<Seevalocal.Server.Client.LlamaServerClient>.Instance);

        return new PipelineOrchestrator(
            dataSource: new ListDataSource(items),
            pipeline: pipeline,
            evalSetConfig: new Seevalocal.Config.Models.EvalSetConfig { Id = "test-set" },
            resolvedConfig: TestHelpers.DefaultConfig(),
            primaryClient: primaryClient,
            judgeClient: null,
            resultCollector: collector,
            progress: progress ?? new NoOpProgress(),
            logger: NullLogger<PipelineOrchestrator>.Instance);
    }

    [Fact]
    public async Task RunAsync_AllItemsProcessed()
    {
        var items = Enumerable.Range(1, 10)
            .Select(i => TestHelpers.MakeItem($"item-{i:D6}", $"Prompt {i}"))
            .ToList();

        var collector = new CapturingResultCollector();
        var pipeline = MakePipeline(new SucceedingStage());
        var orchestrator = MakeOrchestrator(items, pipeline, collector);

        await orchestrator.RunAsync(maxConcurrentCount: 3, ct: CancellationToken.None);

        Assert.Equal(10, collector.GetResults().Count);
    }

    [Fact]
    public async Task RunAsync_ConcurrencyLimitRespected()
    {
        int maxObserved = 0;
        int current = 0;
        var lockObj = new object();

        var items = Enumerable.Range(1, 20)
            .Select(i => TestHelpers.MakeItem($"item-{i:D6}", $"Prompt {i}"))
            .ToList();

        var trackingStage = new TrackingConcurrencyStage(() =>
        {
            lock (lockObj)
            {
                current++;
                if (current > maxObserved) maxObserved = current;
            }
        }, () =>
        {
            lock (lockObj) { current--; }
        });

        var collector = new CapturingResultCollector();
        var pipeline = MakePipeline(trackingStage);
        var orchestrator = MakeOrchestrator(items, pipeline, collector);

        await orchestrator.RunAsync(maxConcurrentCount: 4, ct: CancellationToken.None);

        Assert.True(maxObserved <= 4, $"Max concurrent was {maxObserved}, expected ≤ 4");
        Assert.Equal(20, collector.GetResults().Count);
    }

    [Fact]
    public async Task RunAsync_CancellationMidRun_StopsGracefully()
    {
        using var cts = new CancellationTokenSource();

        var items = Enumerable.Range(1, 100)
            .Select(i => TestHelpers.MakeItem($"item-{i:D6}", $"Prompt {i}"))
            .ToList();

        int processedCount = 0;
        var slowStage = new SlowStage(delayMs: 20, onExecute: () => Interlocked.Increment(ref processedCount));

        var collector = new CapturingResultCollector();
        var pipeline = MakePipeline(slowStage);
        var orchestrator = MakeOrchestrator(items, pipeline, collector);

        // Cancel after a short delay
        _ = Task.Run(async () =>
        {
            await Task.Delay(50);
            cts.Cancel();
        });

        await Assert.ThrowsAnyAsync<OperationCanceledException>(() =>
            orchestrator.RunAsync(maxConcurrentCount: 2, ct: cts.Token));

        // Some items should have been processed before cancellation
        Assert.True(processedCount < 100, "Expected cancellation to stop before all 100 items");
    }

    [Fact]
    public async Task RunAsync_ProgressReported()
    {
        var progressReports = new List<EvalProgress>();
        var progress = new DelegatingProgress<EvalProgress>(p => progressReports.Add(p));

        var items = Enumerable.Range(1, 5)
            .Select(i => TestHelpers.MakeItem($"item-{i:D6}", $"Prompt {i}"))
            .ToList();

        var collector = new CapturingResultCollector();
        var pipeline = MakePipeline(new SucceedingStage());
        var orchestrator = MakeOrchestrator(items, pipeline, collector, progress);

        await orchestrator.RunAsync(maxConcurrentCount: 2, ct: CancellationToken.None);

        Assert.Equal(5, progressReports.Count);
        Assert.All(progressReports, p => Assert.True(p.CompletedCount > 0));
    }

    // ── Test stage helpers ────────────────────────────────────────────────────

    private sealed class TrackingConcurrencyStage : IEvalStage
    {
        private readonly Action _onEnter;
        private readonly Action _onExit;
        public string StageName => "TrackingStage";

        public TrackingConcurrencyStage(Action onEnter, Action onExit)
        {
            _onEnter = onEnter;
            _onExit = onExit;
        }

        public async Task<StageResult> ExecuteAsync(EvalStageContext context)
        {
            _onEnter();
            try
            {
                await Task.Delay(10, context.CancellationToken);
                return StageResult.Success(new Dictionary<string, object?>(), []);
            }
            finally
            {
                _onExit();
            }
        }
    }

    private sealed class SlowStage : IEvalStage
    {
        private readonly int _delayMs;
        private readonly Action _onExecute;
        public string StageName => "SlowStage";

        public SlowStage(int delayMs, Action onExecute)
        {
            _delayMs = delayMs;
            _onExecute = onExecute;
        }

        public async Task<StageResult> ExecuteAsync(EvalStageContext context)
        {
            _onExecute();
            await Task.Delay(_delayMs, context.CancellationToken);
            return StageResult.Success(new Dictionary<string, object?>(), []);
        }
    }

    private sealed class NoOpProgress : IProgress<EvalProgress>
    {
        public void Report(EvalProgress value) { }
    }

    private sealed class DelegatingProgress<T> : IProgress<T>
    {
        private readonly Action<T> _handler;
        public DelegatingProgress(Action<T> handler) => _handler = handler;
        public void Report(T value) => _handler(value);
    }
}
