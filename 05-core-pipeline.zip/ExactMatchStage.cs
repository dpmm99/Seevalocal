using Microsoft.Extensions.Logging;
using Seevalocal.Core.Abstractions;
using Seevalocal.Core.Models;

namespace Seevalocal.Core.Stages;

/// <summary>
/// Compares the LLM response to EvalItem.ExpectedOutput.
/// Emits a boolean metric "exactMatch" (stored as 0/1).
/// Thread-safe.
/// </summary>
public sealed class ExactMatchStage : IEvalStage
{
    private readonly ILogger<ExactMatchStage> _logger;

    public string StageName => "ExactMatchStage";

    public bool CaseSensitive { get; init; } = false;
    public bool TrimWhitespace { get; init; } = true;

    /// <summary>
    /// Key in StageOutputs to read the model response from.
    /// Defaults to PromptStage output.
    /// </summary>
    public string InputStageOutputKey { get; init; } = "PromptStage.response";

    public ExactMatchStage(ILogger<ExactMatchStage> logger)
    {
        _logger = logger;
    }

    public Task<StageResult> ExecuteAsync(EvalStageContext context)
    {
        var item = context.Item;

        if (item.ExpectedOutput is null)
        {
            _logger.LogWarning("[ExactMatchStage] Item {EvalItemId} has no ExpectedOutput; skipping match", item.Id);
            return Task.FromResult(StageResult.Success(
                new Dictionary<string, object?>(),
                [MetricValue.FromBool("exactMatch", false)]));
        }

        if (!context.StageOutputs.TryGetValue(InputStageOutputKey, out var rawActual)
            || rawActual is not string actualOutput)
        {
            _logger.LogWarning(
                "[ExactMatchStage] Stage output key '{Key}' not found or not a string for item {EvalItemId}",
                InputStageOutputKey, item.Id);
            return Task.FromResult(StageResult.Failure(
                $"[ExactMatchStage] Stage output '{InputStageOutputKey}' not available or not a string"));
        }

        string expected = item.ExpectedOutput;
        string actual = actualOutput;

        if (TrimWhitespace)
        {
            expected = expected.Trim();
            actual = actual.Trim();
        }

        var comparison = CaseSensitive
            ? StringComparison.Ordinal
            : StringComparison.OrdinalIgnoreCase;

        bool isMatch = string.Equals(expected, actual, comparison);

        _logger.LogDebug("[ExactMatchStage] Item {EvalItemId}: exactMatch={IsMatch}", item.Id, isMatch);

        return Task.FromResult(StageResult.Success(
            new Dictionary<string, object?> { ["ExactMatchStage.isMatch"] = isMatch },
            [MetricValue.FromBool("exactMatch", isMatch)]));
    }
}
