// ─────────────────────────────────────────────────────────────────────────────
// Stub declarations for types that originate in other Seevalocal projects.
// Seevalocal.Core.Abstractions references these types so they must exist at
// compile time. In the full solution these come from the real projects via
// project references; here they are defined as minimal stubs so Core compiles
// standalone during development.
//
// DO NOT add business logic here. Replace with real project references once
// those parts are implemented.
// ─────────────────────────────────────────────────────────────────────────────

// ── Seevalocal.Config.Models stubs ──────────────────────────────────────────
namespace Seevalocal.Config.Models;

using FluentResults;

public record ResolvedConfig
{
    public RunConfig Run { get; init; } = new();
    public IReadOnlyList<EvalSetConfig> EvalSets { get; init; } = [];
    public OutputConfig Output { get; init; } = new();
}

public record RunConfig
{
    public bool ContinueOnEvalFailure { get; init; } = true;
    public int? MaxConcurrentEvals { get; init; }
}

public record EvalSetConfig
{
    public string Id { get; init; } = "";
    public string PipelineName { get; init; } = "";
    public DataSourceConfig DataSource { get; init; } = new();
}

public record DataSourceConfig
{
    public string Kind { get; init; } = "";
    public string? Path { get; init; }
}

public record OutputConfig
{
    public bool WritePerEvalJson { get; init; } = true;
    public bool WriteSummaryJson { get; init; } = true;
    public bool WriteSummaryCsv { get; init; } = true;
    public bool WriteResultsParquet { get; init; } = false;
    public bool IncludeRawLlmResponse { get; init; } = true;
    public bool IncludeAllStageOutputs { get; init; } = false;
}

public record ValidationError(string Field, string MessageText);
public enum ShellTarget { Bash, PowerShell }


// ── Seevalocal.Server.Models / Client stubs ──────────────────────────────────
namespace Seevalocal.Server.Models;

public record ServerInfo
{
    public required string BaseUrl { get; init; }
    public string? ApiKey { get; init; }
    public int TotalSlots { get; init; }
    public string ModelAlias { get; init; } = "";
}

public record ChatCompletionRequest
{
    public string Model { get; init; } = "";
    public IReadOnlyList<ChatMessage> Messages { get; init; } = [];
    public int? MaxTokens { get; init; }
    public IReadOnlyList<string>? Stop { get; init; }
    public double? Temperature { get; init; }
}

public record ChatCompletionResponse
{
    public string Id { get; init; } = "";
    public IReadOnlyList<ChatChoice> Choices { get; init; } = [];
    public ChatUsage? Usage { get; init; }
    public ChatTimings? Timings { get; init; }
}

public record ChatChoice
{
    public ChatMessage Message { get; init; } = new();
    public string? FinishReason { get; init; }
}

public record ChatMessage
{
    public string Role { get; init; } = "";
    public string? Content { get; init; }
}

public record ChatUsage
{
    public int PromptTokens { get; init; }
    public int CompletionTokens { get; init; }
    public int TotalTokens { get; init; }
}

public record ChatTimings
{
    public double PromptMs { get; init; }
    public double PredictedMs { get; init; }
    public double PromptPerTokenMs { get; init; }
    public double PredictedPerTokenMs { get; init; }
}

public enum GpuKind { Cuda, Vulkan, Metal, CpuOnly }

public record ServerProps
{
    public int TotalSlots { get; init; }
}

public record HealthStatus
{
    public bool IsHealthy { get; init; }
    public string Status { get; init; } = "";
}

public record TokenizeResponse
{
    public IReadOnlyList<int> Tokens { get; init; } = [];
    public int TokenCount { get; init; }
}

namespace Seevalocal.Server.Client;

using FluentResults;
using Microsoft.Extensions.Logging;
using Seevalocal.Server.Models;

/// <summary>
/// Pre-configured HTTP client for a llama-server instance.
/// Constructed from a ServerInfo. Thread-safe; share one instance per endpoint.
/// This stub is replaced by the real implementation from Seevalocal.Server.
/// </summary>
public sealed class LlamaServerClient
{
    private readonly ServerInfo _serverInfo;
    private readonly HttpClient _httpClient;
    private readonly ILogger<LlamaServerClient> _logger;

    public LlamaServerClient(ServerInfo serverInfo, HttpClient httpClient, ILogger<LlamaServerClient> logger)
    {
        _serverInfo = serverInfo;
        _httpClient = httpClient;
        _logger = logger;
    }

    public string BaseUrl => _serverInfo.BaseUrl;

    public Task<Result<ChatCompletionResponse>> ChatCompletionAsync(
        ChatCompletionRequest request, CancellationToken ct) =>
        throw new NotImplementedException("Stub: implement in Seevalocal.Server");

    public Task<Result<ServerProps>> GetPropsAsync(CancellationToken ct) =>
        throw new NotImplementedException("Stub: implement in Seevalocal.Server");

    public Task<Result<HealthStatus>> GetHealthAsync(CancellationToken ct) =>
        throw new NotImplementedException("Stub: implement in Seevalocal.Server");

    public Task<Result<TokenizeResponse>> TokenizeAsync(string content, bool addSpecial, CancellationToken ct) =>
        throw new NotImplementedException("Stub: implement in Seevalocal.Server");
}


// ── Seevalocal.DataSources stub ──────────────────────────────────────────────
namespace Seevalocal.DataSources;

using Seevalocal.Core.Models;

public interface IDataSource
{
    string Name { get; }
    IAsyncEnumerable<EvalItem> GetItemsAsync(CancellationToken ct);
    Task<int?> GetCountAsync(CancellationToken ct);
}
