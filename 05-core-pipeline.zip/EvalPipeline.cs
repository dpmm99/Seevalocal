using System.Diagnostics;
using Microsoft.Extensions.Logging;
using Seevalocal.Core.Abstractions;
using Seevalocal.Core.Models;

namespace Seevalocal.Pipelines;

/// <summary>
/// An ordered list of stages that are executed sequentially for each EvalItem.
/// The pipeline itself is stateless and thread-safe; state is carried in EvalStageContext.
/// </summary>
public sealed class EvalPipeline
{
    private readonly ILogger<EvalPipeline> _logger;

    public string PipelineName { get; init; } = "";
    public IReadOnlyList<IEvalStage> Stages { get; init; } = [];

    public EvalPipeline(ILogger<EvalPipeline> logger)
    {
        _logger = logger;
    }

    /// <summary>
    /// Run all stages for a single item. Stages execute sequentially.
    /// If a stage fails and continueOnStageFailure is false, remaining stages are skipped.
    /// Returns a complete EvalResult regardless of success/failure. Never throws.
    /// </summary>
    public async Task<EvalResult> RunItemAsync(
        EvalStageContext context,
        bool continueOnStageFailure,
        string evalSetId)
    {
        var startedAt = DateTimeOffset.UtcNow;
        var sw = Stopwatch.StartNew();

        var allOutputs = new Dictionary<string, object?>();
        var allMetrics = new List<MetricValue>();
        bool overallSucceeded = true;
        string? firstFailureReason = null;

        _logger.LogDebug("Pipeline {PipelineName} starting for item {EvalItemId}",
            PipelineName, context.Item.Id);

        foreach (var stage in Stages)
        {
            if (!overallSucceeded && !continueOnStageFailure)
            {
                _logger.LogDebug("Skipping stage {StageName} for item {EvalItemId} due to prior failure",
                    stage.StageName, context.Item.Id);
                continue;
            }

            // Build updated context with accumulated outputs
            var stageContext = context with { StageOutputs = allOutputs };

            StageResult stageResult;
            try
            {
                _logger.LogDebug("Executing stage {StageName} for item {EvalItemId}",
                    stage.StageName, context.Item.Id);

                stageResult = await stage.ExecuteAsync(stageContext);
            }
            catch (OperationCanceledException)
            {
                _logger.LogInformation("Stage {StageName} cancelled for item {EvalItemId}",
                    stage.StageName, context.Item.Id);
                throw; // propagate cancellation
            }
#pragma warning disable CA1031 // catch all to ensure EvalResult is always returned
            catch (Exception ex)
            {
                _logger.LogError(ex, "[{StageName}] Unhandled exception for item {EvalItemId}",
                    stage.StageName, context.Item.Id);
                stageResult = StageResult.Failure(
                    $"[{stage.StageName}] Unhandled exception: {ex.Message}");
            }
#pragma warning restore CA1031

            // Merge outputs
            foreach (var (key, value) in stageResult.Outputs)
                allOutputs[key] = value;

            allMetrics.AddRange(stageResult.Metrics);

            if (!stageResult.Succeeded)
            {
                overallSucceeded = false;
                firstFailureReason ??= stageResult.FailureReason;

                _logger.LogWarning("Stage {StageName} failed for item {EvalItemId}: {FailureReason}",
                    stage.StageName, context.Item.Id, stageResult.FailureReason);
            }
        }

        sw.Stop();

        // Extract raw LLM response from PromptStage output if present
        allOutputs.TryGetValue("PromptStage.response", out var rawResponse);

        var result = new EvalResult
        {
            EvalItemId = context.Item.Id,
            EvalSetId = evalSetId,
            Succeeded = overallSucceeded,
            FailureReason = firstFailureReason,
            Metrics = allMetrics,
            AllStageOutputs = allOutputs,
            StartedAt = startedAt,
            DurationSeconds = sw.Elapsed.TotalSeconds,
            RawLlmResponse = rawResponse as string
        };

        _logger.LogDebug("Pipeline {PipelineName} completed for item {EvalItemId} in {DurationSeconds:F2}s — Succeeded={Succeeded}",
            PipelineName, context.Item.Id, result.DurationSeconds, result.Succeeded);

        return result;
    }
}
