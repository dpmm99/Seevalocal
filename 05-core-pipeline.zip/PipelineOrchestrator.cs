using System.Diagnostics;
using System.Threading.Channels;
using Microsoft.Extensions.Logging;
using Polly;
using Polly.Retry;
using Seevalocal.Config.Models;
using Seevalocal.Core.Abstractions;
using Seevalocal.Core.Models;
using Seevalocal.DataSources;
using Seevalocal.Server.Client;

namespace Seevalocal.Pipelines;

/// <summary>
/// Orchestrates the evaluation of all items in a dataset.
/// Manages concurrency, retry, progress reporting, and result collection.
/// </summary>
public sealed class PipelineOrchestrator
{
    private readonly IDataSource _dataSource;
    private readonly EvalPipeline _pipeline;
    private readonly EvalSetConfig _evalSetConfig;
    private readonly ResolvedConfig _resolvedConfig;
    private readonly LlamaServerClient _primaryClient;
    private readonly LlamaServerClient? _judgeClient;
    private readonly IResultCollector _resultCollector;
    private readonly IProgress<EvalProgress> _progress;
    private readonly ILogger<PipelineOrchestrator> _logger;

    public PipelineOrchestrator(
        IDataSource dataSource,
        EvalPipeline pipeline,
        EvalSetConfig evalSetConfig,
        ResolvedConfig resolvedConfig,
        LlamaServerClient primaryClient,
        LlamaServerClient? judgeClient,
        IResultCollector resultCollector,
        IProgress<EvalProgress> progress,
        ILogger<PipelineOrchestrator> logger)
    {
        _dataSource = dataSource;
        _pipeline = pipeline;
        _evalSetConfig = evalSetConfig;
        _resolvedConfig = resolvedConfig;
        _primaryClient = primaryClient;
        _judgeClient = judgeClient;
        _resultCollector = resultCollector;
        _progress = progress;
        _logger = logger;
    }

    /// <summary>
    /// Run all items concurrently, up to maxConcurrentCount.
    /// Returns when all items are complete or cancellation is requested.
    /// </summary>
    public async Task RunAsync(int maxConcurrentCount, CancellationToken ct)
    {
        var runSw = Stopwatch.StartNew();

        int? totalCount = await _dataSource.GetCountAsync(ct);
        int completedCount = 0;

        _logger.LogInformation(
            "Orchestrator starting: EvalSet={EvalSetId}, Pipeline={PipelineName}, MaxConcurrent={MaxConcurrentCount}, TotalItems={TotalCount}",
            _evalSetConfig.Id, _pipeline.PipelineName, maxConcurrentCount, totalCount?.ToString() ?? "unknown");

        var channel = Channel.CreateUnbounded<EvalItem>(new UnboundedChannelOptions
        {
            SingleReader = false,
            SingleWriter = true,
            AllowSynchronousContinuations = false
        });

        // Producer: write all items from the data source to the channel
        var producerTask = Task.Run(async () =>
        {
            try
            {
                await foreach (var item in _dataSource.GetItemsAsync(ct))
                {
                    await channel.Writer.WriteAsync(item, ct);
                    _logger.LogTrace("Queued item {EvalItemId}", item.Id);
                }
                channel.Writer.Complete();
                _logger.LogDebug("Producer finished writing all items to channel");
            }
            catch (OperationCanceledException)
            {
                channel.Writer.Complete();
                _logger.LogInformation("Producer cancelled");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Producer encountered an error");
                channel.Writer.Complete(ex);
            }
        }, ct);

        // Consumers: limited by semaphore
        var semaphore = new SemaphoreSlim(maxConcurrentCount, maxConcurrentCount);

        var consumerTasks = Enumerable
            .Range(0, maxConcurrentCount)
            .Select(_ => ConsumeAsync(channel.Reader, semaphore, totalCount, ref completedCount, runSw, ct))
            .ToArray();

        await Task.WhenAll([producerTask, .. consumerTasks]);

        runSw.Stop();
        _logger.LogInformation(
            "Orchestrator finished: EvalSet={EvalSetId}, Completed={CompletedCount}, Elapsed={ElapsedSeconds:F2}s",
            _evalSetConfig.Id, completedCount, runSw.Elapsed.TotalSeconds);
    }

    private async Task ConsumeAsync(
        ChannelReader<EvalItem> reader,
        SemaphoreSlim semaphore,
        int? totalCount,
        ref int completedCount,
        Stopwatch runSw,
        CancellationToken ct)
    {
        await foreach (var item in reader.ReadAllAsync(ct))
        {
            await semaphore.WaitAsync(ct);
            try
            {
                var result = await RunItemWithRetryAsync(item, ct);

                await _resultCollector.CollectAsync(result, ct);

                int completed = Interlocked.Increment(ref completedCount);
                double elapsed = runSw.Elapsed.TotalSeconds;

                double? estimatedRemaining = null;
                if (totalCount.HasValue && totalCount.Value > 0 && completed > 0)
                {
                    double rate = completed / elapsed;
                    int remaining = totalCount.Value - completed;
                    estimatedRemaining = remaining > 0 ? remaining / rate : 0.0;
                }

                _progress.Report(new EvalProgress
                {
                    EvalItemId = item.Id,
                    Succeeded = result.Succeeded,
                    CompletedCount = completed,
                    TotalCount = totalCount ?? -1,
                    ElapsedSeconds = elapsed,
                    EstimatedRemainingSeconds = estimatedRemaining
                });
            }
            finally
            {
                semaphore.Release();
            }
        }
    }

    private async Task<EvalResult> RunItemWithRetryAsync(EvalItem item, CancellationToken ct)
    {
        var retryConfig = _resolvedConfig.Run is RunConfig run
            ? new RetryConfig
            {
                MaxRetryCount = 2,
                InitialDelaySeconds = 1.0,
                BackoffMultiplier = 2.0
            }
            : new RetryConfig();

        int attempt = 0;
        double delaySeconds = retryConfig.InitialDelaySeconds;

        while (true)
        {
            var context = new EvalStageContext
            {
                Item = item,
                Config = _resolvedConfig,
                PrimaryClient = _primaryClient,
                JudgeClient = _judgeClient,
                CancellationToken = ct
            };

            EvalResult result = await _pipeline.RunItemAsync(
                context,
                _resolvedConfig.Run.ContinueOnEvalFailure,
                _evalSetConfig.Id);

            // Only retry transient failures (not logic/scoring failures)
            if (result.Succeeded || !IsTransientFailure(result) || attempt >= retryConfig.MaxRetryCount)
                return result;

            attempt++;
            _logger.LogWarning(
                "Item {EvalItemId} failed transiently (attempt {Attempt}/{MaxRetry}): {Reason}. Retrying in {DelaySeconds:F1}s",
                item.Id, attempt, retryConfig.MaxRetryCount, result.FailureReason, delaySeconds);

            await Task.Delay(TimeSpan.FromSeconds(delaySeconds), ct);
            delaySeconds *= retryConfig.BackoffMultiplier;
        }
    }

    private static bool IsTransientFailure(EvalResult result)
    {
        // Consider a failure transient if the failure reason suggests an HTTP or timeout issue
        var reason = result.FailureReason ?? "";
        return reason.Contains("503", StringComparison.OrdinalIgnoreCase)
            || reason.Contains("timeout", StringComparison.OrdinalIgnoreCase)
            || reason.Contains("timed out", StringComparison.OrdinalIgnoreCase)
            || reason.Contains("connection", StringComparison.OrdinalIgnoreCase);
    }
}

/// <summary>
/// Retry configuration for transient failures.
/// </summary>
public record RetryConfig
{
    public int MaxRetryCount { get; init; } = 2;
    public double InitialDelaySeconds { get; init; } = 1.0;
    public double BackoffMultiplier { get; init; } = 2.0;
}
