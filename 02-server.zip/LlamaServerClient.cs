using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using FluentResults;
using Microsoft.Extensions.Logging;
using Seevalocal.Server.Models;
using Seevalocal.Server.Serialization;

namespace Seevalocal.Server.Client;

/// <summary>
/// Pre-configured HTTP client for a llama-server instance.
/// Constructed from a <see cref="ServerInfo"/>. Thread-safe; share one instance per endpoint.
/// </summary>
public sealed class LlamaServerClient
{
    private readonly ServerInfo _serverInfo;
    private readonly HttpClient _httpClient;
    private readonly ILogger<LlamaServerClient> _logger;

    public LlamaServerClient(
        ServerInfo serverInfo,
        HttpClient httpClient,
        ILogger<LlamaServerClient> logger)
    {
        _serverInfo = serverInfo ?? throw new ArgumentNullException(nameof(serverInfo));
        _httpClient = httpClient ?? throw new ArgumentNullException(nameof(httpClient));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    // ── Chat Completions (/v1/chat/completions) ───────────────────────────────

    public async Task<Result<ChatCompletionResponse>> ChatCompletionAsync(
        ChatCompletionRequest request,
        CancellationToken ct)
    {
        ArgumentNullException.ThrowIfNull(request);

        return await PostAsync<ChatCompletionRequest, ChatCompletionResponse>(
            "/v1/chat/completions", request, ct);
    }

    // ── Anthropic-compatible (/v1/messages) ───────────────────────────────────

    public async Task<Result<AnthropicMessageResponse>> AnthropicMessageAsync(
        AnthropicMessageRequest request,
        CancellationToken ct)
    {
        ArgumentNullException.ThrowIfNull(request);

        return await PostAsync<AnthropicMessageRequest, AnthropicMessageResponse>(
            "/v1/messages", request, ct);
    }

    // ── Props (/props) ────────────────────────────────────────────────────────

    public async Task<Result<ServerProps>> GetPropsAsync(CancellationToken ct)
    {
        return await GetAsync<ServerProps>("/props", ct);
    }

    // ── Health (/health) ──────────────────────────────────────────────────────

    public async Task<Result<HealthStatus>> GetHealthAsync(CancellationToken ct)
    {
        return await GetAsync<HealthStatus>("/health", ct);
    }

    // ── Tokenize (/tokenize) ──────────────────────────────────────────────────

    public async Task<Result<TokenizeResponse>> TokenizeAsync(
        string content,
        bool addSpecial,
        CancellationToken ct)
    {
        var body = new { content, add_special = addSpecial };
        return await PostAsync<object, TokenizeResponse>("/tokenize", body, ct);
    }

    // ── Embeddings (/v1/embeddings) ───────────────────────────────────────────

    public async Task<Result<EmbeddingsResponse>> GetEmbeddingsAsync(
        EmbeddingsRequest request,
        CancellationToken ct)
    {
        ArgumentNullException.ThrowIfNull(request);
        return await PostAsync<EmbeddingsRequest, EmbeddingsResponse>("/v1/embeddings", request, ct);
    }

    // ── Private HTTP helpers ─────────────────────────────────────────────────

    private async Task<Result<TResponse>> PostAsync<TRequest, TResponse>(
        string path,
        TRequest payload,
        CancellationToken ct)
    {
        var url = BuildUrl(path);

        try
        {
            _logger.LogDebug("POST {Url}", url);

            var json = JsonSerializer.Serialize(payload, LlamaJsonOptions.Request);
            using var content = new StringContent(json, Encoding.UTF8, "application/json");
            using var requestMessage = new HttpRequestMessage(HttpMethod.Post, url) { Content = content };
            AddAuthHeader(requestMessage);

            var response = await _httpClient.SendAsync(requestMessage, ct);

            return await DeserializeResponseAsync<TResponse>(response, url, ct);
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            _logger.LogError(ex, "[LlamaServerClient] POST {Url} failed: {Message}", url, ex.Message);
            return Result.Fail($"[LlamaServerClient] POST {path} failed: {ex.Message}");
        }
    }

    private async Task<Result<TResponse>> GetAsync<TResponse>(string path, CancellationToken ct)
    {
        var url = BuildUrl(path);

        try
        {
            _logger.LogDebug("GET {Url}", url);

            using var requestMessage = new HttpRequestMessage(HttpMethod.Get, url);
            AddAuthHeader(requestMessage);

            var response = await _httpClient.SendAsync(requestMessage, ct);
            return await DeserializeResponseAsync<TResponse>(response, url, ct);
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            _logger.LogError(ex, "[LlamaServerClient] GET {Url} failed: {Message}", url, ex.Message);
            return Result.Fail($"[LlamaServerClient] GET {path} failed: {ex.Message}");
        }
    }

    private async Task<Result<TResponse>> DeserializeResponseAsync<TResponse>(
        HttpResponseMessage response,
        string url,
        CancellationToken ct)
    {
        var body = await response.Content.ReadAsStringAsync(ct);

        if (!response.IsSuccessStatusCode)
        {
            _logger.LogError(
                "[LlamaServerClient] {Url} returned HTTP {StatusCode}: {Body}",
                url, (int)response.StatusCode, body);
            return Result.Fail(
                $"[LlamaServerClient] {url} returned HTTP {(int)response.StatusCode}: {body}");
        }

        try
        {
            var result = JsonSerializer.Deserialize<TResponse>(body, LlamaJsonOptions.LlamaServer);
            if (result is null)
                return Result.Fail($"[LlamaServerClient] Deserialized null from {url}");
            return Result.Ok(result);
        }
        catch (JsonException ex)
        {
            _logger.LogError(ex, "[LlamaServerClient] Failed to deserialize response from {Url}", url);
            return Result.Fail(
                $"[LlamaServerClient] JSON deserialization failed for {url}: {ex.Message}. Body: {body[..Math.Min(body.Length, 500)]}");
        }
    }

    private string BuildUrl(string path) => $"{_serverInfo.BaseUrl.TrimEnd('/')}{path}";

    private void AddAuthHeader(HttpRequestMessage request)
    {
        if (_serverInfo.ApiKey is { Length: > 0 } key)
            request.Headers.Authorization =
                new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", key);
    }
}
