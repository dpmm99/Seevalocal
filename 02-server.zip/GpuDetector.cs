using System.Runtime.InteropServices;
using FluentResults;
using Microsoft.Extensions.Logging;
using Seevalocal.Server.Models;

namespace Seevalocal.Server.Detection;

/// <summary>
/// Detects the available GPU type on the current host.
/// Detection order: CUDA → Metal → Vulkan → CpuOnly.
/// </summary>
public sealed class GpuDetector
{
    private readonly ILogger<GpuDetector> _logger;

    public GpuDetector(ILogger<GpuDetector> logger)
    {
        _logger = logger;
    }

    public async Task<GpuKind> DetectAsync(CancellationToken cancellationToken = default)
    {
        // 1. CUDA check
        if (await HasCudaAsync(cancellationToken))
        {
            _logger.LogInformation("GPU detection: CUDA detected");
            return GpuKind.Cuda;
        }

        // 2. Metal (macOS always has Metal if we reach here)
        if (RuntimeInformation.IsOSPlatform(OSPlatform.OSX))
        {
            _logger.LogInformation("GPU detection: Metal detected (macOS)");
            return GpuKind.Metal;
        }

        // 3. Vulkan
        if (HasVulkan())
        {
            _logger.LogInformation("GPU detection: Vulkan detected");
            return GpuKind.Vulkan;
        }

        // 4. Fallback
        _logger.LogInformation("GPU detection: no GPU found, using CPU-only");
        return GpuKind.CpuOnly;
    }

    private async Task<bool> HasCudaAsync(CancellationToken ct)
    {
        // Check Windows registry first
        if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows) && HasNvidiaRegistry())
            return true;

        // Try nvidia-smi
        return await TryRunToolAsync("nvidia-smi", "--query-gpu=name --format=csv,noheader", ct);
    }

    private static bool HasNvidiaRegistry()
    {
        if (!RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
            return false;

        try
        {
            using var key = Microsoft.Win32.Registry.LocalMachine
                .OpenSubKey(@"SOFTWARE\NVIDIA Corporation\NVSMI");
            return key is not null;
        }
        catch
        {
            return false;
        }
    }

    private bool HasVulkan()
    {
        // Check for Vulkan runtime DLL/SO
        if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
        {
            return File.Exists(Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.System), "vulkan-1.dll"));
        }

        if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux))
        {
            // Common locations for libvulkan on Linux
            return File.Exists("/usr/lib/x86_64-linux-gnu/libvulkan.so.1")
                || File.Exists("/usr/lib/libvulkan.so.1")
                || File.Exists("/usr/lib64/libvulkan.so.1");
        }

        return false;
    }

    private async Task<bool> TryRunToolAsync(string toolName, string arguments, CancellationToken ct)
    {
        try
        {
            var psi = new System.Diagnostics.ProcessStartInfo
            {
                FileName = toolName,
                Arguments = arguments,
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                CreateNoWindow = true,
            };

            using var process = new System.Diagnostics.Process { StartInfo = psi };
            process.Start();

            // Read output but don't wait more than 5 seconds
            var outputTask = process.StandardOutput.ReadToEndAsync(ct);
            var finished = await Task.WhenAny(
                process.WaitForExitAsync(ct),
                Task.Delay(TimeSpan.FromSeconds(5), ct));

            if (!process.HasExited)
            {
                process.Kill(entireProcessTree: true);
                return false;
            }

            var output = await outputTask;
            return process.ExitCode == 0 && !string.IsNullOrWhiteSpace(output);
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            _logger.LogDebug("Tool '{Tool}' not found or failed: {Message}", toolName, ex.Message);
            return false;
        }
    }
}
