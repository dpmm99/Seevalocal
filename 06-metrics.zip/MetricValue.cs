using System.Text.Json.Serialization;

namespace Seevalocal.Core.Models;

/// <summary>
/// A typed, named measurement emitted by a pipeline stage.
/// RULE: Name MUST end with a unit suffix (Seconds, Count, Bytes, Ratio, Percent, etc.).
/// See 00-conventions.md §2.1 for the full list.
/// </summary>
public record MetricValue
{
    /// <summary>Name of the metric, including unit suffix. PascalCase.</summary>
    public string Name { get; init; } = "";

    /// <summary>The actual value.</summary>
    public MetricScalar Value { get; init; } = new MetricScalar.StringMetric("");

    /// <summary>
    /// Optional group/stage that produced this metric, for disambiguation.
    /// E.g., "CompileStage", "JudgeStage".
    /// </summary>
    public string? SourceStage { get; init; }
}

/// <summary>Discriminated union of all metric scalar types.</summary>
[JsonConverter(typeof(MetricScalarJsonConverter))]
public abstract record MetricScalar
{
    public sealed record IntMetric(int Value) : MetricScalar;
    public sealed record DoubleMetric(double Value) : MetricScalar;
    public sealed record BoolMetric(bool Value) : MetricScalar;
    public sealed record StringMetric(string Value) : MetricScalar;

    private MetricScalar() { }
}

public static class MetricScalarExtensions
{
    public static object? ToObject(this MetricScalar m) => m switch
    {
        MetricScalar.IntMetric(var v) => v,
        MetricScalar.DoubleMetric(var v) => v,
        MetricScalar.BoolMetric(var v) => v,
        MetricScalar.StringMetric(var v) => v,
        _ => null
    };
}

public enum MetricType { Int, Double, Bool, String }
