using System.Globalization;
using System.Text;
using CsvHelper;
using CsvHelper.Configuration;
using Microsoft.Extensions.Logging;
using Seevalocal.Core.Abstractions;
using Seevalocal.Core.Models;
using Seevalocal.Metrics.Models;

namespace Seevalocal.Metrics.Writers;

/// <summary>
/// Writes summary.csv at finalization with one row per eval result.
/// Columns include standard fields plus one column per unique metric name.
/// Thread-safe buffering of results; file written only at finalization.
/// </summary>
public sealed class CsvResultWriter : IResultWriter
{
    private readonly string _outputDir;
    private readonly bool _writeSummaryCsv;
    private readonly ILogger<CsvResultWriter> _logger;
    private readonly List<EvalResult> _buffer = new();
    private readonly object _bufferLock = new();

    public CsvResultWriter(
        string outputDir,
        bool writeSummaryCsv = true,
        ILogger<CsvResultWriter>? logger = null)
    {
        _outputDir = outputDir ?? throw new ArgumentNullException(nameof(outputDir));
        _writeSummaryCsv = writeSummaryCsv;
        _logger = logger ?? Microsoft.Extensions.Logging.Abstractions.NullLogger<CsvResultWriter>.Instance;
    }

    public Task WriteResultAsync(EvalResult result, CancellationToken ct)
    {
        lock (_bufferLock)
            _buffer.Add(result);
        return Task.CompletedTask;
    }

    public Task WriteSummaryAsync(RunSummary summary, CancellationToken ct) => Task.CompletedTask;

    public async Task FinalizeAsync(CancellationToken ct)
    {
        if (!_writeSummaryCsv) return;

        List<EvalResult> snapshot;
        lock (_bufferLock)
            snapshot = new List<EvalResult>(_buffer);

        if (snapshot.Count == 0) return;

        // Collect all unique metric names (preserving first-seen order)
        var metricNames = snapshot
            .SelectMany(r => r.Metrics.Select(m => m.Name))
            .Distinct()
            .ToList();

        var filePath = Path.Combine(_outputDir, "summary.csv");
        var config = new CsvConfiguration(CultureInfo.InvariantCulture) { HasHeaderRecord = true };

        await using var writer = new StreamWriter(filePath, append: false, Encoding.UTF8);
        await using var csv = new CsvWriter(writer, config);

        // Write header
        csv.WriteField("evalItemId");
        csv.WriteField("evalSetId");
        csv.WriteField("succeeded");
        csv.WriteField("durationSeconds");
        foreach (var name in metricNames)
            csv.WriteField(name);
        await csv.NextRecordAsync().ConfigureAwait(false);

        // Write rows
        foreach (var result in snapshot)
        {
            ct.ThrowIfCancellationRequested();
            var metricLookup = result.Metrics
                .GroupBy(m => m.Name)
                .ToDictionary(g => g.Key, g => g.Last().Value.ToObject());

            csv.WriteField(result.EvalItemId);
            csv.WriteField(result.EvalSetId);
            csv.WriteField(result.Succeeded ? "true" : "false");
            csv.WriteField(result.DurationSeconds.ToString("F6", CultureInfo.InvariantCulture));

            foreach (var name in metricNames)
            {
                if (metricLookup.TryGetValue(name, out var val) && val is not null)
                    csv.WriteField(Convert.ToString(val, CultureInfo.InvariantCulture));
                else
                    csv.WriteField("");
            }

            await csv.NextRecordAsync().ConfigureAwait(false);
        }

        _logger.LogInformation("[CsvResultWriter] Wrote {Count} rows to {FilePath}", snapshot.Count, filePath);
    }
}
