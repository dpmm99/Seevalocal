using System.Text.Json.Serialization;

namespace Seevalocal.Config.Models;

// ---------------------------------------------------------------------------
// Enums
// ---------------------------------------------------------------------------

public enum ShellTarget { Bash, PowerShell }

// ---------------------------------------------------------------------------
// Shared sub-records (also used by Server – stubs here, real types in .Server)
// ---------------------------------------------------------------------------

/// <summary>
/// All llama-server tuning knobs. All fields are nullable — null means omit
/// from CLI args and let llama-server use its own default.
/// </summary>
public record LlamaServerSettings
{
    // Context / batching
    public int? ContextWindowTokens { get; init; }
    public int? BatchSizeTokens { get; init; }
    public int? UbatchSizeTokens { get; init; }
    public int? ParallelSlotCount { get; init; }
    public bool? EnableContinuousBatching { get; init; }
    public bool? EnableCachePrompt { get; init; }
    public bool? EnableContextShift { get; init; }

    // GPU
    public int? GpuLayerCount { get; init; }
    public string? SplitMode { get; init; }
    public string? KvCacheTypeK { get; init; }
    public string? KvCacheTypeV { get; init; }
    public bool? EnableKvOffload { get; init; }
    public bool? EnableFlashAttention { get; init; }

    // Sampling
    public double? SamplingTemperature { get; init; }
    public double? TopP { get; init; }
    public int? TopK { get; init; }
    public double? MinP { get; init; }
    public double? RepeatPenalty { get; init; }
    public int? RepeatLastNTokens { get; init; }
    public double? PresencePenalty { get; init; }
    public double? FrequencyPenalty { get; init; }
    public int? Seed { get; init; }

    // Threading
    public int? ThreadCount { get; init; }
    public int? HttpThreadCount { get; init; }

    // Model behaviour
    public string? ChatTemplate { get; init; }
    public bool? EnableJinja { get; init; }
    public string? ReasoningFormat { get; init; }
    public string? ModelAlias { get; init; }

    // Logging
    public int? LogVerbosity { get; init; }

    // Memory
    public bool? EnableMlock { get; init; }
    public bool? EnableMmap { get; init; }

    // Timeouts
    public double? ServerTimeoutSeconds { get; init; }

    // Pass-through (advanced)
    public IReadOnlyList<string> ExtraArgs { get; init; } = [];
}

// ---------------------------------------------------------------------------
// DataSourceConfig
// ---------------------------------------------------------------------------

public enum DataSourceKind
{
    Directory,
    SingleFile,
    JsonFile,
    YamlFile,
    CsvFile,
    ParquetFile,
}

public record FieldMapping
{
    public string? IdField { get; init; }
    public string? SystemPromptField { get; init; }
    public string? UserPromptField { get; init; }
    public string? ExpectedOutputField { get; init; }
    public string? ArtifactFilePathField { get; init; }
}

public record DataSourceConfig
{
    public DataSourceKind Kind { get; init; } = DataSourceKind.Directory;

    /// <summary>Used when Kind = Directory. Path to prompt files.</summary>
    public string? PromptDirectoryPath { get; init; }

    /// <summary>Used when Kind = Directory. Path to expected-output files (optional).</summary>
    public string? ExpectedOutputDirectoryPath { get; init; }

    /// <summary>Path to a single file (JSON, YAML, CSV, Parquet, or raw text).</summary>
    public string? FilePath { get; init; }

    /// <summary>Optional default system prompt applied to all items from this source.</summary>
    public string? DefaultSystemPrompt { get; init; }

    /// <summary>Path to a file whose contents become the default system prompt.</summary>
    public string? DefaultSystemPromptFilePath { get; init; }

    /// <summary>Column/field mapping for structured sources.</summary>
    public FieldMapping FieldMapping { get; init; } = new();

    /// <summary>Glob pattern filter for directory sources. Default: *</summary>
    public string FilePattern { get; init; } = "*";
}

// ---------------------------------------------------------------------------
// PipelineConfig / OutputConfig
// ---------------------------------------------------------------------------

public record PipelineConfig
{
    // Pipeline-specific options are passed via EvalSetConfig.PipelineOptions.
    // This record is intentionally open for future base options.
}

public record OutputConfig
{
    public bool WritePerEvalJson { get; init; } = true;
    public bool WriteSummaryJson { get; init; } = true;
    public bool WriteSummaryCsv { get; init; } = true;
    public bool WriteResultsParquet { get; init; } = false;
    public bool IncludeRawLlmResponse { get; init; } = true;
    public bool IncludeAllStageOutputs { get; init; } = false;
}

// ---------------------------------------------------------------------------
// EvalSetConfig
// ---------------------------------------------------------------------------

public record EvalSetConfig
{
    public string Id { get; init; } = "";
    public string Name { get; init; } = "";
    public string PipelineName { get; init; } = "";
    public DataSourceConfig DataSource { get; init; } = new();
    public PipelineConfig Pipeline { get; init; } = new();
    public OutputConfig Output { get; init; } = new();

    /// <summary>
    /// Pipeline-specific options forwarded to IBuiltinPipelineFactory.Create().
    /// Keys/values are pipeline-defined.
    /// </summary>
    public IReadOnlyDictionary<string, object?> PipelineOptions { get; init; }
        = new Dictionary<string, object?>();

    /// <summary>Optional endpoint name override. Null = use primary server.</summary>
    public string? EndpointName { get; init; }
}

// ---------------------------------------------------------------------------
// RunMeta
// ---------------------------------------------------------------------------

public record RunMeta
{
    public string RunName { get; init; } = "";
    public string OutputDirectoryPath { get; init; } = "./results";
    public ShellTarget ExportShellTarget { get; init; } = ShellTarget.Bash;
    public bool ContinueOnEvalFailure { get; init; } = true;

    /// <summary>null = use total_slots from server /props response.</summary>
    public int? MaxConcurrentEvals { get; init; }
}

// ---------------------------------------------------------------------------
// JudgeConfig
// ---------------------------------------------------------------------------

public record JudgeConfig
{
    public string BaseUrl { get; init; } = "";
    public string? ApiKey { get; init; }
    public string ModelAlias { get; init; } = "";
    public string? SystemPromptTemplate { get; init; }
    public string? UserPromptTemplate { get; init; }
    public double? SamplingTemperature { get; init; }
    public int? MaxCompletionTokens { get; init; }
}

// ---------------------------------------------------------------------------
// Server stub — full type lives in Seevalocal.Server
// Reproduced here minimally so Config has no project reference to Server.
// The real ServerConfig is in Seevalocal.Server.Models; this mirrors it.
// ---------------------------------------------------------------------------

public enum ModelSourceKind { LocalFile, HuggingFace }

public record ModelSource
{
    public ModelSourceKind Kind { get; init; }
    public string? FilePath { get; init; }
    public string? HfRepo { get; init; }
    public string? HfQuant { get; init; }
    public string? HfToken { get; init; }
}

public record ServerConfig
{
    public bool Manage { get; init; }
    public string? ExecutablePath { get; init; }
    public ModelSource? Model { get; init; }
    public string Host { get; init; } = "127.0.0.1";
    public int Port { get; init; } = 8080;
    public string? ApiKey { get; init; }
    public IReadOnlyList<string> ExtraArgs { get; init; } = [];
    public string? BaseUrl { get; init; }
}

// ---------------------------------------------------------------------------
// ResolvedConfig (fully-populated, immutable)
// ---------------------------------------------------------------------------

public record ResolvedConfig
{
    public RunMeta Run { get; init; } = new();
    public ServerConfig Server { get; init; } = new();
    public LlamaServerSettings LlamaServer { get; init; } = new();
    public IReadOnlyList<EvalSetConfig> EvalSets { get; init; } = [];
    public JudgeConfig? Judge { get; init; }
}

// ---------------------------------------------------------------------------
// PartialConfig — structurally mirrors ResolvedConfig but every leaf nullable
// ---------------------------------------------------------------------------

public record PartialRunMeta
{
    public string? RunName { get; init; }
    public string? OutputDirectoryPath { get; init; }
    public ShellTarget? ExportShellTarget { get; init; }
    public bool? ContinueOnEvalFailure { get; init; }
    public int? MaxConcurrentEvals { get; init; }
}

public record PartialLlamaServerSettings
{
    public int? ContextWindowTokens { get; init; }
    public int? BatchSizeTokens { get; init; }
    public int? UbatchSizeTokens { get; init; }
    public int? ParallelSlotCount { get; init; }
    public bool? EnableContinuousBatching { get; init; }
    public bool? EnableCachePrompt { get; init; }
    public bool? EnableContextShift { get; init; }
    public int? GpuLayerCount { get; init; }
    public string? SplitMode { get; init; }
    public string? KvCacheTypeK { get; init; }
    public string? KvCacheTypeV { get; init; }
    public bool? EnableKvOffload { get; init; }
    public bool? EnableFlashAttention { get; init; }
    public double? SamplingTemperature { get; init; }
    public double? TopP { get; init; }
    public int? TopK { get; init; }
    public double? MinP { get; init; }
    public double? RepeatPenalty { get; init; }
    public int? RepeatLastNTokens { get; init; }
    public double? PresencePenalty { get; init; }
    public double? FrequencyPenalty { get; init; }
    public int? Seed { get; init; }
    public int? ThreadCount { get; init; }
    public int? HttpThreadCount { get; init; }
    public string? ChatTemplate { get; init; }
    public bool? EnableJinja { get; init; }
    public string? ReasoningFormat { get; init; }
    public string? ModelAlias { get; init; }
    public int? LogVerbosity { get; init; }
    public bool? EnableMlock { get; init; }
    public bool? EnableMmap { get; init; }
    public double? ServerTimeoutSeconds { get; init; }
    public IReadOnlyList<string>? ExtraArgs { get; init; }
}

public record PartialServerConfig
{
    public bool? Manage { get; init; }
    public string? ExecutablePath { get; init; }
    public ModelSource? Model { get; init; }
    public string? Host { get; init; }
    public int? Port { get; init; }
    public string? ApiKey { get; init; }
    public IReadOnlyList<string>? ExtraArgs { get; init; }
    public string? BaseUrl { get; init; }
}

public record PartialConfig
{
    public PartialRunMeta? Run { get; init; }
    public PartialServerConfig? Server { get; init; }
    public PartialLlamaServerSettings? LlamaServer { get; init; }
    public IReadOnlyList<EvalSetConfig>? EvalSets { get; init; }
    public JudgeConfig? Judge { get; init; }
}

// ---------------------------------------------------------------------------
// ValidationError
// ---------------------------------------------------------------------------

public record ValidationError(string Field, string MessageText);
