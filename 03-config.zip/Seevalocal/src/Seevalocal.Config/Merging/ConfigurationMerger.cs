using Seevalocal.Config.Models;

namespace Seevalocal.Config.Merging;

/// <summary>
/// Merges an ordered list of <see cref="PartialConfig"/> settings files plus CLI
/// overrides into a single <see cref="ResolvedConfig"/>.
///
/// Merge rule (right-fold null-coalescing, per 03-config.md §4.1):
///   For each leaf field:
///     1. If CLI overrides has a non-null value → use it.
///     2. Else walk settings files from last to first; use first non-null.
///     3. If still null → field is unset; use defaults.
/// </summary>
public sealed class ConfigurationMerger
{
    /// <summary>
    /// Merges settings files in order; later files override earlier ones.
    /// CLI overrides are applied last (highest priority).
    /// </summary>
    public ResolvedConfig Merge(
        IReadOnlyList<PartialConfig> settingsFiles,
        PartialConfig? cliOverrides = null)
    {
        // Build a combined list ordered lowest → highest priority
        // (index 0 = first file, last = CLI)
        var all = new List<PartialConfig>(settingsFiles);
        if (cliOverrides is not null)
            all.Add(cliOverrides);

        return new ResolvedConfig
        {
            Run = MergeRunMeta(all),
            Server = MergeServerConfig(all),
            LlamaServer = MergeLlamaServerSettings(all),
            EvalSets = MergeEvalSets(all),
            Judge = MergeJudgeConfig(all),
        };
    }

    // -------------------------------------------------------------------------
    // Helpers — pick last non-null value from the list for a given selector
    // -------------------------------------------------------------------------

    private static T? Last<T>(IReadOnlyList<PartialConfig> all, Func<PartialConfig, T?> selector)
        where T : class
    {
        for (var i = all.Count - 1; i >= 0; i--)
        {
            var v = selector(all[i]);
            if (v is not null)
                return v;
        }
        return null;
    }

    private static T? LastValue<T>(IReadOnlyList<PartialConfig> all, Func<PartialConfig, T?> selector)
        where T : struct
    {
        for (var i = all.Count - 1; i >= 0; i--)
        {
            var v = selector(all[i]);
            if (v.HasValue)
                return v;
        }
        return null;
    }

    // -------------------------------------------------------------------------

    private static RunMeta MergeRunMeta(IReadOnlyList<PartialConfig> all)
    {
        PartialRunMeta? Pick(PartialConfig p) => p.Run;

        return new RunMeta
        {
            RunName = LastRun(all, r => r.RunName is not null ? r.RunName : null) ?? "",
            OutputDirectoryPath = LastRun(all, r => r.OutputDirectoryPath) ?? "./results",
            ExportShellTarget = LastRunValue(all, r => r.ExportShellTarget) ?? ShellTarget.Bash,
            ContinueOnEvalFailure = LastRunValue(all, r => r.ContinueOnEvalFailure) ?? true,
            MaxConcurrentEvals = LastRunValue(all, r => r.MaxConcurrentEvals),
        };

        static string? LastRun(IReadOnlyList<PartialConfig> all, Func<PartialRunMeta, string?> sel)
        {
            for (var i = all.Count - 1; i >= 0; i--)
            {
                var run = all[i].Run;
                if (run is null) continue;
                var v = sel(run);
                if (v is not null) return v;
            }
            return null;
        }

        static T? LastRunValue<T>(IReadOnlyList<PartialConfig> all, Func<PartialRunMeta, T?> sel)
            where T : struct
        {
            for (var i = all.Count - 1; i >= 0; i--)
            {
                var run = all[i].Run;
                if (run is null) continue;
                var v = sel(run);
                if (v.HasValue) return v;
            }
            return null;
        }
    }

    private static ServerConfig MergeServerConfig(IReadOnlyList<PartialConfig> all)
    {
        return new ServerConfig
        {
            Manage = LastSrv(all, s => s.Manage) ?? false,
            ExecutablePath = LastSrvStr(all, s => s.ExecutablePath),
            Model = LastSrvRef(all, s => s.Model),
            Host = LastSrvStr(all, s => s.Host) ?? "127.0.0.1",
            Port = LastSrv(all, s => s.Port) ?? 8080,
            ApiKey = LastSrvStr(all, s => s.ApiKey),
            ExtraArgs = LastSrvRef(all, s => s.ExtraArgs) ?? [],
            BaseUrl = LastSrvStr(all, s => s.BaseUrl),
        };

        static T? LastSrv<T>(IReadOnlyList<PartialConfig> all, Func<PartialServerConfig, T?> sel)
            where T : struct
        {
            for (var i = all.Count - 1; i >= 0; i--)
            {
                var s = all[i].Server; if (s is null) continue;
                var v = sel(s); if (v.HasValue) return v;
            }
            return null;
        }
        static string? LastSrvStr(IReadOnlyList<PartialConfig> all, Func<PartialServerConfig, string?> sel)
        {
            for (var i = all.Count - 1; i >= 0; i--)
            {
                var s = all[i].Server; if (s is null) continue;
                var v = sel(s); if (v is not null) return v;
            }
            return null;
        }
        static T? LastSrvRef<T>(IReadOnlyList<PartialConfig> all, Func<PartialServerConfig, T?> sel)
            where T : class
        {
            for (var i = all.Count - 1; i >= 0; i--)
            {
                var s = all[i].Server; if (s is null) continue;
                var v = sel(s); if (v is not null) return v;
            }
            return null;
        }
    }

    private static LlamaServerSettings MergeLlamaServerSettings(IReadOnlyList<PartialConfig> all)
    {
        return new LlamaServerSettings
        {
            ContextWindowTokens = L(all, s => s.ContextWindowTokens),
            BatchSizeTokens = L(all, s => s.BatchSizeTokens),
            UbatchSizeTokens = L(all, s => s.UbatchSizeTokens),
            ParallelSlotCount = L(all, s => s.ParallelSlotCount),
            EnableContinuousBatching = L(all, s => s.EnableContinuousBatching),
            EnableCachePrompt = L(all, s => s.EnableCachePrompt),
            EnableContextShift = L(all, s => s.EnableContextShift),
            GpuLayerCount = L(all, s => s.GpuLayerCount),
            SplitMode = Ls(all, s => s.SplitMode),
            KvCacheTypeK = Ls(all, s => s.KvCacheTypeK),
            KvCacheTypeV = Ls(all, s => s.KvCacheTypeV),
            EnableKvOffload = L(all, s => s.EnableKvOffload),
            EnableFlashAttention = L(all, s => s.EnableFlashAttention),
            SamplingTemperature = Ld(all, s => s.SamplingTemperature),
            TopP = Ld(all, s => s.TopP),
            TopK = L(all, s => s.TopK),
            MinP = Ld(all, s => s.MinP),
            RepeatPenalty = Ld(all, s => s.RepeatPenalty),
            RepeatLastNTokens = L(all, s => s.RepeatLastNTokens),
            PresencePenalty = Ld(all, s => s.PresencePenalty),
            FrequencyPenalty = Ld(all, s => s.FrequencyPenalty),
            Seed = L(all, s => s.Seed),
            ThreadCount = L(all, s => s.ThreadCount),
            HttpThreadCount = L(all, s => s.HttpThreadCount),
            ChatTemplate = Ls(all, s => s.ChatTemplate),
            EnableJinja = L(all, s => s.EnableJinja),
            ReasoningFormat = Ls(all, s => s.ReasoningFormat),
            ModelAlias = Ls(all, s => s.ModelAlias),
            LogVerbosity = L(all, s => s.LogVerbosity),
            EnableMlock = L(all, s => s.EnableMlock),
            EnableMmap = L(all, s => s.EnableMmap),
            ServerTimeoutSeconds = Ld(all, s => s.ServerTimeoutSeconds),
            ExtraArgs = LlamaExtraArgs(all),
        };

        static int? L(IReadOnlyList<PartialConfig> all, Func<PartialLlamaServerSettings, int?> sel)
        {
            for (var i = all.Count - 1; i >= 0; i--)
            {
                var s = all[i].LlamaServer; if (s is null) continue;
                var v = sel(s); if (v.HasValue) return v;
            }
            return null;
        }
        static bool? L(IReadOnlyList<PartialConfig> all, Func<PartialLlamaServerSettings, bool?> sel)
        {
            for (var i = all.Count - 1; i >= 0; i--)
            {
                var s = all[i].LlamaServer; if (s is null) continue;
                var v = sel(s); if (v.HasValue) return v;
            }
            return null;
        }
        static double? Ld(IReadOnlyList<PartialConfig> all, Func<PartialLlamaServerSettings, double?> sel)
        {
            for (var i = all.Count - 1; i >= 0; i--)
            {
                var s = all[i].LlamaServer; if (s is null) continue;
                var v = sel(s); if (v.HasValue) return v;
            }
            return null;
        }
        static string? Ls(IReadOnlyList<PartialConfig> all, Func<PartialLlamaServerSettings, string?> sel)
        {
            for (var i = all.Count - 1; i >= 0; i--)
            {
                var s = all[i].LlamaServer; if (s is null) continue;
                var v = sel(s); if (v is not null) return v;
            }
            return null;
        }
        static IReadOnlyList<string> LlamaExtraArgs(IReadOnlyList<PartialConfig> all)
        {
            for (var i = all.Count - 1; i >= 0; i--)
            {
                var s = all[i].LlamaServer;
                if (s?.ExtraArgs is { Count: > 0 } args) return args;
            }
            return [];
        }
    }

    private static IReadOnlyList<EvalSetConfig> MergeEvalSets(IReadOnlyList<PartialConfig> all)
    {
        // EvalSets are taken from the highest-priority file that defines them.
        for (var i = all.Count - 1; i >= 0; i--)
        {
            var sets = all[i].EvalSets;
            if (sets is { Count: > 0 })
                return sets;
        }
        return [];
    }

    private static JudgeConfig? MergeJudgeConfig(IReadOnlyList<PartialConfig> all)
    {
        for (var i = all.Count - 1; i >= 0; i--)
        {
            var j = all[i].Judge;
            if (j is not null) return j;
        }
        return null;
    }
}
