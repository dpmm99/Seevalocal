using FluentAssertions;
using Microsoft.Extensions.Logging.Abstractions;
using Seevalocal.Config.Loading;
using Seevalocal.Config.Models;
using Xunit;

namespace Seevalocal.Config.Tests;

public sealed class SettingsFileLoaderTests : IDisposable
{
    private readonly SettingsFileLoader _loader = new(NullLogger<SettingsFileLoader>.Instance);
    private readonly List<string> _tempFiles = [];

    private string WriteTemp(string extension, string content)
    {
        var path = Path.Combine(Path.GetTempPath(), $"seevalocal-test-{Guid.NewGuid()}{extension}");
        File.WriteAllText(path, content);
        _tempFiles.Add(path);
        return path;
    }

    public void Dispose()
    {
        foreach (var f in _tempFiles)
            if (File.Exists(f)) File.Delete(f);
    }

    // -------------------------------------------------------------------------
    // YAML round-trip
    // -------------------------------------------------------------------------

    [Fact]
    public async Task Load_Yaml_ParsesRunMeta()
    {
        var yaml = """
            run:
              name: yaml-test
              outputDirectoryPath: /tmp/yaml-out
              exportShellTarget: Bash
            """;

        var path = WriteTemp(".yml", yaml);
        var result = await _loader.LoadAsync(path);

        result.IsSuccess.Should().BeTrue();
        result.Value.Run!.RunName.Should().Be("yaml-test");
        result.Value.Run!.OutputDirectoryPath.Should().Be("/tmp/yaml-out");
    }

    [Fact]
    public async Task Load_Yaml_ParsesLlamaServerSettings()
    {
        var yaml = """
            llamaServer:
              contextWindowTokens: 4096
              samplingTemperature: 0.5
              enableFlashAttention: true
              parallelSlotCount: 2
            """;

        var path = WriteTemp(".yaml", yaml);
        var result = await _loader.LoadAsync(path);

        result.IsSuccess.Should().BeTrue();
        result.Value.LlamaServer!.ContextWindowTokens.Should().Be(4096);
        result.Value.LlamaServer!.SamplingTemperature.Should().Be(0.5);
        result.Value.LlamaServer!.EnableFlashAttention.Should().BeTrue();
        result.Value.LlamaServer!.ParallelSlotCount.Should().Be(2);
    }

    [Fact]
    public async Task Load_Yaml_IgnoresUnknownFields()
    {
        var yaml = """
            unknownTopLevel: hello
            llamaServer:
              contextWindowTokens: 1024
              completelyMadeUpField: 999
            """;

        var path = WriteTemp(".yml", yaml);
        var result = await _loader.LoadAsync(path);

        result.IsSuccess.Should().BeTrue();
        result.Value.LlamaServer!.ContextWindowTokens.Should().Be(1024);
    }

    [Fact]
    public async Task Load_Yaml_ParsesEvalSets()
    {
        var yaml = """
            evalSets:
              - id: my-eval
                name: "My Eval"
                pipelineName: CSharpCoding
                dataSource:
                  kind: Directory
                  promptDirectoryPath: ./prompts
            """;

        var path = WriteTemp(".yml", yaml);
        var result = await _loader.LoadAsync(path);

        result.IsSuccess.Should().BeTrue();
        result.Value.EvalSets.Should().HaveCount(1);
        result.Value.EvalSets![0].Id.Should().Be("my-eval");
        result.Value.EvalSets![0].PipelineName.Should().Be("CSharpCoding");
        result.Value.EvalSets![0].DataSource.PromptDirectoryPath.Should().Be("./prompts");
    }

    // -------------------------------------------------------------------------
    // JSON round-trip
    // -------------------------------------------------------------------------

    [Fact]
    public async Task Load_Json_ParsesRunMeta()
    {
        var json = """
            {
              "run": {
                "name": "json-test",
                "outputDirectoryPath": "/tmp/json-out"
              }
            }
            """;

        var path = WriteTemp(".json", json);
        var result = await _loader.LoadAsync(path);

        result.IsSuccess.Should().BeTrue();
        result.Value.Run!.RunName.Should().Be("json-test");
        result.Value.Run!.OutputDirectoryPath.Should().Be("/tmp/json-out");
    }

    [Fact]
    public async Task Load_Json_ParsesLlamaServerSettings()
    {
        var json = """
            {
              "llamaServer": {
                "contextWindowTokens": 8192,
                "gpuLayerCount": 35
              }
            }
            """;

        var path = WriteTemp(".json", json);
        var result = await _loader.LoadAsync(path);

        result.IsSuccess.Should().BeTrue();
        result.Value.LlamaServer!.ContextWindowTokens.Should().Be(8192);
        result.Value.LlamaServer!.GpuLayerCount.Should().Be(35);
    }

    // -------------------------------------------------------------------------
    // Format auto-detection
    // -------------------------------------------------------------------------

    [Fact]
    public async Task Load_UnsupportedExtension_ReturnsFailure()
    {
        var path = WriteTemp(".txt", "anything");
        var result = await _loader.LoadAsync(path);

        result.IsFailed.Should().BeTrue();
    }

    // -------------------------------------------------------------------------
    // Missing file
    // -------------------------------------------------------------------------

    [Fact]
    public async Task Load_MissingFile_ReturnsFailure()
    {
        var result = await _loader.LoadAsync("/nonexistent/path/settings.yml");

        result.IsFailed.Should().BeTrue();
        result.Errors[0].Message.Should().Contain("[SettingsFileLoader]");
    }

    // -------------------------------------------------------------------------
    // Empty / minimal file
    // -------------------------------------------------------------------------

    [Fact]
    public async Task Load_EmptyYaml_ReturnsEmptyPartialConfig()
    {
        var path = WriteTemp(".yml", "");
        var result = await _loader.LoadAsync(path);

        result.IsSuccess.Should().BeTrue();
        result.Value.Should().NotBeNull();
        result.Value.Run.Should().BeNull();
        result.Value.LlamaServer.Should().BeNull();
    }

    [Fact]
    public async Task Load_EmptyJson_ReturnsEmptyPartialConfig()
    {
        var path = WriteTemp(".json", "{}");
        var result = await _loader.LoadAsync(path);

        result.IsSuccess.Should().BeTrue();
        result.Value.Should().NotBeNull();
    }

    // -------------------------------------------------------------------------
    // Server config
    // -------------------------------------------------------------------------

    [Fact]
    public async Task Load_Yaml_ParsesServerConfig()
    {
        var yaml = """
            server:
              manage: true
              host: 0.0.0.0
              port: 9090
              model:
                kind: LocalFile
                filePath: /models/test.gguf
            """;

        var path = WriteTemp(".yml", yaml);
        var result = await _loader.LoadAsync(path);

        result.IsSuccess.Should().BeTrue();
        result.Value.Server!.Manage.Should().BeTrue();
        result.Value.Server!.Host.Should().Be("0.0.0.0");
        result.Value.Server!.Port.Should().Be(9090);
        result.Value.Server!.Model!.FilePath.Should().Be("/models/test.gguf");
    }
}
