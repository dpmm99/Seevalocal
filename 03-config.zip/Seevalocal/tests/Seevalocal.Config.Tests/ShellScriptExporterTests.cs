using FluentAssertions;
using Seevalocal.Config.Export;
using Seevalocal.Config.Models;
using Xunit;

namespace Seevalocal.Config.Tests;

public sealed class ShellScriptExporterTests
{
    private readonly ShellScriptExporter _exporter = new();

    private static ResolvedConfig ManagedConfig(string runName = "test-run") => new()
    {
        Run = new RunMeta
        {
            RunName = runName,
            OutputDirectoryPath = "./results",
        },
        Server = new ServerConfig
        {
            Manage = true,
            Host = "127.0.0.1",
            Port = 8080,
            Model = new ModelSource
            {
                Kind = ModelSourceKind.LocalFile,
                FilePath = "/models/phi-4-Q4_K_M.gguf",
            },
        },
        LlamaServer = new LlamaServerSettings
        {
            ContextWindowTokens = 8192,
            ParallelSlotCount = 4,
            EnableFlashAttention = true,
            SamplingTemperature = 0.2,
        },
        EvalSets = [],
    };

    private static ResolvedConfig UnmanagedConfig() => new()
    {
        Run = new RunMeta { RunName = "ext-run", OutputDirectoryPath = "./out" },
        Server = new ServerConfig { Manage = false, BaseUrl = "http://remote:8080" },
        LlamaServer = new LlamaServerSettings(),
        EvalSets = [],
    };

    // -------------------------------------------------------------------------
    // Bash output
    // -------------------------------------------------------------------------

    [Fact]
    public void Export_Bash_ContainsShebang()
    {
        var script = _exporter.Export(ManagedConfig(), ShellTarget.Bash);
        script.Should().StartWith("#!/usr/bin/env bash");
    }

    [Fact]
    public void Export_Bash_ContainsRunName()
    {
        var script = _exporter.Export(ManagedConfig("my-run"), ShellTarget.Bash);
        script.Should().Contain("my-run");
    }

    [Fact]
    public void Export_Bash_ContainsModelPath()
    {
        var script = _exporter.Export(ManagedConfig(), ShellTarget.Bash);
        script.Should().Contain("/models/phi-4-Q4_K_M.gguf");
    }

    [Fact]
    public void Export_Bash_ContainsContextWindowFlag()
    {
        var script = _exporter.Export(ManagedConfig(), ShellTarget.Bash);
        script.Should().Contain("-c").And.Contain("8192");
    }

    [Fact]
    public void Export_Bash_ContainsParallelSlotFlag()
    {
        var script = _exporter.Export(ManagedConfig(), ShellTarget.Bash);
        script.Should().Contain("-np").And.Contain("4");
    }

    [Fact]
    public void Export_Bash_ContainsFlashAttentionFlag()
    {
        var script = _exporter.Export(ManagedConfig(), ShellTarget.Bash);
        script.Should().Contain("-fa").And.Contain("on");
    }

    [Fact]
    public void Export_Bash_ContainsTemperatureFlag()
    {
        var script = _exporter.Export(ManagedConfig(), ShellTarget.Bash);
        script.Should().Contain("--temp").And.Contain("0.2");
    }

    [Fact]
    public void Export_Bash_BackgroundsLlamaServer()
    {
        var script = _exporter.Export(ManagedConfig(), ShellTarget.Bash);
        script.Should().Contain("&");
        script.Should().Contain("LLAMA_PID=");
        script.Should().Contain("kill $LLAMA_PID");
    }

    [Fact]
    public void Export_Bash_ContainsDotnetRunCommand()
    {
        var script = _exporter.Export(ManagedConfig(), ShellTarget.Bash);
        script.Should().Contain("dotnet run --project Seevalocal.Cli");
    }

    [Fact]
    public void Export_Bash_ContainsOutputDir()
    {
        var script = _exporter.Export(ManagedConfig(), ShellTarget.Bash);
        script.Should().Contain("--output-dir").And.Contain("./results");
    }

    [Fact]
    public void Export_Bash_Unmanaged_NoLlamaServerBlock()
    {
        var script = _exporter.Export(UnmanagedConfig(), ShellTarget.Bash);
        script.Should().NotContain("llama-server");
        script.Should().NotContain("LLAMA_PID");
    }

    [Fact]
    public void Export_Bash_Unmanaged_UsesBaseUrl()
    {
        var script = _exporter.Export(UnmanagedConfig(), ShellTarget.Bash);
        script.Should().Contain("http://remote:8080");
    }

    // -------------------------------------------------------------------------
    // Null fields omitted
    // -------------------------------------------------------------------------

    [Fact]
    public void Export_Bash_NullFields_NotIncluded()
    {
        var config = ManagedConfig() with
        {
            LlamaServer = new LlamaServerSettings
            {
                // Only set temperature; everything else is null
                SamplingTemperature = 0.7,
            },
        };

        var script = _exporter.Export(config, ShellTarget.Bash);

        script.Should().NotContain("-np");
        script.Should().NotContain("-c ");
        script.Should().Contain("--temp");
    }

    // -------------------------------------------------------------------------
    // PowerShell output
    // -------------------------------------------------------------------------

    [Fact]
    public void Export_PowerShell_ContainsStartProcess()
    {
        var script = _exporter.Export(ManagedConfig(), ShellTarget.PowerShell);
        script.Should().Contain("Start-Process llama-server.exe");
    }

    [Fact]
    public void Export_PowerShell_ContainsModelPath()
    {
        var script = _exporter.Export(ManagedConfig(), ShellTarget.PowerShell);
        script.Should().Contain("/models/phi-4-Q4_K_M.gguf");
    }

    [Fact]
    public void Export_PowerShell_ContainsDotnetRunCommand()
    {
        var script = _exporter.Export(ManagedConfig(), ShellTarget.PowerShell);
        script.Should().Contain("dotnet run --project Seevalocal.Cli");
    }

    [Fact]
    public void Export_PowerShell_ContainsStopProcess()
    {
        var script = _exporter.Export(ManagedConfig(), ShellTarget.PowerShell);
        script.Should().Contain("Stop-Process");
    }

    [Fact]
    public void Export_PowerShell_ContainsPassThru()
    {
        var script = _exporter.Export(ManagedConfig(), ShellTarget.PowerShell);
        script.Should().Contain("-PassThru");
    }

    [Fact]
    public void Export_PowerShell_Unmanaged_NoStartProcess()
    {
        var script = _exporter.Export(UnmanagedConfig(), ShellTarget.PowerShell);
        script.Should().NotContain("Start-Process");
    }

    // -------------------------------------------------------------------------
    // Bash escaping
    // -------------------------------------------------------------------------

    [Fact]
    public void Export_Bash_PathWithSpaces_IsQuoted()
    {
        var config = ManagedConfig() with
        {
            Server = new ServerConfig
            {
                Manage = true,
                Host = "127.0.0.1",
                Port = 8080,
                Model = new ModelSource
                {
                    Kind = ModelSourceKind.LocalFile,
                    FilePath = "/my models/phi 4.gguf",
                },
            },
        };

        var script = _exporter.Export(config, ShellTarget.Bash);

        script.Should().Contain("'");  // single-quoted
        script.Should().Contain("/my models/phi 4.gguf");
    }

    // -------------------------------------------------------------------------
    // HuggingFace model source
    // -------------------------------------------------------------------------

    [Fact]
    public void Export_Bash_HfModel_UsesHfFlags()
    {
        var config = ManagedConfig() with
        {
            Server = new ServerConfig
            {
                Manage = true,
                Host = "127.0.0.1",
                Port = 8080,
                Model = new ModelSource
                {
                    Kind = ModelSourceKind.HuggingFace,
                    HfRepo = "bartowski/phi-4-GGUF",
                    HfQuant = "phi-4-Q4_K_M.gguf",
                },
            },
        };

        var script = _exporter.Export(config, ShellTarget.Bash);

        script.Should().Contain("--hf-repo").And.Contain("bartowski/phi-4-GGUF");
        script.Should().Contain("--hf-file").And.Contain("phi-4-Q4_K_M.gguf");
    }
}
