using Microsoft.Extensions.Logging;
using Seevalocal.Core.Models;
using Seevalocal.DataSources.Internal;
using YamlDotNet.RepresentationModel;

namespace Seevalocal.DataSources.Sources;

internal sealed class YamlDataSource : IDataSource
{
    private readonly DataSourceConfig _config;
    private readonly ILogger _logger;

    public YamlDataSource(string name, DataSourceConfig config, ILogger logger)
    {
        Name = name;
        _config = config;
        _logger = logger;
    }

    public string Name { get; }

    public async IAsyncEnumerable<EvalItem> GetItemsAsync(
        [System.Runtime.CompilerServices.EnumeratorCancellation] CancellationToken ct)
    {
        var mapping = _config.FieldMapping ?? new FieldMapping();
        var filePath = Path.GetFullPath(_config.DataFilePath!);
        _logger.LogDebug("[{Name}] Loading YAML from {Path}", Name, filePath);

        var yaml = await File.ReadAllTextAsync(filePath, ct);
        var stream = new YamlStream();
        stream.Load(new StringReader(yaml));

        if (stream.Documents.Count == 0)
            yield break;

        var root = stream.Documents[0].RootNode;
        if (root is not YamlSequenceNode sequence)
            throw new InvalidDataException($"[{Name}] Expected a YAML sequence at root in {filePath}");

        int index = 0;
        foreach (var node in sequence.Children)
        {
            ct.ThrowIfCancellationRequested();
            if (node is not YamlMappingNode mapping_node)
                continue;

            yield return ParseNode(mapping_node, mapping, index++);
        }
    }

    private EvalItem ParseNode(YamlMappingNode node, FieldMapping mapping, int index)
    {
        var id = GetString(node, mapping.IdField) ?? IdGenerator.Generate(Name, index);
        var userPrompt = GetString(node, mapping.UserPromptField) ?? "";
        var expectedOutput = mapping.ExpectedOutputField is not null
            ? GetString(node, mapping.ExpectedOutputField)
            : null;
        var systemPrompt = mapping.SystemPromptField is not null
            ? GetString(node, mapping.SystemPromptField)
            : _config.DefaultSystemPrompt;

        var metadata = new Dictionary<string, string>();
        foreach (var field in mapping.MetadataFields)
        {
            var val = GetString(node, field);
            if (val is not null)
                metadata[field] = val;
        }

        return new EvalItem
        {
            Id = id,
            UserPrompt = userPrompt,
            ExpectedOutput = expectedOutput,
            SystemPrompt = systemPrompt,
            Metadata = metadata,
        };
    }

    private static string? GetString(YamlMappingNode node, string key)
    {
        var keyNode = new YamlScalarNode(key);
        if (node.Children.TryGetValue(keyNode, out var value) && value is YamlScalarNode scalar)
            return scalar.Value;
        return null;
    }

    public async Task<int?> GetCountAsync(CancellationToken ct)
    {
        if (_config.DataFilePath is null) return null;
        var filePath = Path.GetFullPath(_config.DataFilePath);
        if (!File.Exists(filePath)) return null;

        var yaml = await File.ReadAllTextAsync(filePath, ct);
        var stream = new YamlStream();
        stream.Load(new StringReader(yaml));
        if (stream.Documents.Count == 0) return 0;
        if (stream.Documents[0].RootNode is YamlSequenceNode seq)
            return seq.Children.Count;
        return null;
    }
}
