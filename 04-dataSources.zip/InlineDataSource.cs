using Microsoft.Extensions.Logging;
using Seevalocal.Core.Models;
using Seevalocal.DataSources.Internal;

namespace Seevalocal.DataSources.Sources;

internal sealed class InlineDataSource : IDataSource
{
    private readonly DataSourceConfig _config;
    private readonly ILogger _logger;

    public InlineDataSource(string name, DataSourceConfig config, ILogger logger)
    {
        Name = name;
        _config = config;
        _logger = logger;
    }

    public string Name { get; }

    public async IAsyncEnumerable<EvalItem> GetItemsAsync(
        [System.Runtime.CompilerServices.EnumeratorCancellation] CancellationToken ct)
    {
        var items = _config.InlineItems ?? [];
        int index = 0;
        foreach (var dto in items)
        {
            ct.ThrowIfCancellationRequested();

            var id = dto.Id ?? IdGenerator.Generate(Name, index);
            var systemPrompt = dto.SystemPrompt ?? _config.DefaultSystemPrompt;

            yield return new EvalItem
            {
                Id = id,
                UserPrompt = dto.UserPrompt,
                ExpectedOutput = dto.ExpectedOutput,
                SystemPrompt = systemPrompt,
                Metadata = dto.Metadata is not null
                    ? new Dictionary<string, string>(dto.Metadata)
                    : new Dictionary<string, string>(),
                ArtifactFilePath = dto.ArtifactFilePath,
            };

            index++;
        }

        await Task.CompletedTask; // satisfy async IAsyncEnumerable
    }

    public Task<int?> GetCountAsync(CancellationToken ct)
        => Task.FromResult<int?>(_config.InlineItems?.Count);
}
