using Microsoft.Extensions.Logging;
using Seevalocal.Core.Models;

namespace Seevalocal.DataSources.Internal;

/// <summary>
/// Wraps any IDataSource to apply post-processing:
/// - Template injection
/// - Shuffle (if configured)
/// - MaxItemCount limit
/// - Duplicate ID detection
/// </summary>
internal sealed class WrappedDataSource : IDataSource
{
    private readonly IDataSource _inner;
    private readonly DataSourceConfig _config;
    private readonly PromptTemplateEngine _templateEngine;
    private readonly ILogger _logger;

    public WrappedDataSource(
        IDataSource inner,
        DataSourceConfig config,
        PromptTemplateEngine templateEngine,
        ILogger logger)
    {
        _inner = inner;
        _config = config;
        _templateEngine = templateEngine;
        _logger = logger;
    }

    public string Name => _inner.Name;

    public async IAsyncEnumerable<EvalItem> GetItemsAsync(
        [System.Runtime.CompilerServices.EnumeratorCancellation] CancellationToken ct)
    {
        var seenIds = new HashSet<string>();
        int emitted = 0;

        // If shuffle is requested, we must buffer all items first
        if (_config.ShuffleRandomSeed.HasValue)
        {
            var buffer = new List<EvalItem>();
            await foreach (var item in _inner.GetItemsAsync(ct))
                buffer.Add(item);

            var rng = new Random(_config.ShuffleRandomSeed.Value);
            for (int i = buffer.Count - 1; i > 0; i--)
            {
                int j = rng.Next(i + 1);
                (buffer[i], buffer[j]) = (buffer[j], buffer[i]);
            }

            foreach (var item in buffer)
            {
                ct.ThrowIfCancellationRequested();
                if (_config.MaxItemCount.HasValue && emitted >= _config.MaxItemCount.Value)
                    yield break;

                var processed = ProcessItem(item, seenIds);
                if (processed is not null)
                {
                    yield return processed;
                    emitted++;
                }
            }
        }
        else
        {
            await foreach (var item in _inner.GetItemsAsync(ct))
            {
                ct.ThrowIfCancellationRequested();
                if (_config.MaxItemCount.HasValue && emitted >= _config.MaxItemCount.Value)
                    yield break;

                var processed = ProcessItem(item, seenIds);
                if (processed is not null)
                {
                    yield return processed;
                    emitted++;
                }
            }
        }
    }

    private EvalItem? ProcessItem(EvalItem item, HashSet<string> seenIds)
    {
        if (!seenIds.Add(item.Id))
        {
            throw new InvalidDataException(
                $"[DataSource:{Name}] Duplicate ID '{item.Id}' detected. " +
                "All IDs within a dataset must be unique.");
        }

        return _templateEngine.Apply(item, _config);
    }

    public Task<int?> GetCountAsync(CancellationToken ct)
    {
        if (_config.MaxItemCount.HasValue)
            return Task.FromResult<int?>(_config.MaxItemCount.Value);
        return _inner.GetCountAsync(ct);
    }
}
