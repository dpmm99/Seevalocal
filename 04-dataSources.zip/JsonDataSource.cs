using System.Text.Json;
using Microsoft.Extensions.Logging;
using Seevalocal.Core.Models;
using Seevalocal.DataSources.Internal;

namespace Seevalocal.DataSources.Sources;

internal sealed class JsonDataSource : IDataSource
{
    private readonly DataSourceConfig _config;
    private readonly bool _isJsonl;
    private readonly ILogger _logger;

    public JsonDataSource(string name, DataSourceConfig config, bool isJsonl, ILogger logger)
    {
        Name = name;
        _config = config;
        _isJsonl = isJsonl;
        _logger = logger;
    }

    public string Name { get; }

    public async IAsyncEnumerable<EvalItem> GetItemsAsync(
        [System.Runtime.CompilerServices.EnumeratorCancellation] CancellationToken ct)
    {
        var mapping = _config.FieldMapping ?? new FieldMapping();
        var filePath = Path.GetFullPath(_config.DataFilePath!);
        _logger.LogDebug("[{Name}] Loading from {Path} (jsonl={IsJsonl})", Name, filePath, _isJsonl);

        if (_isJsonl)
        {
            var lines = await File.ReadAllLinesAsync(filePath, ct);
            int index = 0;
            foreach (var line in lines)
            {
                ct.ThrowIfCancellationRequested();
                if (string.IsNullOrWhiteSpace(line)) continue;

                using var doc = JsonDocument.Parse(line);
                yield return ParseObject(doc.RootElement, mapping, index++);
            }
        }
        else
        {
            var json = await File.ReadAllTextAsync(filePath, ct);
            using var doc = JsonDocument.Parse(json);
            var root = doc.RootElement;
            if (root.ValueKind != JsonValueKind.Array)
                throw new InvalidDataException($"[{Name}] Expected a JSON array in {filePath}");

            int index = 0;
            foreach (var element in root.EnumerateArray())
            {
                ct.ThrowIfCancellationRequested();
                yield return ParseObject(element, mapping, index++);
            }
        }
    }

    private EvalItem ParseObject(JsonElement el, FieldMapping mapping, int index)
    {
        var id = GetString(el, mapping.IdField)
                 ?? IdGenerator.Generate(Name, index);

        var userPrompt = GetString(el, mapping.UserPromptField) ?? "";
        var expectedOutput = mapping.ExpectedOutputField is not null
            ? GetString(el, mapping.ExpectedOutputField)
            : null;
        var systemPrompt = mapping.SystemPromptField is not null
            ? GetString(el, mapping.SystemPromptField)
            : _config.DefaultSystemPrompt;

        var metadata = new Dictionary<string, string>();
        foreach (var field in mapping.MetadataFields)
        {
            var val = GetString(el, field);
            if (val is not null)
                metadata[field] = val;
        }

        return new EvalItem
        {
            Id = id,
            UserPrompt = userPrompt,
            ExpectedOutput = expectedOutput,
            SystemPrompt = systemPrompt,
            Metadata = metadata,
        };
    }

    private static string? GetString(JsonElement el, string key)
    {
        if (el.TryGetProperty(key, out var prop))
            return prop.ValueKind == JsonValueKind.Null ? null : prop.GetString();
        return null;
    }

    public async Task<int?> GetCountAsync(CancellationToken ct)
    {
        if (_config.DataFilePath is null) return null;
        var filePath = Path.GetFullPath(_config.DataFilePath);
        if (!File.Exists(filePath)) return null;

        if (_isJsonl)
        {
            var lines = await File.ReadAllLinesAsync(filePath, ct);
            return lines.Count(l => !string.IsNullOrWhiteSpace(l));
        }

        var json = await File.ReadAllTextAsync(filePath, ct);
        using var doc = JsonDocument.Parse(json);
        if (doc.RootElement.ValueKind == JsonValueKind.Array)
            return doc.RootElement.GetArrayLength();
        return null;
    }
}
