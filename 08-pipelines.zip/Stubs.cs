// ============================================================
// STUBS — These types will be removed once the corresponding
// sibling projects (Core, Config, Server, DataSources, Metrics,
// Judge) are implemented. They exist only so this project
// compiles standalone.
// ============================================================

// ---- Seevalocal.Core.Abstractions ----
namespace Seevalocal.Core.Abstractions
{
    public interface IEvalStage
    {
        string StageName { get; }
        Task<StageResult> ExecuteAsync(EvalStageContext context);
    }

    public record EvalStageContext
    {
        public required Core.Models.EvalItem Item { get; init; }
        public IReadOnlyDictionary<string, object?> StageOutputs { get; init; } = new Dictionary<string, object?>();
        public required Config.Models.ResolvedConfig Config { get; init; }
        public required Server.Client.LlamaServerClient PrimaryClient { get; init; }
        public Server.Client.LlamaServerClient? JudgeClient { get; init; }
        public CancellationToken CancellationToken { get; init; }
    }

    public record StageResult
    {
        public IReadOnlyDictionary<string, object?> Outputs { get; init; } = new Dictionary<string, object?>();
        public IReadOnlyList<Core.Models.MetricValue> Metrics { get; init; } = [];
        public bool Succeeded { get; init; } = true;
        public string? FailureReason { get; init; }

        public static StageResult Success(
            IReadOnlyDictionary<string, object?> outputs,
            IReadOnlyList<Core.Models.MetricValue> metrics) =>
            new() { Outputs = outputs, Metrics = metrics, Succeeded = true };

        public static StageResult Failure(string reason) =>
            new() { Succeeded = false, FailureReason = reason };
    }

    public record EvalResult
    {
        public required string EvalItemId { get; init; }
        public required string EvalSetId { get; init; }
        public bool Succeeded { get; init; }
        public string? FailureReason { get; init; }
        public IReadOnlyList<Core.Models.MetricValue> Metrics { get; init; } = [];
        public IReadOnlyDictionary<string, object?> AllStageOutputs { get; init; } = new Dictionary<string, object?>();
        public DateTimeOffset StartedAt { get; init; }
        public double DurationSeconds { get; init; }
        public string? RawLlmResponse { get; init; }
    }

    public record EvalProgress
    {
        public required string EvalItemId { get; init; }
        public bool Succeeded { get; init; }
        public int CompletedCount { get; init; }
        public int TotalCount { get; init; }
        public double ElapsedSeconds { get; init; }
        public double? EstimatedRemainingSeconds { get; init; }
        public double? AverageCompletionTokensPerSecond { get; init; }
    }

    public interface IResultCollector
    {
        Task CollectAsync(EvalResult result, CancellationToken ct);
        Task FinalizeAsync(CancellationToken ct);
        IReadOnlyList<EvalResult> GetResults();
    }
}

// ---- Seevalocal.Core.Models ----
namespace Seevalocal.Core.Models
{
    public record EvalItem
    {
        public required string Id { get; init; }
        public string? SystemPrompt { get; init; }
        public required string UserPrompt { get; init; }
        public string? ExpectedOutput { get; init; }
        public IReadOnlyDictionary<string, string> Metadata { get; init; } = new Dictionary<string, string>();
        public string? ArtifactFilePath { get; init; }
    }

    public enum MetricType { Integer, Double, Boolean, String }

    public record MetricValue
    {
        public required string Name { get; init; }
        public required MetricType Type { get; init; }
        public int? IntValue { get; init; }
        public double? DoubleValue { get; init; }
        public bool? BoolValue { get; init; }
        public string? StringValue { get; init; }
        public object? RawValue => Type switch
        {
            MetricType.Integer => IntValue,
            MetricType.Double  => DoubleValue,
            MetricType.Boolean => BoolValue,
            MetricType.String  => StringValue,
            _ => null
        };
    }
}

// ---- Seevalocal.Config.Models ----
namespace Seevalocal.Config.Models
{
    public enum DataSourceKind { Directory, SplitDirectories, JsonFile, YamlFile, CsvFile, ParquetFile }

    public record FieldMapping
    {
        public string IdField { get; init; } = "id";
        public string UserPromptField { get; init; } = "prompt";
        public string? ExpectedOutputField { get; init; }
        public string? SystemPromptField { get; init; }
    }

    public record DataSourceConfig
    {
        public DataSourceKind Kind { get; init; }
        public string? PromptDirectoryPath { get; init; }
        public string? ExpectedOutputDirectoryPath { get; init; }
        public string? FileExtensionFilter { get; init; }
        public string? DataFilePath { get; init; }
        public FieldMapping? FieldMapping { get; init; }
    }

    public record EvalSetConfig
    {
        public required string Id { get; init; }
        public required string PipelineName { get; init; }
        public DataSourceConfig? DataSource { get; init; }
        public IDictionary<string, object?>? PipelineOptions { get; init; }
    }

    public record RunConfig
    {
        public string? Id { get; init; }
        public bool ContinueOnEvalFailure { get; init; } = true;
        public int? MaxConcurrentEvals { get; init; }
    }

    public record JudgeConfig
    {
        public string? BaseUrl { get; init; }
        public string? ApiKey { get; init; }
    }

    public record ServerConfig
    {
        public bool Manage { get; init; }
        public string? ExecutablePath { get; init; }
        public string Host { get; init; } = "127.0.0.1";
        public int Port { get; init; } = 8080;
        public string? ApiKey { get; init; }
    }

    public record ResolvedConfig
    {
        public RunConfig? Run { get; init; }
        public ServerConfig? Server { get; init; }
        public JudgeConfig? Judge { get; init; }
        public IReadOnlyList<EvalSetConfig> EvalSets { get; init; } = [];
    }

    public record PipelineConfig { }
    public record ValidationError(string Field, string MessageText);
    public enum ShellTarget { Bash, PowerShell }
}

// ---- Seevalocal.Server.Models ----
namespace Seevalocal.Server.Models
{
    public enum GpuKind { Cuda, Vulkan, Metal, CpuOnly }

    public record ChatMessage
    {
        public required string Role { get; init; }
        public required string Content { get; init; }
    }

    public record ChatCompletionRequest
    {
        public IReadOnlyList<ChatMessage> Messages { get; init; } = [];
    }

    public record ChatUsage
    {
        public int PromptTokens { get; init; }
        public int CompletionTokens { get; init; }
    }

    public record ChatTimings
    {
        public double? PredictedMs { get; init; }
        public double? PredictedPerSecond { get; init; }
    }

    public record ChatChoice
    {
        public ChatMessage? Message { get; init; }
    }

    public record ChatCompletionResponse
    {
        public IReadOnlyList<ChatChoice>? Choices { get; init; }
        public ChatUsage? Usage { get; init; }
        public ChatTimings? Timings { get; init; }
    }

    public record ServerProps
    {
        public int TotalSlots { get; init; }
    }

    public record ServerInfo
    {
        public required string BaseUrl { get; init; }
        public string? ApiKey { get; init; }
        public int TotalSlots { get; init; }
        public string ModelAlias { get; init; } = "";
    }

    public enum HealthStatus { Ok, Loading, Error }
    public record TokenizeResponse { public IReadOnlyList<int> Tokens { get; init; } = []; }
}

// ---- Seevalocal.Server.Client ----
namespace Seevalocal.Server.Client
{
    using FluentResults;
    using Seevalocal.Server.Models;
    using Microsoft.Extensions.Logging;

    public sealed class LlamaServerClient
    {
        public LlamaServerClient(ServerInfo serverInfo, HttpClient httpClient, ILogger<LlamaServerClient> logger) { }
        public Task<Result<ChatCompletionResponse>> ChatCompletionAsync(ChatCompletionRequest request, CancellationToken ct)
            => Task.FromResult(Result.Fail<ChatCompletionResponse>("Stub"));
        public Task<Result<ServerProps>> GetPropsAsync(CancellationToken ct)
            => Task.FromResult(Result.Ok(new ServerProps { TotalSlots = 1 }));
        public Task<Result<HealthStatus>> GetHealthAsync(CancellationToken ct)
            => Task.FromResult(Result.Ok(HealthStatus.Ok));
        public Task<Result<TokenizeResponse>> TokenizeAsync(string content, bool addSpecial, CancellationToken ct)
            => Task.FromResult(Result.Ok(new TokenizeResponse()));
    }
}

// ---- Seevalocal.DataSources ----
namespace Seevalocal.DataSources
{
    using Seevalocal.Core.Models;

    public interface IDataSource
    {
        string Name { get; }
        IAsyncEnumerable<EvalItem> GetItemsAsync(CancellationToken ct);
        Task<int?> GetCountAsync(CancellationToken ct);
    }
}

// ---- Seevalocal.Metrics.Writers ----
namespace Seevalocal.Metrics.Writers
{
    using Seevalocal.Core.Abstractions;
    public interface IResultWriter
    {
        Task WriteResultAsync(EvalResult result, CancellationToken ct);
        Task WriteSummaryAsync(object summary, CancellationToken ct);
        Task FinalizeAsync(CancellationToken ct);
    }
}

// ---- Seevalocal.Judge ----
namespace Seevalocal.Judge
{
    using Microsoft.Extensions.Logging;
    using Seevalocal.Core.Abstractions;
    using Seevalocal.Core.Models;
    using System.Text.RegularExpressions;

    /// <summary>Default judge prompt templates.</summary>
    public static class DefaultTemplates
    {
        public const string TranslationJudgeTemplate =
            "You are a translation quality evaluator.\n" +
            "Source text: {{source}}\n" +
            "Reference translation: {{reference}}\n" +
            "Model translation: {{response}}\n\n" +
            "Rate the translation accuracy and naturalness on a scale of 0 to {{maxScore}}.\n" +
            "Respond with ONLY a number.";

        public const string CasualQAJudgeTemplate =
            "You are a Q&A quality evaluator.\n" +
            "Question: {{prompt}}\n" +
            "Reference answer: {{reference}}\n" +
            "Model answer: {{response}}\n\n" +
            "Rate the answer accuracy and completeness on a scale of 0 to {{maxScore}}.\n" +
            "Respond with ONLY a number.";

        public const string CodeQualityJudgeTemplate =
            "You are a C# code quality evaluator.\n" +
            "Task: {{prompt}}\n" +
            "Generated code:\n{{response}}\n\n" +
            "Rate the code quality, style, and correctness on a scale of 0 to {{maxScore}}.\n" +
            "Respond with ONLY a number.";
    }

    public record ParsedJudgeResponse
    {
        public double ScoreRatio { get; init; }
        public bool Passed { get; init; }
        public string RawResponse { get; init; } = "";
    }

    /// <summary>
    /// Sends (prompt, reference, response) to the judge LLM and parses a numeric score.
    /// </summary>
    public sealed class JudgeStage : IEvalStage
    {
        public string StageName => "JudgeStage";

        private readonly string _promptTemplate;
        private readonly int _maxScore;
        private readonly double _passThresholdRatio;
        private readonly ILogger<JudgeStage> _logger;

        public JudgeStage(
            ILogger<JudgeStage> logger,
            string promptTemplate,
            int maxScore = 10,
            double passThresholdRatio = 0.6)
        {
            _logger = logger;
            _promptTemplate = promptTemplate;
            _maxScore = maxScore;
            _passThresholdRatio = passThresholdRatio;
        }

        public async Task<StageResult> ExecuteAsync(EvalStageContext context)
        {
            if (context.JudgeClient is null)
            {
                const string reason = "[JudgeStage] No judge client configured.";
                _logger.LogError("Item {ItemId}: {Reason}", context.Item.Id, reason);
                return StageResult.Failure(reason);
            }

            var item = context.Item;
            var response = context.StageOutputs.TryGetValue("PromptStage.response", out var r) ? r as string ?? "" : "";

            var judgePrompt = _promptTemplate
                .Replace("{{source}}",    item.UserPrompt)
                .Replace("{{prompt}}",    item.UserPrompt)
                .Replace("{{reference}}", item.ExpectedOutput ?? "")
                .Replace("{{response}}", response)
                .Replace("{{maxScore}}", _maxScore.ToString());

            var request = new Server.Models.ChatCompletionRequest
            {
                Messages = [new Server.Models.ChatMessage { Role = "user", Content = judgePrompt }]
            };

            var result = await context.JudgeClient.ChatCompletionAsync(request, context.CancellationToken);
            if (result.IsFailed)
            {
                var reason = $"[JudgeStage] Judge call failed: {result.Errors.FirstOrDefault()?.Message}";
                _logger.LogError("Item {ItemId}: {Reason}", item.Id, reason);
                return StageResult.Failure(reason);
            }

            var rawJudgeResponse = result.Value.Choices?.FirstOrDefault()?.Message?.Content ?? "";
            var parsed = ParseScore(rawJudgeResponse, _maxScore, _passThresholdRatio);

            if (parsed is null)
            {
                var reason = $"[JudgeResponseParser] Could not extract numeric score from judge response: \"{rawJudgeResponse}\"";
                _logger.LogError("Item {ItemId}: {Reason}", item.Id, reason);
                return StageResult.Failure(reason);
            }

            var outputs = new Dictionary<string, object?>
            {
                [$"{StageName}.rawResponse"]    = rawJudgeResponse,
                [$"{StageName}.scoreRatio"]     = parsed.ScoreRatio,
                [$"{StageName}.passed"]         = parsed.Passed,
            };

            var metrics = new List<MetricValue>
            {
                new() { Name = "judgeScoreRatio",  Type = MetricType.Double,  DoubleValue = parsed.ScoreRatio },
                new() { Name = "judgePassedBool",  Type = MetricType.Boolean, BoolValue   = parsed.Passed },
            };

            _logger.LogDebug(
                "Item {ItemId}: JudgeStage score={ScoreRatio:F2} passed={Passed}",
                item.Id, parsed.ScoreRatio, parsed.Passed);

            return StageResult.Success(outputs, metrics);
        }

        internal static ParsedJudgeResponse? ParseScore(string raw, int maxScore, double passThreshold)
        {
            var match = Regex.Match(raw.Trim(), @"(\d+(?:\.\d+)?)");
            if (!match.Success || !double.TryParse(match.Groups[1].Value, out double score))
                return null;

            double ratio = maxScore > 0 ? score / maxScore : 0;
            return new ParsedJudgeResponse
            {
                ScoreRatio   = ratio,
                Passed       = ratio >= passThreshold,
                RawResponse  = raw,
            };
        }
    }
}
