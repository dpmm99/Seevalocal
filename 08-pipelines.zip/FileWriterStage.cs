using Microsoft.Extensions.Logging;
using Seevalocal.Core.Abstractions;
using Seevalocal.Core.Models;

namespace Seevalocal.Pipelines.Stages;

/// <summary>
/// Writes the LLM response from <c>PromptStage.response</c> to a file.
/// Strips leading/trailing markdown code fences (```lang ... ```) before writing.
/// </summary>
public sealed class FileWriterStage : IEvalStage
{
    public string StageName => "FileWriterStage";

    private readonly string _targetFilePath;
    private readonly ILogger<FileWriterStage> _logger;

    /// <param name="targetFilePath">Absolute path to the file to write.</param>
    public FileWriterStage(string targetFilePath, ILogger<FileWriterStage> logger)
    {
        _targetFilePath = targetFilePath;
        _logger = logger;
    }

    public async Task<StageResult> ExecuteAsync(EvalStageContext context)
    {
        var rawResponse = context.StageOutputs.TryGetValue("PromptStage.response", out var r)
            ? r as string ?? ""
            : "";

        var code = StripMarkdownFences(rawResponse);
        int codeLineCount = code
            .Split('\n', StringSplitOptions.None)
            .Count(l => !string.IsNullOrWhiteSpace(l));

        try
        {
            var dir = Path.GetDirectoryName(_targetFilePath);
            if (!string.IsNullOrEmpty(dir))
                Directory.CreateDirectory(dir);

            await File.WriteAllTextAsync(_targetFilePath, code, context.CancellationToken);
        }
        catch (Exception ex)
        {
            var reason = $"[FileWriterStage] Failed to write file '{_targetFilePath}': {ex.Message}";
            _logger.LogError("Item {ItemId}: {Reason}", context.Item.Id, reason);
            return StageResult.Failure(reason);
        }

        var outputs = new Dictionary<string, object?>
        {
            [$"{StageName}.writtenFilePath"] = _targetFilePath,
            [$"{StageName}.codeLineCount"] = codeLineCount,
        };

        var metrics = new List<MetricValue>
        {
            new() { Name = "codeLineCount", Type = MetricType.Integer, IntValue = codeLineCount },
        };

        _logger.LogDebug(
            "Item {ItemId}: Wrote {LineCount} non-blank lines to '{FilePath}'",
            context.Item.Id, codeLineCount, _targetFilePath);

        return StageResult.Success(outputs, metrics);
    }

    /// <summary>
    /// Removes a single leading ```[lang] fence and trailing ``` fence if present.
    /// </summary>
    internal static string StripMarkdownFences(string content)
    {
        var trimmed = content.Trim();
        if (!trimmed.StartsWith("```"))
            return trimmed;

        // Remove the opening fence line (```csharp, ```cs, ```, etc.)
        var firstNewline = trimmed.IndexOf('\n');
        if (firstNewline < 0)
            return trimmed; // Only one line starting with ``` — nothing to strip

        var afterOpenFence = trimmed[(firstNewline + 1)..];

        // Remove the closing ``` if present
        var lastFenceIdx = afterOpenFence.LastIndexOf("```", StringComparison.Ordinal);
        if (lastFenceIdx >= 0)
            afterOpenFence = afterOpenFence[..lastFenceIdx];

        return afterOpenFence.Trim();
    }
}
