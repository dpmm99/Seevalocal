using Microsoft.Extensions.Logging;
using Seevalocal.Config.Models;
using Seevalocal.Judge;
using Seevalocal.Pipelines.Stages;

namespace Seevalocal.Pipelines.Factories;

/// <summary>
/// Builds a pipeline that evaluates C# code generation by compiling and running unit tests.
/// Stages: PromptStage → FileWriterStage → CompileStage → TestStage → JudgeStage (optional)
/// </summary>
public sealed class CSharpCodingPipelineFactory : IBuiltinPipelineFactory
{
    public string PipelineName => "CSharpCoding";
    public string Description => "Evaluates C# code generation quality by compiling the output and running unit tests.";

    private readonly ILoggerFactory _loggerFactory;

    public CSharpCodingPipelineFactory(ILoggerFactory loggerFactory)
    {
        _loggerFactory = loggerFactory;
    }

    public DataSourceConfig DefaultDataSourceConfig => new()
    {
        Kind = DataSourceKind.Directory,
        PromptDirectoryPath = "./data/prompts",
    };

    public IReadOnlyList<ValidationError> Validate(EvalSetConfig evalSetConfig)
    {
        var errors = new List<ValidationError>();
        var opts = evalSetConfig.PipelineOptions;
        if (opts is null) return errors;

        if (opts.TryGetValue("compileTimeoutSeconds", out var cts))
        {
            if (cts is not double and not int and not string)
                errors.Add(new ValidationError("pipelineOptions.compileTimeoutSeconds", "Must be a numeric value."));
        }
        if (opts.TryGetValue("testTimeoutSeconds", out var tts))
        {
            if (tts is not double and not int and not string)
                errors.Add(new ValidationError("pipelineOptions.testTimeoutSeconds", "Must be a numeric value."));
        }

        return errors;
    }

    public EvalPipeline Create(EvalSetConfig evalSetConfig, ResolvedConfig resolvedConfig)
    {
        var opts = evalSetConfig.PipelineOptions ?? new Dictionary<string, object?>();

        double compileTimeoutSeconds = ParseDouble(opts, "compileTimeoutSeconds", 30.0);
        double testTimeoutSeconds    = ParseDouble(opts, "testTimeoutSeconds",    60.0);
        bool cleanupOnSuccess        = ParseBool(opts, "cleanupTempFilesOnSuccess", true);
        bool cleanupOnFailure        = ParseBool(opts, "cleanupTempFilesOnFailure", false);
        bool scoreWithJudge          = ParseBool(opts, "scoreStyleWithJudge", false);

        string templatePath = opts.GetValueOrDefault("testProjectTemplatePath") as string
            ?? Path.Combine(AppContext.BaseDirectory, "templates", "csharp-test-skeleton");

        // Temp dir per eval item — use item ID at execution time
        // We build the stages with a placeholder; the actual path is resolved in EvalPipeline.RunItemAsync
        // via context. Because the temp path depends on item.Id, we use a factory lambda approach.
        //
        // For simplicity, the temp directory root is fixed and the item ID sub-folder is applied at
        // FileWriterStage and ExternalProcessStage construction time inside a custom composite stage.

        var stages = new List<Core.Abstractions.IEvalStage>
        {
            new PromptStage(_loggerFactory.CreateLogger<PromptStage>()),
            new CSharpEvalSetupStage(
                templatePath,
                compileTimeoutSeconds,
                testTimeoutSeconds,
                cleanupOnSuccess,
                cleanupOnFailure,
                _loggerFactory),
        };

        if (scoreWithJudge)
        {
            stages.Add(new JudgeStage(
                _loggerFactory.CreateLogger<JudgeStage>(),
                promptTemplate: DefaultTemplates.CodeQualityJudgeTemplate,
                maxScore: 10,
                passThresholdRatio: 0.6));
        }

        return new EvalPipeline
        {
            PipelineName = PipelineName,
            Stages = stages,
        };
    }

    /// <summary>
    /// Checks that dotnet is on PATH and that the template project compiles.
    /// </summary>
    public async Task<FluentResults.Result> EnsurePrerequisitesAsync(
        EvalSetConfig evalSetConfig,
        ResolvedConfig resolvedConfig,
        CancellationToken ct)
    {
        // Check dotnet on PATH
        var psi = new System.Diagnostics.ProcessStartInfo
        {
            FileName = "dotnet",
            Arguments = "--version",
            UseShellExecute = false,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            CreateNoWindow = true,
        };

        try
        {
            using var p = System.Diagnostics.Process.Start(psi)!;
            await p.WaitForExitAsync(ct);
            if (p.ExitCode != 0)
                return FluentResults.Result.Fail(
                    "[CSharpCodingPipelineFactory] 'dotnet --version' returned non-zero exit code. " +
                    "Install .NET SDK from https://dotnet.microsoft.com/download");
        }
        catch (Exception ex)
        {
            return FluentResults.Result.Fail(
                "[CSharpCodingPipelineFactory] 'dotnet' is not on PATH or could not be executed: " +
                $"{ex.Message}. Install .NET SDK from https://dotnet.microsoft.com/download");
        }

        return FluentResults.Result.Ok();
    }

    private static double ParseDouble(IDictionary<string, object?> opts, string key, double fallback)
    {
        if (!opts.TryGetValue(key, out var raw) || raw is null) return fallback;
        return raw switch
        {
            double d => d,
            int i    => i,
            string s when double.TryParse(s, out var p) => p,
            _ => fallback,
        };
    }

    private static bool ParseBool(IDictionary<string, object?> opts, string key, bool fallback)
    {
        if (!opts.TryGetValue(key, out var raw) || raw is null) return fallback;
        return raw switch
        {
            bool b   => b,
            string s => bool.TryParse(s, out var p) ? p : fallback,
            _        => fallback,
        };
    }
}
