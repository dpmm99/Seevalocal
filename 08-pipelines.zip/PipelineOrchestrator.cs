using System.Threading.Channels;
using Microsoft.Extensions.Logging;
using Seevalocal.Config.Models;
using Seevalocal.Core.Abstractions;
using Seevalocal.DataSources;
using Seevalocal.Metrics.Writers;
using Seevalocal.Server.Client;

namespace Seevalocal.Pipelines;

/// <summary>
/// Drains a <see cref="IDataSource"/> through an <see cref="EvalPipeline"/> with bounded concurrency.
/// Progress events are published for each completed item.
/// </summary>
public sealed class PipelineOrchestrator
{
    private readonly EvalPipeline _pipeline;
    private readonly IDataSource _dataSource;
    private readonly IResultCollector _collector;
    private readonly ResolvedConfig _config;
    private readonly LlamaServerClient _primaryClient;
    private readonly LlamaServerClient? _judgeClient;
    private readonly ILogger<PipelineOrchestrator> _logger;

    public event Action<EvalProgress>? ProgressChanged;

    public PipelineOrchestrator(
        EvalPipeline pipeline,
        IDataSource dataSource,
        IResultCollector collector,
        ResolvedConfig config,
        LlamaServerClient primaryClient,
        LlamaServerClient? judgeClient,
        ILogger<PipelineOrchestrator> logger)
    {
        _pipeline = pipeline;
        _dataSource = dataSource;
        _collector = collector;
        _config = config;
        _primaryClient = primaryClient;
        _judgeClient = judgeClient;
        _logger = logger;
    }

    /// <summary>
    /// Run the full pipeline. Returns all collected results.
    /// </summary>
    public async Task<IReadOnlyList<EvalResult>> RunAsync(
        int maxConcurrentEvals,
        CancellationToken ct)
    {
        _logger.LogInformation(
            "Pipeline '{PipelineName}' starting. MaxConcurrency={MaxConcurrency}",
            _pipeline.PipelineName, maxConcurrentEvals);

        var totalCount = await _dataSource.GetCountAsync(ct);
        var overallSw = System.Diagnostics.Stopwatch.StartNew();
        int completedCount = 0;
        var completedTokensPerSecondSum = 0.0;
        int completedWithTokens = 0;

        var channel = Channel.CreateUnbounded<Core.Models.EvalItem>(
            new UnboundedChannelOptions { SingleWriter = true });

        // Producer: stream items into channel
        var producer = Task.Run(async () =>
        {
            try
            {
                await foreach (var item in _dataSource.GetItemsAsync(ct))
                    await channel.Writer.WriteAsync(item, ct);
            }
            finally
            {
                channel.Writer.Complete();
            }
        }, ct);

        var semaphore = new SemaphoreSlim(maxConcurrentEvals, maxConcurrentEvals);
        var consumerTasks = new List<Task>();

        await foreach (var item in channel.Reader.ReadAllAsync(ct))
        {
            await semaphore.WaitAsync(ct);

            var capturedItem = item;
            consumerTasks.Add(Task.Run(async () =>
            {
                try
                {
                    var context = new EvalStageContext
                    {
                        Item = capturedItem,
                        Config = _config,
                        PrimaryClient = _primaryClient,
                        JudgeClient = _judgeClient,
                        CancellationToken = ct
                    };

                    _logger.LogDebug(
                        "Pipeline '{PipelineName}' starting item '{ItemId}'",
                        _pipeline.PipelineName, capturedItem.Id);

                    bool continueOnStageFailure = _config.Run?.ContinueOnEvalFailure ?? true;
                    var result = await _pipeline.RunItemAsync(
                        context,
                        continueOnStageFailure,
                        _config.Run?.Id ?? "");

                    await _collector.CollectAsync(result, ct);

                    int done = Interlocked.Increment(ref completedCount);

                    // Estimate tokens/s for progress (optional)
                    var tpsMetric = result.Metrics
                        .FirstOrDefault(m => m.Name == "promptTokensPerSecond");

                    double? avgTps = null;
                    if (tpsMetric is not null && tpsMetric.DoubleValue.HasValue)
                    {
                        completedWithTokens++;
                        completedTokensPerSecondSum += tpsMetric.DoubleValue.Value;
                        avgTps = completedTokensPerSecondSum / completedWithTokens;
                    }

                    double elapsed = overallSw.Elapsed.TotalSeconds;
                    double? remaining = totalCount.HasValue && done > 0
                        ? (elapsed / done) * (totalCount.Value - done)
                        : null;

                    ProgressChanged?.Invoke(new EvalProgress
                    {
                        EvalItemId = capturedItem.Id,
                        Succeeded = result.Succeeded,
                        CompletedCount = done,
                        TotalCount = totalCount ?? -1,
                        ElapsedSeconds = elapsed,
                        EstimatedRemainingSeconds = remaining,
                        AverageCompletionTokensPerSecond = avgTps
                    });

                    _logger.LogDebug(
                        "Pipeline '{PipelineName}' completed item '{ItemId}' in {DurationSeconds:F2}s. Succeeded={Succeeded}",
                        _pipeline.PipelineName, capturedItem.Id, result.DurationSeconds, result.Succeeded);
                }
                finally
                {
                    semaphore.Release();
                }
            }, ct));
        }

        await producer;
        await Task.WhenAll(consumerTasks);
        await _collector.FinalizeAsync(ct);

        overallSw.Stop();
        _logger.LogInformation(
            "Pipeline '{PipelineName}' finished. {CompletedCount} items in {DurationSeconds:F2}s",
            _pipeline.PipelineName, completedCount, overallSw.Elapsed.TotalSeconds);

        return _collector.GetResults();
    }
}
