using Microsoft.Extensions.Logging;
using Seevalocal.Config.Models;
using Seevalocal.Judge;
using Seevalocal.Pipelines.Stages;

namespace Seevalocal.Pipelines.Factories;

/// <summary>
/// Builds a pipeline that evaluates language translation quality.
/// Stages: PromptStage → JudgeStage
/// </summary>
public sealed class TranslationPipelineFactory : IBuiltinPipelineFactory
{
    public string PipelineName => "Translation";
    public string Description => "Evaluates language translation quality using LLM-as-judge for accuracy scoring.";

    private readonly ILoggerFactory _loggerFactory;

    public TranslationPipelineFactory(ILoggerFactory loggerFactory)
    {
        _loggerFactory = loggerFactory;
    }

    public DataSourceConfig DefaultDataSourceConfig => new()
    {
        Kind = DataSourceKind.SplitDirectories,
        PromptDirectoryPath = "./data/source",
        ExpectedOutputDirectoryPath = "./data/reference",
        FileExtensionFilter = "*.txt",
    };

    public IReadOnlyList<ValidationError> Validate(EvalSetConfig evalSetConfig)
    {
        var errors = new List<ValidationError>();
        var opts = evalSetConfig.PipelineOptions;

        if (opts is not null)
        {
            if (opts.TryGetValue("sourceLanguage", out var src) && src is not string)
                errors.Add(new ValidationError("pipelineOptions.sourceLanguage", "Must be a string value."));
            if (opts.TryGetValue("targetLanguage", out var tgt) && tgt is not string)
                errors.Add(new ValidationError("pipelineOptions.targetLanguage", "Must be a string value."));
        }

        return errors;
    }

    public EvalPipeline Create(EvalSetConfig evalSetConfig, ResolvedConfig resolvedConfig)
    {
        var opts = evalSetConfig.PipelineOptions;
        string sourceLanguage = opts?.GetValueOrDefault("sourceLanguage") as string ?? "English";
        string targetLanguage = opts?.GetValueOrDefault("targetLanguage") as string ?? "French";
        string? judgePromptTemplate = opts?.GetValueOrDefault("judgePromptTemplate") as string;

        string systemPrompt =
            "You are a professional translator. " +
            $"Translate the following text from {sourceLanguage} to {targetLanguage} accurately and naturally. " +
            "Output only the translation, with no explanation or preamble.";

        var promptStage = new PromptStage(
            _loggerFactory.CreateLogger<PromptStage>(),
            systemPromptOverride: systemPrompt);

        var judgeStage = new JudgeStage(
            _loggerFactory.CreateLogger<JudgeStage>(),
            promptTemplate: judgePromptTemplate ?? DefaultTemplates.TranslationJudgeTemplate,
            maxScore: 10,
            passThresholdRatio: 0.6);

        return new EvalPipeline
        {
            PipelineName = PipelineName,
            Stages = [promptStage, judgeStage],
        };
    }

    /// <summary>
    /// Checks that the judge endpoint is configured and that the data directories exist.
    /// </summary>
    public async Task<FluentResults.Result> EnsurePrerequisitesAsync(
        EvalSetConfig evalSetConfig,
        ResolvedConfig resolvedConfig,
        CancellationToken ct)
    {
        var errors = new List<string>();

        if (resolvedConfig.Judge is null)
            errors.Add("[TranslationPipelineFactory] Judge endpoint is not configured. Set 'judge' in settings.");

        var sourceDir = evalSetConfig.DataSource?.PromptDirectoryPath ?? "./data/source";
        var refDir = evalSetConfig.DataSource?.ExpectedOutputDirectoryPath ?? "./data/reference";

        if (!Directory.Exists(sourceDir))
            errors.Add($"[TranslationPipelineFactory] Source directory not found: {Path.GetFullPath(sourceDir)}");
        if (!Directory.Exists(refDir))
            errors.Add($"[TranslationPipelineFactory] Reference directory not found: {Path.GetFullPath(refDir)}");

        if (errors.Count > 0)
            return FluentResults.Result.Fail(errors);

        return FluentResults.Result.Ok();
    }
}
