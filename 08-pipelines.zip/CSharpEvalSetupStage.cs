using Microsoft.Extensions.Logging;
using Seevalocal.Core.Abstractions;
using Seevalocal.Core.Models;
using Seevalocal.Pipelines.Stages;

namespace Seevalocal.Pipelines.Factories;

/// <summary>
/// Composite stage for the C# coding pipeline that:
/// 1. Copies the template project to a per-item temp directory.
/// 2. Writes the generated code to Generated.cs (via FileWriterStage).
/// 3. Optionally copies the item's test file.
/// 4. Runs dotnet build (CompileStage).
/// 5. Runs dotnet test (TestStage).
/// 6. Optionally cleans up the temp directory.
///
/// This stage is self-contained so that the temp path can use the item ID.
/// </summary>
internal sealed class CSharpEvalSetupStage : IEvalStage
{
    public string StageName => "CSharpEvalSetupStage";

    private readonly string _templatePath;
    private readonly double _compileTimeoutSeconds;
    private readonly double _testTimeoutSeconds;
    private readonly bool _cleanupOnSuccess;
    private readonly bool _cleanupOnFailure;
    private readonly ILoggerFactory _loggerFactory;

    public CSharpEvalSetupStage(
        string templatePath,
        double compileTimeoutSeconds,
        double testTimeoutSeconds,
        bool cleanupOnSuccess,
        bool cleanupOnFailure,
        ILoggerFactory loggerFactory)
    {
        _templatePath = templatePath;
        _compileTimeoutSeconds = compileTimeoutSeconds;
        _testTimeoutSeconds = testTimeoutSeconds;
        _cleanupOnSuccess = cleanupOnSuccess;
        _cleanupOnFailure = cleanupOnFailure;
        _loggerFactory = loggerFactory;
    }

    public async Task<StageResult> ExecuteAsync(EvalStageContext context)
    {
        var item = context.Item;
        var ct = context.CancellationToken;

        // Per-item temp directory
        string tempRoot = Path.Combine(Path.GetTempPath(), "seevalocal-csharp");
        string evalDir  = Path.Combine(tempRoot, $"eval-{item.Id}");
        string generatedCsPath = Path.Combine(evalDir, "Generated.cs");
        string testSuiteSource  = item.Metadata.TryGetValue("testFilePath", out var tf) ? tf : null!;

        bool succeeded = false;
        var allOutputs = new Dictionary<string, object?>();
        var allMetrics = new List<MetricValue>();

        try
        {
            // 1. Copy template
            CopyDirectory(_templatePath, evalDir);

            // 2. Copy test suite if specified
            if (!string.IsNullOrEmpty(testSuiteSource) && File.Exists(testSuiteSource))
            {
                string destTestsDir = Path.Combine(evalDir, "Tests");
                Directory.CreateDirectory(destTestsDir);
                File.Copy(testSuiteSource, Path.Combine(destTestsDir, "TestSuite.cs"), overwrite: true);
            }

            // 3. Write generated code
            var fileWriter = new FileWriterStage(generatedCsPath, _loggerFactory.CreateLogger<FileWriterStage>());
            var writeResult = await fileWriter.ExecuteAsync(context);
            if (!writeResult.Succeeded)
                return writeResult;
            MergeInto(allOutputs, allMetrics, writeResult);

            // 4. CompileStage
            var compileStage = BuildCompileStage(evalDir);
            var compileCtx = context with { StageOutputs = allOutputs };
            var compileResult = await compileStage.ExecuteAsync(compileCtx);
            MergeInto(allOutputs, allMetrics, compileResult);

            if (!compileResult.Succeeded)
            {
                return StageResult.Success(allOutputs, allMetrics) with
                {
                    Succeeded = false,
                    FailureReason = compileResult.FailureReason
                };
            }

            // 5. TestStage
            var testStage = BuildTestStage(evalDir);
            var testCtx = context with { StageOutputs = allOutputs };
            var testResult = await testStage.ExecuteAsync(testCtx);
            MergeInto(allOutputs, allMetrics, testResult);

            // Derived test metrics
            int pass  = (allOutputs.GetValueOrDefault("TestStage.testPassCount")  as int?) ?? 0;
            int fail  = (allOutputs.GetValueOrDefault("TestStage.testFailCount")  as int?) ?? 0;
            int skip  = (allOutputs.GetValueOrDefault("TestStage.testSkipCount")  as int?) ?? 0;
            int total = pass + fail + skip;
            double passPercent = total > 0 ? (double)pass / total * 100.0 : 0;

            allOutputs[$"{StageName}.testTotalCount"]       = total;
            allOutputs[$"{StageName}.testPassRatioPercent"] = passPercent;
            allMetrics.Add(new() { Name = "testTotalCount",       Type = MetricType.Integer, IntValue   = total });
            allMetrics.Add(new() { Name = "testPassRatioPercent", Type = MetricType.Double,  DoubleValue = passPercent });

            succeeded = testResult.Succeeded;
        }
        catch (Exception ex)
        {
            return StageResult.Failure($"[CSharpEvalSetupStage] Unexpected error for item '{item.Id}': {ex.Message}");
        }
        finally
        {
            // Cleanup
            bool doCleanup = succeeded ? _cleanupOnSuccess : _cleanupOnFailure;
            if (doCleanup && Directory.Exists(evalDir))
            {
                try { Directory.Delete(evalDir, recursive: true); }
                catch { /* best-effort */ }
            }
        }

        return new StageResult
        {
            Outputs = allOutputs,
            Metrics = allMetrics,
            Succeeded = succeeded,
        };
    }

    private ExternalProcessStage BuildCompileStage(string evalDir) =>
        new(
            stageName: "CompileStage",
            executable: "dotnet",
            arguments: "build --no-incremental -v minimal",
            workingDirectory: evalDir,
            timeoutSeconds: _compileTimeoutSeconds,
            extractors: new MetricExtractor[]
            {
                new BoolMetricExtractor("compilationSucceededBool", trueOnExitCodeZero: true),
                new RegexIntMetricExtractor("compilationErrorCount",   @"(\d+)\s+Error",   1),
                new RegexIntMetricExtractor("compilationWarningCount", @"(\d+)\s+Warning", 1),
            },
            logger: _loggerFactory.CreateLogger<ExternalProcessStage>());

    private ExternalProcessStage BuildTestStage(string evalDir) =>
        new(
            stageName: "TestStage",
            executable: "dotnet",
            arguments: "test --logger \"console;verbosity=normal\" --no-build",
            workingDirectory: evalDir,
            timeoutSeconds: _testTimeoutSeconds,
            extractors: new MetricExtractor[]
            {
                new RegexIntMetricExtractor("testPassCount", @"Passed:\s*(\d+)", 1),
                new RegexIntMetricExtractor("testFailCount", @"Failed:\s*(\d+)", 1),
                new RegexIntMetricExtractor("testSkipCount", @"Skipped:\s*(\d+)", 1),
            },
            logger: _loggerFactory.CreateLogger<ExternalProcessStage>());

    private static void CopyDirectory(string source, string destination)
    {
        Directory.CreateDirectory(destination);
        foreach (var file in Directory.GetFiles(source))
            File.Copy(file, Path.Combine(destination, Path.GetFileName(file)), overwrite: true);
        foreach (var dir in Directory.GetDirectories(source))
            CopyDirectory(dir, Path.Combine(destination, Path.GetFileName(dir)));
    }

    private static void MergeInto(
        Dictionary<string, object?> outputs,
        List<MetricValue> metrics,
        StageResult result)
    {
        foreach (var (k, v) in result.Outputs)
            outputs[k] = v;
        metrics.AddRange(result.Metrics);
    }
}
