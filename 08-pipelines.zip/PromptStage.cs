using Microsoft.Extensions.Logging;
using Seevalocal.Config.Models;
using Seevalocal.Core.Abstractions;
using Seevalocal.Core.Models;
using Seevalocal.Server.Models;

namespace Seevalocal.Pipelines.Stages;

/// <summary>
/// Sends the eval item's prompt to the primary LLM endpoint and captures
/// the response text, token counts, and latency.
/// </summary>
public sealed class PromptStage : IEvalStage
{
    public string StageName => "PromptStage";

    private readonly string? _systemPromptOverride;
    private readonly ILogger<PromptStage> _logger;

    /// <param name="systemPromptOverride">
    /// If non-null, used as the system prompt instead of <see cref="EvalItem.SystemPrompt"/>.
    /// </param>
    public PromptStage(ILogger<PromptStage> logger, string? systemPromptOverride = null)
    {
        _logger = logger;
        _systemPromptOverride = systemPromptOverride;
    }

    public async Task<StageResult> ExecuteAsync(EvalStageContext context)
    {
        var item = context.Item;
        var ct = context.CancellationToken;

        var systemPrompt = _systemPromptOverride ?? item.SystemPrompt;

        var messages = new List<ChatMessage>();
        if (!string.IsNullOrWhiteSpace(systemPrompt))
            messages.Add(new ChatMessage { Role = "system", Content = systemPrompt });
        messages.Add(new ChatMessage { Role = "user", Content = item.UserPrompt });

        var request = new ChatCompletionRequest
        {
            Messages = messages
        };

        var sw = System.Diagnostics.Stopwatch.StartNew();
        var result = await context.PrimaryClient.ChatCompletionAsync(request, ct);
        sw.Stop();

        if (result.IsFailed)
        {
            var reason = $"[PromptStage] Chat completion failed: {result.Errors.FirstOrDefault()?.Message}";
            _logger.LogError("Item {ItemId}: {Reason}", item.Id, reason);
            return StageResult.Failure(reason);
        }

        var response = result.Value;
        var content = response.Choices?.FirstOrDefault()?.Message?.Content ?? "";
        var usage = response.Usage;
        var timings = response.Timings;

        double llmLatencySeconds = sw.Elapsed.TotalSeconds;
        if (timings?.PredictedMs is double predictedMs && predictedMs > 0)
            llmLatencySeconds = predictedMs / 1000.0;

        double? tokensPerSecond = null;
        if (timings?.PredictedPerSecond is double tps && tps > 0)
            tokensPerSecond = tps;

        var metrics = new List<MetricValue>
        {
            new() { Name = "promptTokenCount",      Type = MetricType.Integer, IntValue     = usage?.PromptTokens },
            new() { Name = "completionTokenCount",   Type = MetricType.Integer, IntValue     = usage?.CompletionTokens },
            new() { Name = "llmLatencySeconds",      Type = MetricType.Double,  DoubleValue  = llmLatencySeconds },
        };

        if (tokensPerSecond.HasValue)
            metrics.Add(new() { Name = "promptTokensPerSecond", Type = MetricType.Double, DoubleValue = tokensPerSecond });

        var outputs = new Dictionary<string, object?>
        {
            [$"{StageName}.response"] = content,
            [$"{StageName}.promptTokenCount"] = usage?.PromptTokens,
            [$"{StageName}.completionTokenCount"] = usage?.CompletionTokens,
            [$"{StageName}.llmLatencySeconds"] = llmLatencySeconds,
        };

        _logger.LogDebug(
            "Item {ItemId}: PromptStage completed. Tokens: {Prompt}+{Completion}, Latency: {LatencySeconds:F2}s",
            item.Id, usage?.PromptTokens, usage?.CompletionTokens, llmLatencySeconds);

        return StageResult.Success(outputs, metrics);
    }
}
