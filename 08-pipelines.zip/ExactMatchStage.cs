using Microsoft.Extensions.Logging;
using Seevalocal.Core.Abstractions;
using Seevalocal.Core.Models;

namespace Seevalocal.Pipelines.Stages;

/// <summary>
/// Compares the primary LLM response against <see cref="EvalItem.ExpectedOutput"/>.
/// Produces a boolean metric indicating whether they match after normalization.
/// </summary>
public sealed class ExactMatchStage : IEvalStage
{
    public string StageName => "ExactMatchStage";

    private readonly bool _caseSensitive;
    private readonly ILogger<ExactMatchStage> _logger;

    public ExactMatchStage(ILogger<ExactMatchStage> logger, bool caseSensitive = false)
    {
        _logger = logger;
        _caseSensitive = caseSensitive;
    }

    public Task<StageResult> ExecuteAsync(EvalStageContext context)
    {
        var item = context.Item;

        if (item.ExpectedOutput is null)
        {
            _logger.LogDebug("Item {ItemId}: ExactMatchStage skipped — no expected output.", item.Id);
            return Task.FromResult(StageResult.Success(
                new Dictionary<string, object?> { [$"{StageName}.skipped"] = true },
                []));
        }

        var rawResponse = context.StageOutputs.TryGetValue("PromptStage.response", out var r)
            ? r as string ?? ""
            : "";

        var comparison = _caseSensitive ? StringComparison.Ordinal : StringComparison.OrdinalIgnoreCase;
        bool matched = string.Equals(
            Normalize(rawResponse),
            Normalize(item.ExpectedOutput),
            comparison);

        var outputs = new Dictionary<string, object?>
        {
            [$"{StageName}.matched"] = matched,
        };

        var metrics = new List<MetricValue>
        {
            new() { Name = "exactMatch", Type = MetricType.Boolean, BoolValue = matched },
        };

        _logger.LogDebug("Item {ItemId}: ExactMatch={Matched}", item.Id, matched);

        return Task.FromResult(StageResult.Success(outputs, metrics));
    }

    private static string Normalize(string s) => s.Trim();
}
