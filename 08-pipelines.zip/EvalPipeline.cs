using Seevalocal.Core.Abstractions;
using Seevalocal.Core.Models;

namespace Seevalocal.Pipelines;

/// <summary>
/// An ordered list of stages that together form an evaluation pipeline.
/// </summary>
public sealed class EvalPipeline
{
    public string PipelineName { get; init; } = "";
    public IReadOnlyList<IEvalStage> Stages { get; init; } = [];

    /// <summary>
    /// Run all stages for a single item. Stages execute sequentially.
    /// If a stage fails and <paramref name="continueOnStageFailure"/> is false, remaining stages are skipped.
    /// Returns a complete EvalResult regardless of success/failure.
    /// Never throws.
    /// </summary>
    public async Task<EvalResult> RunItemAsync(
        EvalStageContext context,
        bool continueOnStageFailure,
        string evalSetId)
    {
        var startedAt = DateTimeOffset.UtcNow;
        var sw = System.Diagnostics.Stopwatch.StartNew();

        var allOutputs = new Dictionary<string, object?>(context.StageOutputs);
        var allMetrics = new List<MetricValue>();
        bool overallSucceeded = true;
        string? failureReason = null;

        foreach (var stage in Stages)
        {
            var stageContext = context with { StageOutputs = allOutputs };
            StageResult result;

            try
            {
                result = await stage.ExecuteAsync(stageContext);
            }
            catch (Exception ex)
            {
                // Programming error — capture but don't rethrow
                result = StageResult.Failure($"[{stage.StageName}] Unhandled exception: {ex.Message}");
            }

            foreach (var (k, v) in result.Outputs)
                allOutputs[k] = v;

            allMetrics.AddRange(result.Metrics);

            if (!result.Succeeded)
            {
                overallSucceeded = false;
                failureReason = result.FailureReason;
                if (!continueOnStageFailure)
                    break;
            }
        }

        sw.Stop();

        string? rawLlmResponse = allOutputs.TryGetValue("PromptStage.response", out var rawObj)
            ? rawObj as string
            : null;

        return new EvalResult
        {
            EvalItemId = context.Item.Id,
            EvalSetId = evalSetId,
            Succeeded = overallSucceeded,
            FailureReason = failureReason,
            Metrics = allMetrics,
            AllStageOutputs = allOutputs,
            StartedAt = startedAt,
            DurationSeconds = sw.Elapsed.TotalSeconds,
            RawLlmResponse = rawLlmResponse
        };
    }
}
