using System.Diagnostics;
using System.Text;
using System.Text.RegularExpressions;
using Microsoft.Extensions.Logging;
using Seevalocal.Core.Abstractions;
using Seevalocal.Core.Models;

namespace Seevalocal.Pipelines.Stages;

/// <summary>
/// Runs an external process (e.g., <c>dotnet build</c>, <c>dotnet test</c>)
/// and extracts typed metrics from its stdout/stderr via configurable regex patterns.
/// </summary>
public sealed class ExternalProcessStage : IEvalStage
{
    public string StageName { get; }

    private readonly string _executable;
    private readonly string _arguments;
    private readonly string _workingDirectory;
    private readonly double _timeoutSeconds;
    private readonly IReadOnlyList<MetricExtractor> _extractors;
    private readonly ILogger<ExternalProcessStage> _logger;

    public ExternalProcessStage(
        string stageName,
        string executable,
        string arguments,
        string workingDirectory,
        double timeoutSeconds,
        IReadOnlyList<MetricExtractor> extractors,
        ILogger<ExternalProcessStage> logger)
    {
        StageName = stageName;
        _executable = executable;
        _arguments = arguments;
        _workingDirectory = workingDirectory;
        _timeoutSeconds = timeoutSeconds;
        _extractors = extractors;
        _logger = logger;
    }

    public async Task<StageResult> ExecuteAsync(EvalStageContext context)
    {
        var ct = context.CancellationToken;
        var sw = Stopwatch.StartNew();

        var stdoutSb = new StringBuilder();
        var stderrSb = new StringBuilder();

        using var cts = CancellationTokenSource.CreateLinkedTokenSource(ct);
        cts.CancelAfter(TimeSpan.FromSeconds(_timeoutSeconds));

        var psi = new ProcessStartInfo
        {
            FileName = _executable,
            Arguments = _arguments,
            WorkingDirectory = _workingDirectory,
            UseShellExecute = false,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            CreateNoWindow = true,
        };

        using var process = new Process { StartInfo = psi };
        process.OutputDataReceived += (_, e) => { if (e.Data != null) stdoutSb.AppendLine(e.Data); };
        process.ErrorDataReceived  += (_, e) => { if (e.Data != null) stderrSb.AppendLine(e.Data); };

        try
        {
            process.Start();
            process.BeginOutputReadLine();
            process.BeginErrorReadLine();
            await process.WaitForExitAsync(cts.Token);
        }
        catch (OperationCanceledException) when (!ct.IsCancellationRequested)
        {
            try { process.Kill(entireProcessTree: true); } catch { /* ignore */ }
            var reason = $"[{StageName}] Process '{_executable} {_arguments}' timed out after {_timeoutSeconds}s";
            _logger.LogError("Item {ItemId}: {Reason}", context.Item.Id, reason);
            return StageResult.Failure(reason);
        }

        sw.Stop();
        double durationSeconds = sw.Elapsed.TotalSeconds;

        var stdout = stdoutSb.ToString();
        var stderr = stderrSb.ToString();
        var combined = stdout + stderr;
        int exitCode = process.ExitCode;

        _logger.LogDebug(
            "Item {ItemId}: [{StageName}] exited {ExitCode} in {DurationSeconds:F2}s",
            context.Item.Id, StageName, exitCode, durationSeconds);

        var outputs = new Dictionary<string, object?>
        {
            [$"{StageName}.stdout"] = stdout,
            [$"{StageName}.stderr"] = stderr,
            [$"{StageName}.exitCode"] = exitCode,
        };

        var durationMetricName = StageName switch
        {
            "CompileStage" => "compileDurationSeconds",
            "TestStage"    => "testDurationSeconds",
            _              => $"{char.ToLowerInvariant(StageName[0])}{StageName[1..]}DurationSeconds",
        };

        var metrics = new List<MetricValue>
        {
            new() { Name = durationMetricName, Type = MetricType.Double, DoubleValue = durationSeconds },
        };

        // Apply extractors
        foreach (var extractor in _extractors)
        {
            var value = extractor.Extract(combined, exitCode);
            if (value is not null)
            {
                outputs[$"{StageName}.{extractor.MetricName}"] = value.RawValue;
                metrics.Add(value);
            }
        }

        return StageResult.Success(outputs, metrics);
    }
}

/// <summary>
/// Extracts a single metric from process output text or exit code.
/// </summary>
public abstract class MetricExtractor
{
    public abstract string MetricName { get; }
    public abstract MetricValue? Extract(string combinedOutput, int exitCode);
}

/// <summary>Extracts a boolean from whether a specific string is present (or from exit code 0).</summary>
public sealed class BoolMetricExtractor : MetricExtractor
{
    public override string MetricName { get; }
    private readonly string? _truePattern;
    private readonly bool _trueOnExitCodeZero;

    public BoolMetricExtractor(string metricName, string? truePattern = null, bool trueOnExitCodeZero = false)
    {
        MetricName = metricName;
        _truePattern = truePattern;
        _trueOnExitCodeZero = trueOnExitCodeZero;
    }

    public override MetricValue? Extract(string combinedOutput, int exitCode)
    {
        bool value = _trueOnExitCodeZero
            ? exitCode == 0
            : (_truePattern != null && combinedOutput.Contains(_truePattern, StringComparison.OrdinalIgnoreCase));

        return new MetricValue { Name = MetricName, Type = MetricType.Boolean, BoolValue = value };
    }
}

/// <summary>Extracts an integer from a regex capture group in process output.</summary>
public sealed class RegexIntMetricExtractor : MetricExtractor
{
    public override string MetricName { get; }
    private readonly Regex _regex;
    private readonly int _groupIndex;

    public RegexIntMetricExtractor(string metricName, string pattern, int groupIndex = 1)
    {
        MetricName = metricName;
        _regex = new Regex(pattern, RegexOptions.Compiled | RegexOptions.Multiline);
        _groupIndex = groupIndex;
    }

    public override MetricValue? Extract(string combinedOutput, int exitCode)
    {
        var match = _regex.Match(combinedOutput);
        if (!match.Success || !int.TryParse(match.Groups[_groupIndex].Value, out int value))
            return null;

        return new MetricValue { Name = MetricName, Type = MetricType.Integer, IntValue = value };
    }
}
