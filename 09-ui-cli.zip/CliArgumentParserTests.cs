using FluentAssertions;
using Seevalocal.Cli.Commands;
using Seevalocal.Config.Models;
using Xunit;

namespace Seevalocal.Cli.Tests;

/// <summary>
/// Tests that each CLI flag correctly sets the corresponding PartialConfig field,
/// and that unset flags produce null (not sentinel values).
/// </summary>
public sealed class CliArgumentParserTests
{
    // ─── Helpers ─────────────────────────────────────────────────────────────

    private static PartialConfig Adapt(Action<RunCommandSettings> configure)
    {
        var s = new RunCommandSettings();
        configure(s);
        return CliSettingsAdapter.ToPartialConfig(s);
    }

    // ─── Server flags ─────────────────────────────────────────────────────────

    [Fact]
    public void ExecutablePath_Sets_ServerConfig_ExecutablePath()
    {
        var config = Adapt(s => s.ExecutablePath = "/usr/bin/llama-server");
        config.Server!.ExecutablePath.Should().Be("/usr/bin/llama-server");
    }

    [Fact]
    public void ExecutablePath_Implies_Manage_True()
    {
        var config = Adapt(s => s.ExecutablePath = "/bin/llama-server");
        config.Server!.Manage.Should().BeTrue();
    }

    [Fact]
    public void ServerUrl_Implies_Manage_False()
    {
        var config = Adapt(s => s.ServerUrl = "http://localhost:8080");
        config.Server!.Manage.Should().BeFalse();
        config.Server.BaseUrl.Should().Be("http://localhost:8080");
    }

    [Fact]
    public void NoManage_Sets_Manage_False()
    {
        var config = Adapt(s => s.NoManage = true);
        config.Server!.Manage.Should().BeFalse();
    }

    [Fact]
    public void ModelFile_Creates_LocalFile_ModelSource()
    {
        var config = Adapt(s => s.ModelFilePath = "/models/ggml.gguf");
        config.Server!.Model!.Kind.Should().Be(ModelSourceKind.LocalFile);
        config.Server.Model.FilePath.Should().Be("/models/ggml.gguf");
    }

    [Fact]
    public void HfRepo_Without_Quant_Creates_HuggingFace_Source()
    {
        var config = Adapt(s => s.HfRepo = "TheBloke/Mistral-7B-GGUF");
        config.Server!.Model!.Kind.Should().Be(ModelSourceKind.HuggingFace);
        config.Server.Model.HfRepo.Should().Be("TheBloke/Mistral-7B-GGUF");
        config.Server.Model.HfQuant.Should().BeNull();
    }

    [Fact]
    public void HfRepo_With_Quant_Splits_Correctly()
    {
        var config = Adapt(s => s.HfRepo = "TheBloke/Mistral-7B-GGUF:Q4_K_M");
        config.Server!.Model!.HfRepo.Should().Be("TheBloke/Mistral-7B-GGUF");
        config.Server.Model.HfQuant.Should().Be("Q4_K_M");
    }

    [Fact]
    public void Port_Sets_ServerConfig_Port()
    {
        var config = Adapt(s => s.Port = 9090);
        config.Server!.Port.Should().Be(9090);
    }

    // ─── llama-server tuning flags ────────────────────────────────────────────

    [Fact]
    public void ContextWindow_Sets_LlamaSettings()
    {
        var config = Adapt(s => s.ContextWindowTokens = 4096);
        config.LlamaSettings!.ContextWindowTokens.Should().Be(4096);
    }

    [Fact]
    public void GpuLayers_Sets_LlamaSettings_GpuLayerCount()
    {
        var config = Adapt(s => s.GpuLayerCount = 35);
        config.LlamaSettings!.GpuLayerCount.Should().Be(35);
    }

    [Fact]
    public void FlashAttn_Sets_EnableFlashAttention_True()
    {
        var config = Adapt(s => s.EnableFlashAttention = true);
        config.LlamaSettings!.EnableFlashAttention.Should().BeTrue();
    }

    [Fact]
    public void NoFlashAttn_Sets_EnableFlashAttention_False()
    {
        var config = Adapt(s => s.EnableFlashAttention = false);
        config.LlamaSettings!.EnableFlashAttention.Should().BeFalse();
    }

    [Fact]
    public void Temperature_Sets_SamplingTemperature()
    {
        var config = Adapt(s => s.SamplingTemperature = 0.7);
        config.LlamaSettings!.SamplingTemperature.Should().BeApproximately(0.7, 1e-9);
    }

    // ─── Null fields stay null ────────────────────────────────────────────────

    [Fact]
    public void Unset_LlamaSettings_Flags_Produce_Null_Config()
    {
        var config = Adapt(s => s.ContextWindowTokens = null);

        // If no llama settings at all, the whole LlamaSettings object should be null
        var empty = Adapt(_ => { });
        empty.LlamaSettings.Should().BeNull();
    }

    [Fact]
    public void Unset_Server_Flags_Produce_Null_ServerConfig()
    {
        var config = Adapt(_ => { });
        config.Server.Should().BeNull();
    }

    // ─── Eval options ─────────────────────────────────────────────────────────

    [Fact]
    public void PipelineName_Sets_EvalSet_PipelineName()
    {
        var config = Adapt(s =>
        {
            s.PipelineName = "Translation";
            s.DataFilePath = "/data/prompts.json";
        });
        config.EvalSets![0].PipelineName.Should().Be("Translation");
    }

    [Fact]
    public void DataFilePath_Creates_File_DataSource()
    {
        var config = Adapt(s => s.DataFilePath = "/data/evals.json");
        config.EvalSets![0].DataSource.Kind.Should().Be(DataSourceKind.File);
        config.EvalSets[0].DataSource.FilePath.Should().Be("/data/evals.json");
    }

    [Fact]
    public void PromptDir_Creates_DirectoryPair_DataSource()
    {
        var config = Adapt(s =>
        {
            s.PromptDir = "/prompts";
            s.ExpectedDir = "/expected";
        });
        config.EvalSets![0].DataSource.Kind.Should().Be(DataSourceKind.DirectoryPair);
        config.EvalSets[0].DataSource.PromptDirectory.Should().Be("/prompts");
        config.EvalSets[0].DataSource.ExpectedDirectory.Should().Be("/expected");
    }

    // ─── Judge flags ──────────────────────────────────────────────────────────

    [Fact]
    public void JudgeUrl_Creates_JudgeConfig()
    {
        var config = Adapt(s =>
        {
            s.JudgeUrl = "http://localhost:8081";
            s.DataFilePath = "/data.json";   // need eval settings to get judge attached
        });
        config.EvalSets![0].Judge!.JudgeUrl.Should().Be("http://localhost:8081");
    }

    [Fact]
    public void JudgeScoreMin_Max_Set_Correctly()
    {
        var config = Adapt(s =>
        {
            s.JudgeUrl = "http://localhost:8081";
            s.JudgeScoreMin = 1;
            s.JudgeScoreMax = 5;
            s.DataFilePath = "/d.json";
        });
        config.EvalSets![0].Judge!.ScoreMin.Should().Be(1);
        config.EvalSets[0].Judge.ScoreMax.Should().Be(5);
    }

    // ─── Output flags ─────────────────────────────────────────────────────────

    [Fact]
    public void OutputDir_Sets_OutputConfig()
    {
        var config = Adapt(s => s.OutputDir = "/results");
        config.Output!.OutputDir.Should().Be("/results");
    }

    [Fact]
    public void ShellDialect_Bash_Maps_To_Bash_Target()
    {
        var config = Adapt(s => { s.ShellDialect = "bash"; s.OutputDir = "/r"; });
        config.Output!.ShellTarget.Should().Be(ShellTarget.Bash);
    }

    [Fact]
    public void ShellDialect_PowerShell_Maps_To_PowerShell_Target()
    {
        var config = Adapt(s => { s.ShellDialect = "powershell"; s.OutputDir = "/r"; });
        config.Output!.ShellTarget.Should().Be(ShellTarget.PowerShell);
    }

    [Fact]
    public void NoParquet_Sets_WriteResultsParquet_False()
    {
        var config = Adapt(s => { s.NoParquet = true; s.OutputDir = "/r"; });
        config.Output!.WriteResultsParquet.Should().BeFalse();
    }

    [Fact]
    public void NoRawResponse_Sets_IncludeRawLlmResponse_False()
    {
        var config = Adapt(s => { s.NoRawResponse = true; s.OutputDir = "/r"; });
        config.Output!.IncludeRawLlmResponse.Should().BeFalse();
    }

    // ─── Settings layering via multiple --settings files ──────────────────────

    [Fact]
    public void Multiple_Settings_Files_Are_Captured_In_Array()
    {
        var settings = new RunCommandSettings
        {
            SettingsFiles = ["a.yml", "b.yml", "c.yml"]
        };
        settings.SettingsFiles.Should().HaveCount(3);
        settings.SettingsFiles[2].Should().Be("c.yml");
    }

    // ─── Run control flags ────────────────────────────────────────────────────

    [Fact]
    public void StopOnFailure_Sets_ContinueOnEvalFailure_False()
    {
        var config = Adapt(s => s.StopOnFailure = true);
        config.Run!.ContinueOnEvalFailure.Should().BeFalse();
    }

    [Fact]
    public void TimeoutSeconds_Sets_RunMeta()
    {
        var config = Adapt(s => s.TimeoutSeconds = 30.0);
        config.Run!.TimeoutSeconds.Should().BeApproximately(30.0, 1e-9);
    }

    [Fact]
    public void RetryCount_Sets_RunMeta()
    {
        var config = Adapt(s => s.RetryCount = 5);
        config.Run!.RetryCount.Should().Be(5);
    }
}
