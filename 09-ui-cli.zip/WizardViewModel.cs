using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using Seevalocal.Config.Models;

namespace Seevalocal.Ui.ViewModels;

// ─── Settings stack ──────────────────────────────────────────────────────────

/// <summary>
/// Represents a single loaded settings file in the layered stack.
/// </summary>
public sealed class SettingsLayerViewModel : INotifyPropertyChanged
{
    private bool _isEnabled = true;

    public string FilePath { get; }
    public string DisplayName => Path.GetFileName(FilePath);
    public int LayerIndex { get; }

    public bool IsEnabled
    {
        get => _isEnabled;
        set => SetField(ref _isEnabled, value);
    }

    public PartialConfig Config { get; }

    public SettingsLayerViewModel(string filePath, int layerIndex, PartialConfig config)
    {
        FilePath = filePath;
        LayerIndex = layerIndex;
        Config = config;
    }

    public event PropertyChangedEventHandler? PropertyChanged;
    private void OnPropertyChanged([CallerMemberName] string? n = null) =>
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(n));
    private bool SetField<T>(ref T f, T v, [CallerMemberName] string? n = null)
    {
        if (EqualityComparer<T>.Default.Equals(f, v)) return false;
        f = v; OnPropertyChanged(n); return true;
    }
}

// ─── Wizard steps ────────────────────────────────────────────────────────────

public enum WizardStepKind
{
    ModelAndServer,
    PerformanceSettings,
    EvaluationDataset,
    Scoring,
    Output,
    ReviewAndRun
}

/// <summary>
/// View model for the guided setup wizard.
/// </summary>
public sealed class WizardViewModel : INotifyPropertyChanged
{
    private WizardStepKind _currentStep = WizardStepKind.ModelAndServer;
    private bool _manageServer = true;
    private bool _useLocalFile = true;
    private string? _localModelPath;
    private string? _hfRepo;
    private string? _hfToken;
    private string? _serverUrl;
    private int? _contextWindowTokens;
    private int? _parallelSlotCount;
    private int? _gpuLayerCount;
    private string _pipelineName = "CasualQA";
    private string? _dataFilePath;
    private string? _promptDir;
    private string? _expectedDir;
    private bool _enableJudge;
    private string? _judgeUrl;
    private string _judgeTemplate = "standard";
    private double _judgeScoreMin = 0;
    private double _judgeScoreMax = 10;
    private string _outputDir = "./results";
    private string? _runName;
    private ShellTarget _shellTarget = ShellTarget.Bash;

    // ─── Step navigation ──────────────────────────────────────────────────────

    public WizardStepKind CurrentStep
    {
        get => _currentStep;
        set => SetField(ref _currentStep, value);
    }

    public bool CanGoBack => CurrentStep != WizardStepKind.ModelAndServer;

    public bool CanGoForward => CurrentStep != WizardStepKind.ReviewAndRun
                                && ValidateCurrentStep().Count == 0;

    public void GoBack()
    {
        if (!CanGoBack) return;
        CurrentStep = (WizardStepKind)((int)CurrentStep - 1);
        OnPropertyChanged(nameof(CanGoBack));
        OnPropertyChanged(nameof(CanGoForward));
    }

    public void GoForward()
    {
        if (!CanGoForward) return;
        CurrentStep = (WizardStepKind)((int)CurrentStep + 1);
        OnPropertyChanged(nameof(CanGoBack));
        OnPropertyChanged(nameof(CanGoForward));
    }

    public IReadOnlyList<string> ValidateCurrentStep() => CurrentStep switch
    {
        WizardStepKind.ModelAndServer => ValidateServerStep(),
        _ => Array.Empty<string>()
    };

    private IReadOnlyList<string> ValidateServerStep()
    {
        var errors = new List<string>();
        if (_manageServer)
        {
            if (_useLocalFile && string.IsNullOrWhiteSpace(_localModelPath))
                errors.Add("Model file path is required when using a local file.");
            if (!_useLocalFile && string.IsNullOrWhiteSpace(_hfRepo))
                errors.Add("HuggingFace repo is required.");
        }
        else
        {
            if (string.IsNullOrWhiteSpace(_serverUrl))
                errors.Add("Server URL is required when connecting to an existing server.");
        }
        return errors;
    }

    // ─── Step 1: Model & Server ───────────────────────────────────────────────

    public bool ManageServer { get => _manageServer; set => SetField(ref _manageServer, value); }
    public bool UseLocalFile { get => _useLocalFile; set => SetField(ref _useLocalFile, value); }
    public string? LocalModelPath { get => _localModelPath; set => SetField(ref _localModelPath, value); }
    public string? HfRepo { get => _hfRepo; set => SetField(ref _hfRepo, value); }
    public string? HfToken { get => _hfToken; set => SetField(ref _hfToken, value); }
    public string? ServerUrl { get => _serverUrl; set => SetField(ref _serverUrl, value); }

    // ─── Step 2: Performance ─────────────────────────────────────────────────

    public int? ContextWindowTokens { get => _contextWindowTokens; set => SetField(ref _contextWindowTokens, value); }
    public int? ParallelSlotCount { get => _parallelSlotCount; set => SetField(ref _parallelSlotCount, value); }
    public int? GpuLayerCount { get => _gpuLayerCount; set => SetField(ref _gpuLayerCount, value); }

    // ─── Step 3: Dataset ──────────────────────────────────────────────────────

    public string PipelineName { get => _pipelineName; set => SetField(ref _pipelineName, value); }
    public string? DataFilePath { get => _dataFilePath; set => SetField(ref _dataFilePath, value); }
    public string? PromptDir { get => _promptDir; set => SetField(ref _promptDir, value); }
    public string? ExpectedDir { get => _expectedDir; set => SetField(ref _expectedDir, value); }

    // ─── Step 4: Scoring ─────────────────────────────────────────────────────

    public bool EnableJudge { get => _enableJudge; set => SetField(ref _enableJudge, value); }
    public string? JudgeUrl { get => _judgeUrl; set => SetField(ref _judgeUrl, value); }
    public string JudgeTemplate { get => _judgeTemplate; set => SetField(ref _judgeTemplate, value); }
    public double JudgeScoreMin { get => _judgeScoreMin; set => SetField(ref _judgeScoreMin, value); }
    public double JudgeScoreMax { get => _judgeScoreMax; set => SetField(ref _judgeScoreMax, value); }

    // ─── Step 5: Output ───────────────────────────────────────────────────────

    public string OutputDir { get => _outputDir; set => SetField(ref _outputDir, value); }
    public string? RunName { get => _runName; set => SetField(ref _runName, value); }
    public ShellTarget ShellTarget { get => _shellTarget; set => SetField(ref _shellTarget, value); }

    // ─── Build config from wizard state ──────────────────────────────────────

    public PartialConfig BuildPartialConfig()
    {
        ModelSource? model = ManageServer
            ? UseLocalFile && LocalModelPath != null
                ? new ModelSource { Kind = ModelSourceKind.LocalFile, FilePath = LocalModelPath }
                : HfRepo != null
                    ? new ModelSource { Kind = ModelSourceKind.HuggingFace, HfRepo = HfRepo, HfToken = HfToken }
                    : null
            : null;

        var server = new ServerConfig
        {
            Manage = ManageServer,
            Model = model,
            BaseUrl = ManageServer ? null : ServerUrl
        };

        LlamaServerSettings? llamaSettings = (ContextWindowTokens != null || ParallelSlotCount != null || GpuLayerCount != null)
            ? new LlamaServerSettings
            {
                ContextWindowTokens = ContextWindowTokens,
                ParallelSlotCount = ParallelSlotCount,
                GpuLayerCount = GpuLayerCount
            }
            : null;

        JudgeConfig? judge = EnableJudge
            ? new JudgeConfig
            {
                JudgeUrl = JudgeUrl,
                TemplateName = JudgeTemplate,
                ScoreMin = JudgeScoreMin,
                ScoreMax = JudgeScoreMax
            }
            : null;

        DataSourceConfig dataSource = DataFilePath != null
            ? new DataSourceConfig { Kind = DataSourceKind.File, FilePath = DataFilePath }
            : new DataSourceConfig { Kind = DataSourceKind.DirectoryPair, PromptDirectory = PromptDir, ExpectedDirectory = ExpectedDir };

        var evalSet = new EvalSetConfig
        {
            PipelineName = PipelineName,
            DataSource = dataSource,
            Judge = judge
        };

        var output = new OutputConfig
        {
            OutputDir = OutputDir,
            RunName = RunName,
            ShellTarget = ShellTarget
        };

        return new PartialConfig
        {
            Server = server,
            LlamaSettings = llamaSettings,
            EvalSets = [evalSet],
            Output = output
        };
    }

    // ─── INotifyPropertyChanged ───────────────────────────────────────────────

    public event PropertyChangedEventHandler? PropertyChanged;
    private void OnPropertyChanged([CallerMemberName] string? n = null) =>
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(n));
    private bool SetField<T>(ref T f, T v, [CallerMemberName] string? n = null)
    {
        if (EqualityComparer<T>.Default.Equals(f, v)) return false;
        f = v; OnPropertyChanged(n); return true;
    }
}
