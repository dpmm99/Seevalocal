using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using Microsoft.Extensions.Logging;
using Seevalocal.Config.Models;
using Seevalocal.Core.Abstractions;
using Seevalocal.Metrics.Models;
using Seevalocal.Pipelines;

namespace Seevalocal.Ui.ViewModels;

/// <summary>
/// Shared view-model for an eval run. Both the CLI renderer and the Avalonia UI bind to this.
/// All property changes fire <see cref="PropertyChanged"/> for MVVM data-binding.
/// </summary>
public sealed class EvalRunViewModel : INotifyPropertyChanged, IDisposable
{
    private readonly PipelineOrchestrator _orchestrator;
    private readonly ILogger _logger;
    private CancellationTokenSource? _cts;

    // ─── Observable properties ────────────────────────────────────────────────

    public ResolvedConfig Config { get; }

    private bool _isRunning;
    public bool IsRunning
    {
        get => _isRunning;
        private set => SetField(ref _isRunning, value);
    }

    private bool _isPaused;
    public bool IsPaused
    {
        get => _isPaused;
        private set => SetField(ref _isPaused, value);
    }

    private double _progressPercent;
    public double ProgressPercent
    {
        get => _progressPercent;
        private set => SetField(ref _progressPercent, value);
    }

    private int _completedCount;
    public int CompletedCount
    {
        get => _completedCount;
        private set => SetField(ref _completedCount, value);
    }

    private int _totalCount;
    public int TotalCount
    {
        get => _totalCount;
        private set => SetField(ref _totalCount, value);
    }

    private double _averageTokensPerSecond;
    public double AverageTokensPerSecond
    {
        get => _averageTokensPerSecond;
        private set => SetField(ref _averageTokensPerSecond, value);
    }

    private double? _estimatedRemainingSeconds;
    public double? EstimatedRemainingSeconds
    {
        get => _estimatedRemainingSeconds;
        private set => SetField(ref _estimatedRemainingSeconds, value);
    }

    private string _statusLine = "Ready";
    public string StatusLine
    {
        get => _statusLine;
        private set => SetField(ref _statusLine, value);
    }

    private RunSummary? _summary;
    public RunSummary? Summary
    {
        get => _summary;
        private set => SetField(ref _summary, value);
    }

    private bool _hadFailures;
    public bool HadFailures
    {
        get => _hadFailures;
        private set => SetField(ref _hadFailures, value);
    }

    public ObservableCollection<EvalResultViewModel> Results { get; } = [];

    // ─── Constructor ─────────────────────────────────────────────────────────

    public EvalRunViewModel(
        ResolvedConfig config,
        PipelineOrchestrator orchestrator,
        ILogger logger)
    {
        Config = config;
        _orchestrator = orchestrator;
        _logger = logger;
    }

    // ─── Commands ─────────────────────────────────────────────────────────────

    public async Task StartAsync(CancellationToken externalCt = default)
    {
        if (IsRunning)
            throw new InvalidOperationException("A run is already in progress.");

        _cts = CancellationTokenSource.CreateLinkedTokenSource(externalCt);
        IsRunning = true;
        IsPaused = false;
        StatusLine = "Starting...";
        Results.Clear();
        CompletedCount = 0;

        try
        {
            _logger.LogInformation("EvalRunViewModel: Starting run '{RunName}'",
                Config.Output?.RunName ?? "(unnamed)");

            await _orchestrator.RunAsync(
                Config,
                OnProgress,
                OnResult,
                _cts.Token);

            Summary = await _orchestrator.GetSummaryAsync(_cts.Token);
            HadFailures = Results.Any(r => !r.Succeeded);
            StatusLine = "Complete";
        }
        catch (OperationCanceledException)
        {
            StatusLine = "Cancelled";
            _logger.LogInformation("Run was cancelled");
        }
        catch (Exception ex)
        {
            StatusLine = $"Error: {ex.Message}";
            _logger.LogError(ex, "Run failed with unhandled exception");
        }
        finally
        {
            IsRunning = false;
            IsPaused = false;
        }
    }

    public void Cancel()
    {
        _cts?.Cancel();
        StatusLine = "Cancelling...";
    }

    public void Pause()
    {
        _orchestrator.Pause();
        IsPaused = true;
        StatusLine = "Paused (in-flight items finishing)";
    }

    public void Resume()
    {
        _orchestrator.Resume();
        IsPaused = false;
        StatusLine = "Running...";
    }

    // ─── Callbacks ────────────────────────────────────────────────────────────

    private void OnProgress(EvalProgress progress)
    {
        CompletedCount = progress.CompletedCount;
        TotalCount = progress.TotalCount;
        ProgressPercent = progress.TotalCount > 0
            ? (double)progress.CompletedCount / progress.TotalCount * 100.0
            : 0;
        AverageTokensPerSecond = progress.AverageCompletionTokensPerSecond ?? 0;
        EstimatedRemainingSeconds = progress.EstimatedRemainingSeconds;

        var eta = progress.EstimatedRemainingSeconds is double remaining
            ? $" ETA: {TimeSpan.FromSeconds(remaining):hh\\:mm\\:ss}"
            : "";
        StatusLine = $"{progress.CompletedCount}/{(progress.TotalCount < 0 ? "?" : progress.TotalCount.ToString())} " +
                     $"{AverageTokensPerSecond:F1} tok/s{eta}";
    }

    private void OnResult(EvalResult result)
    {
        var vm = new EvalResultViewModel(result);
        // Marshal to UI thread if needed — Avalonia Dispatcher.UIThread.Post
        Results.Add(vm);
    }

    // ─── INotifyPropertyChanged ───────────────────────────────────────────────

    public event PropertyChangedEventHandler? PropertyChanged;

    private void OnPropertyChanged([CallerMemberName] string? name = null) =>
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));

    private bool SetField<T>(ref T field, T value, [CallerMemberName] string? name = null)
    {
        if (EqualityComparer<T>.Default.Equals(field, value)) return false;
        field = value;
        OnPropertyChanged(name);
        return true;
    }

    // ─── IDisposable ──────────────────────────────────────────────────────────

    public void Dispose()
    {
        _cts?.Cancel();
        _cts?.Dispose();
    }
}

/// <summary>
/// A flat view of a single <see cref="EvalResult"/> for list display.
/// </summary>
public sealed class EvalResultViewModel
{
    private readonly EvalResult _result;

    public EvalResultViewModel(EvalResult result) => _result = result;

    public string Id => _result.EvalItemId;
    public string EvalSetId => _result.EvalSetId;
    public bool Succeeded => _result.Succeeded;
    public string Status => _result.Succeeded ? "Pass" : "Fail";
    public string? FailureReason => _result.FailureReason;
    public double DurationSeconds => _result.DurationSeconds;
    public DateTimeOffset StartedAt => _result.StartedAt;
    public string? RawResponse => _result.RawLlmResponse;

    public string? UserPrompt =>
        _result.AllStageOutputs.TryGetValue("PromptStage.userPrompt", out var val)
            ? val?.ToString()
            : null;

    public string? ExpectedOutput =>
        _result.AllStageOutputs.TryGetValue("PromptStage.expectedOutput", out var val)
            ? val?.ToString()
            : null;

    public string? JudgeRationale =>
        _result.AllStageOutputs.TryGetValue("JudgeStage.rationale", out var val)
            ? val?.ToString()
            : null;

    public double? JudgeScore =>
        _result.Metrics.FirstOrDefault(m => m.Name.Contains("Score"))?.AsDouble();

    public IEnumerable<(string Name, string Value)> MetricDisplay =>
        _result.Metrics.Select(m => (m.Name, m.AsDouble()?.ToString("G4") ?? m.Value?.ToString() ?? ""));
}
