using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Seevalocal.Cli.Commands;
using Serilog;
using Spectre.Console.Cli;

// Configure Serilog
Log.Logger = new LoggerConfiguration()
    .MinimumLevel.Information()
    .WriteTo.Console(outputTemplate: "[{Level:u3}] {Message:lj}{NewLine}{Exception}")
    .WriteTo.File(Path.Combine("logs", "seevalocal-.log"),
        rollingInterval: RollingInterval.Day,
        outputTemplate: "{Timestamp:yyyy-MM-dd HH:mm:ss.fff} [{Level:u3}] {Message:lj}{NewLine}{Exception}")
    .CreateLogger();

try
{
    var services = new ServiceCollection();
    services.AddLogging(b => b.AddSerilog(dispose: true));

    // Register CLI services (real implementations wire to the component projects)
    services.AddSingleton<IConfigurationService, DefaultConfigurationService>();
    services.AddSingleton<IRunnerService, DefaultRunnerService>();
    services.AddSingleton<IServerLifecycleService, DefaultServerLifecycleService>();
    services.AddSingleton<IShellScriptExporter, DefaultShellScriptExporter>();

    // Register pipeline factories
    services.AddSingleton<Seevalocal.Pipelines.IBuiltinPipelineFactory, Seevalocal.Pipelines.TranslationPipelineFactory>();
    services.AddSingleton<Seevalocal.Pipelines.IBuiltinPipelineFactory, Seevalocal.Pipelines.CSharpCodingPipelineFactory>();
    services.AddSingleton<Seevalocal.Pipelines.IBuiltinPipelineFactory, Seevalocal.Pipelines.CasualQAPipelineFactory>();

    // Register commands
    services.AddTransient<RunCommand>();
    services.AddTransient<ValidateCommand>();
    services.AddTransient<ExportScriptCommand>();
    services.AddTransient<ServerStartCommand>();
    services.AddTransient<ServerCheckCommand>();
    services.AddTransient<PipelineListCommand>();

    var registrar = new TypeRegistrar(services);
    var app = new CommandApp(registrar);

    app.Configure(config =>
    {
        config.SetApplicationName("seevalocal");
        config.SetApplicationVersion(typeof(Program).Assembly.GetName().Version?.ToString() ?? "0.0.0");

        config.AddCommand<RunCommand>("run")
            .WithDescription("Run an evaluation pipeline");

        config.AddCommand<ValidateCommand>("validate")
            .WithDescription("Validate a settings file without running");

        config.AddCommand<ExportScriptCommand>("export-script")
            .WithDescription("Export a shell script from a settings file");

        config.AddBranch("server", server =>
        {
            server.SetDescription("Server lifecycle commands");
            server.AddCommand<ServerStartCommand>("start")
                .WithDescription("Start llama-server (for debugging)");
            server.AddCommand<ServerCheckCommand>("check")
                .WithDescription("Check if a URL is a healthy llama-server");
        });

        config.AddBranch("pipeline", pipeline =>
        {
            pipeline.SetDescription("Pipeline management commands");
            pipeline.AddCommand<PipelineListCommand>("list")
                .WithDescription("List registered pipeline names and descriptions");
        });
    });

    return await app.RunAsync(args);
}
catch (Exception ex)
{
    Log.Fatal(ex, "Unhandled exception at startup");
    return 1;
}
finally
{
    await Log.CloseAndFlushAsync();
}
