using Seevalocal.Config.Models;
using Seevalocal.Server.Models;

namespace Seevalocal.Cli.Commands;

/// <summary>
/// Converts parsed CLI flags into a <see cref="PartialConfig"/> that can be layered
/// over file-based configs using ConfigurationMerger.
/// </summary>
public static class CliSettingsAdapter
{
    public static PartialConfig ToPartialConfig(RunCommandSettings s)
    {
        // Determine Manage tri-state
        bool? manage = s.NoManage ? false : s.Manage;
        // Imply manage=true when executable or model are specified
        if (s.ExecutablePath != null || s.ModelFilePath != null || s.HfRepo != null)
            manage ??= true;
        // Imply manage=false when server-url is specified
        if (s.ServerUrl != null)
            manage ??= false;

        ModelSource? model = null;
        if (s.ModelFilePath != null)
        {
            model = new ModelSource
            {
                Kind = ModelSourceKind.LocalFile,
                FilePath = s.ModelFilePath
            };
        }
        else if (s.HfRepo != null)
        {
            var parts = s.HfRepo.Split(':', 2);
            model = new ModelSource
            {
                Kind = ModelSourceKind.HuggingFace,
                HfRepo = parts[0],
                HfQuant = parts.Length > 1 ? parts[1] : null,
                HfToken = s.HfToken
            };
        }

        var serverConfig = (manage != null || s.Host != null || s.Port != null || model != null
                            || s.ServerUrl != null || s.ApiKey != null)
            ? new ServerConfig
            {
                Manage = manage ?? false,
                ExecutablePath = s.ExecutablePath,
                Model = model,
                Host = s.Host ?? "127.0.0.1",
                Port = s.Port ?? 8080,
                ApiKey = s.ApiKey,
                BaseUrl = s.ServerUrl,
                ExtraArgs = s.ExtraArgs?.ToList().AsReadOnly() ?? (IReadOnlyList<string>)[]
            }
            : null;

        LlamaServerSettings? llamaSettings = HasAnyLlamaSettings(s)
            ? new LlamaServerSettings
            {
                ContextWindowTokens = s.ContextWindowTokens,
                BatchTokens = s.BatchTokens,
                UBatchTokens = s.UBatchTokens,
                ParallelSlotCount = s.ParallelSlotCount,
                GpuLayerCount = s.GpuLayerCount,
                EnableFlashAttention = s.EnableFlashAttention,
                EnableCachePrompt = s.EnableCachePrompt,
                EnableContextShift = s.EnableContextShift,
                KvTypeK = s.KvTypeK,
                KvTypeV = s.KvTypeV,
                ThreadCount = s.ThreadCount,
                SamplingTemperature = s.SamplingTemperature,
                TopP = s.TopP,
                TopK = s.TopK,
                MinP = s.MinP,
                Seed = s.Seed,
                ChatTemplate = s.ChatTemplate,
                ReasoningFormat = s.ReasoningFormat,
                LogVerbosity = s.LogVerbosity
            }
            : null;

        JudgeConfig? judgeConfig = (s.JudgeUrl != null || s.JudgeModelFilePath != null || s.JudgeHfRepo != null)
            ? new JudgeConfig
            {
                JudgeUrl = s.JudgeUrl,
                JudgeApiKey = s.JudgeApiKey,
                TemplateName = s.JudgeTemplate,
                ScoreMin = s.JudgeScoreMin ?? 0,
                ScoreMax = s.JudgeScoreMax ?? 10,
                ModelFilePath = s.JudgeModelFilePath,
                HfRepo = s.JudgeHfRepo
            }
            : null;

        RunMeta? runMeta = (s.MaxConcurrent != null || s.TimeoutSeconds != null
                            || s.RetryCount != null || s.StopOnFailure || s.ContinueOnFailure)
            ? new RunMeta
            {
                MaxConcurrentEvals = s.MaxConcurrent,
                TimeoutSeconds = s.TimeoutSeconds,
                RetryCount = s.RetryCount,
                ContinueOnEvalFailure = !s.StopOnFailure
            }
            : null;

        OutputConfig? outputConfig = (s.OutputDir != null || s.RunName != null
                                      || s.NoParquet || s.NoRawResponse || s.ShellDialect != null)
            ? new OutputConfig
            {
                OutputDir = s.OutputDir,
                RunName = s.RunName,
                ShellTarget = ParseShellTarget(s.ShellDialect),
                WriteResultsParquet = !s.NoParquet,
                IncludeRawLlmResponse = !s.NoRawResponse
            }
            : null;

        // Build a single EvalSetConfig if any eval options are present
        EvalSetConfig? evalSet = HasAnyEvalSettings(s)
            ? new EvalSetConfig
            {
                PipelineName = s.PipelineName ?? "CasualQA",
                DataSource = BuildDataSourceConfig(s),
                SystemPrompt = s.SystemPrompt,
                SystemPromptFilePath = s.SystemPromptFilePath,
                MaxItems = s.MaxItems,
                ShuffleSeed = s.ShuffleSeed,
                Judge = judgeConfig
            }
            : null;

        return new PartialConfig
        {
            Server = serverConfig,
            LlamaSettings = llamaSettings,
            EvalSets = evalSet != null ? [evalSet] : null,
            Run = runMeta,
            Output = outputConfig
        };
    }

    private static bool HasAnyLlamaSettings(RunCommandSettings s) =>
        s.ContextWindowTokens != null || s.BatchTokens != null || s.UBatchTokens != null
        || s.ParallelSlotCount != null || s.GpuLayerCount != null || s.EnableFlashAttention != null
        || s.EnableCachePrompt != null || s.EnableContextShift != null || s.KvTypeK != null
        || s.KvTypeV != null || s.ThreadCount != null || s.SamplingTemperature != null
        || s.TopP != null || s.TopK != null || s.MinP != null || s.Seed != null
        || s.ChatTemplate != null || s.ReasoningFormat != null || s.LogVerbosity != null;

    private static bool HasAnyEvalSettings(RunCommandSettings s) =>
        s.PipelineName != null || s.PromptDir != null || s.ExpectedDir != null
        || s.DataFilePath != null || s.SystemPrompt != null || s.SystemPromptFilePath != null
        || s.MaxItems != null || s.ShuffleSeed != null;

    private static DataSourceConfig BuildDataSourceConfig(RunCommandSettings s)
    {
        if (s.DataFilePath != null)
            return new DataSourceConfig { Kind = DataSourceKind.File, FilePath = s.DataFilePath };
        if (s.PromptDir != null)
            return new DataSourceConfig
            {
                Kind = DataSourceKind.DirectoryPair,
                PromptDirectory = s.PromptDir,
                ExpectedDirectory = s.ExpectedDir
            };
        return new DataSourceConfig { Kind = DataSourceKind.File };
    }

    private static ShellTarget? ParseShellTarget(string? dialect) => dialect?.ToLowerInvariant() switch
    {
        "bash" => ShellTarget.Bash,
        "powershell" or "ps" or "ps1" => ShellTarget.PowerShell,
        _ => null
    };
}
