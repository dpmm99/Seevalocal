using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using Microsoft.Extensions.Logging;
using Seevalocal.Cli.Commands;
using Seevalocal.Config.Models;

namespace Seevalocal.Ui.ViewModels;

public enum AppView { Wizard, RunDashboard, Results, Settings }

/// <summary>
/// Top-level ViewModel for the Avalonia MainWindow.
/// Manages navigation, active run, and settings stack.
/// </summary>
public sealed class MainWindowViewModel : INotifyPropertyChanged, IDisposable
{
    private readonly IConfigurationService _configService;
    private readonly IRunnerService _runnerService;
    private readonly IShellScriptExporter _scriptExporter;
    private readonly ILogger<MainWindowViewModel> _logger;

    private AppView _currentView = AppView.Wizard;
    private string _titleBarText = "Seevalocal";
    private bool _isModified;
    private EvalRunViewModel? _activeRun;

    // ─── Navigation ───────────────────────────────────────────────────────────

    public AppView CurrentView
    {
        get => _currentView;
        set => SetField(ref _currentView, value);
    }

    public string TitleBarText
    {
        get => _titleBarText;
        private set => SetField(ref _titleBarText, value);
    }

    public bool IsModified
    {
        get => _isModified;
        private set
        {
            SetField(ref _isModified, value);
            UpdateTitle();
        }
    }

    // ─── Settings stack ───────────────────────────────────────────────────────

    public ObservableCollection<SettingsLayerViewModel> SettingsLayers { get; } = [];

    /// <summary>Session overrides (CLI-style values entered in the UI).</summary>
    public WizardViewModel WizardState { get; } = new();

    // ─── Active run ───────────────────────────────────────────────────────────

    public EvalRunViewModel? ActiveRun
    {
        get => _activeRun;
        private set => SetField(ref _activeRun, value);
    }

    // ─── Constructor ─────────────────────────────────────────────────────────

    public MainWindowViewModel(
        IConfigurationService configService,
        IRunnerService runnerService,
        IShellScriptExporter scriptExporter,
        ILogger<MainWindowViewModel> logger)
    {
        _configService = configService;
        _runnerService = runnerService;
        _scriptExporter = scriptExporter;
        _logger = logger;

        WizardState.PropertyChanged += (_, _) => IsModified = true;

        _ = LoadDefaultSettingsAsync();
    }

    // ─── Settings file management ─────────────────────────────────────────────

    public async Task AddSettingsFileAsync(string filePath)
    {
        var result = await _configService.LoadPartialConfigAsync(filePath, default);
        if (result.IsFailed)
        {
            _logger.LogError("Failed to load settings file {Path}: {Error}",
                filePath, result.Errors[0].Message);
            return;
        }

        SettingsLayers.Add(new SettingsLayerViewModel(filePath, SettingsLayers.Count, result.Value));
        IsModified = true;
        _logger.LogInformation("Loaded settings file {Path}", filePath);
    }

    public void RemoveSettingsLayer(SettingsLayerViewModel layer)
    {
        SettingsLayers.Remove(layer);
        IsModified = true;
    }

    /// <summary>Resolves the current settings stack + wizard state into a <see cref="ResolvedConfig"/>.</summary>
    public Result<ResolvedConfig> ResolveCurrentConfig()
    {
        var partials = SettingsLayers
            .Where(l => l.IsEnabled)
            .OrderBy(l => l.LayerIndex)
            .Select(l => l.Config)
            .ToList();

        partials.Add(WizardState.BuildPartialConfig());
        return _configService.Resolve(partials);
    }

    public async Task SaveCurrentConfigAsync(string path)
    {
        var resolveResult = ResolveCurrentConfig();
        if (resolveResult.IsFailed) return;

        // Delegate to Config project serializer
        await File.WriteAllTextAsync(path, SerializeToYaml(WizardState.BuildPartialConfig()));
        IsModified = false;
        UpdateTitle();
    }

    // ─── Run management ───────────────────────────────────────────────────────

    public async Task StartRunAsync()
    {
        var resolveResult = ResolveCurrentConfig();
        if (resolveResult.IsFailed)
        {
            _logger.LogError("Cannot start run: config resolution failed");
            return;
        }

        var config = resolveResult.Value;
        var errors = _configService.Validate(config);
        if (errors.Count > 0)
        {
            _logger.LogWarning("Validation errors: {Count}", errors.Count);
            return;
        }

        ActiveRun = _runnerService.CreateViewModel(config);
        CurrentView = AppView.RunDashboard;

        await ActiveRun.StartAsync();

        CurrentView = AppView.Results;
    }

    // ─── Script export ────────────────────────────────────────────────────────

    public string ExportScript(ShellTarget target)
    {
        var result = ResolveCurrentConfig();
        if (result.IsFailed) return $"# Error: {result.Errors[0].Message}";
        return _scriptExporter.Export(result.Value, target);
    }

    // ─── Private helpers ──────────────────────────────────────────────────────

    private async Task LoadDefaultSettingsAsync()
    {
        var candidates = new[]
        {
            Path.Combine(AppContext.BaseDirectory, "Seevalocal.yml"),
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),
                ".Seevalocal", "default.yml")
        };

        foreach (var candidate in candidates)
        {
            if (File.Exists(candidate))
            {
                await AddSettingsFileAsync(candidate);
                _logger.LogInformation("Auto-loaded settings from {Path}", candidate);
            }
        }
    }

    private void UpdateTitle()
    {
        var runName = WizardState.RunName ?? "(unnamed)";
        TitleBarText = IsModified ? $"Seevalocal — {runName} •" : $"Seevalocal — {runName}";
    }

    private static string SerializeToYaml(PartialConfig config)
    {
        // Delegates to Seevalocal.Config serializer; stub returns placeholder
        return "# Seevalocal settings\n# (serialization implemented in Seevalocal.Config)\n";
    }

    // ─── INotifyPropertyChanged ───────────────────────────────────────────────

    public event PropertyChangedEventHandler? PropertyChanged;
    private void OnPropertyChanged([CallerMemberName] string? n = null) =>
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(n));
    private bool SetField<T>(ref T f, T v, [CallerMemberName] string? n = null)
    {
        if (EqualityComparer<T>.Default.Equals(f, v)) return false;
        f = v; OnPropertyChanged(n); return true;
    }

    public void Dispose() => ActiveRun?.Dispose();
}
