using FluentResults;
using Microsoft.Extensions.Logging;
using Seevalocal.Config.Models;
using Seevalocal.Core.Abstractions;
using Seevalocal.Core.Models;
using Seevalocal.Server.Client;
using Seevalocal.Server.Models;

namespace Seevalocal.Judge;

/// <summary>
/// Pipeline stage that sends the item's prompt, expected output, and primary LLM response
/// to a judge LLM for scoring. Produces <c>judgeScoreRatio</c> and <c>judgePassedBool</c>
/// metrics.
///
/// Thread-safe; a single instance is shared across all concurrently running eval items.
/// </summary>
public sealed class JudgeStage : IEvalStage
{
    public string StageName => "JudgeStage";

    private readonly JudgeConfig _config;
    private readonly JudgePromptRenderer _renderer;
    private readonly JudgeResponseParser _parser;
    private readonly ILogger<JudgeStage> _logger;

    public JudgeStage(
        JudgeConfig config,
        JudgePromptRenderer renderer,
        JudgeResponseParser parser,
        ILogger<JudgeStage> logger)
    {
        _config   = config   ?? throw new ArgumentNullException(nameof(config));
        _renderer = renderer ?? throw new ArgumentNullException(nameof(renderer));
        _parser   = parser   ?? throw new ArgumentNullException(nameof(parser));
        _logger   = logger   ?? throw new ArgumentNullException(nameof(logger));
    }

    /// <summary>
    /// Convenience constructor that creates internal collaborators from DI-injected loggers.
    /// </summary>
    public JudgeStage(
        JudgeConfig config,
        ILogger<JudgeStage> logger,
        ILogger<JudgePromptRenderer> rendererLogger,
        ILogger<JudgeResponseParser> parserLogger)
        : this(config,
               new JudgePromptRenderer(rendererLogger),
               new JudgeResponseParser(parserLogger),
               logger)
    { }

    /// <inheritdoc />
    public async Task<StageResult> ExecuteAsync(EvalStageContext context)
    {
        ArgumentNullException.ThrowIfNull(context);

        // ── 1. Resolve the judge client ────────────────────────────────────
        var judgeClient = context.JudgeClient
            ?? throw new InvalidOperationException(
                $"[{StageName}] JudgeStage requires a judge client but EvalStageContext.JudgeClient is null. " +
                "Ensure the pipeline orchestrator initialises a judge endpoint.");

        // ── 2. Retrieve the primary LLM's actual output ────────────────────
        var actualOutput = context.StageOutputs.GetValueOrDefault("PromptStage.response") as string ?? string.Empty;

        if (string.IsNullOrEmpty(actualOutput))
        {
            _logger.LogWarning(
                "[{Stage}] EvalItem {ItemId}: 'PromptStage.response' is missing or empty. " +
                "The judge will evaluate an empty actual output.",
                StageName, context.Item.Id);
        }

        // ── 3. Render judge prompt ─────────────────────────────────────────
        var judgePrompt = _renderer.Render(
            _config.JudgePromptTemplate,
            context.Item.UserPrompt,
            context.Item.ExpectedOutput ?? string.Empty,
            actualOutput,
            context.Item.Metadata);

        _logger.LogDebug(
            "[{Stage}] EvalItem {ItemId}: sending request to judge endpoint",
            StageName, context.Item.Id);

        // ── 4. Call the judge endpoint ─────────────────────────────────────
        var request = new ChatCompletionRequest
        {
            Model       = string.Empty, // use whatever model the judge server has loaded
            Messages    =
            [
                new ChatMessage { Role = "system", Content = _config.JudgeSystemPrompt ?? string.Empty },
                new ChatMessage { Role = "user",   Content = judgePrompt },
            ],
            MaxTokens   = _config.JudgeMaxTokenCount,
            Temperature = _config.JudgeSamplingTemperature,
        };

        Result<ChatCompletionResponse> response;
        try
        {
            response = await judgeClient.ChatCompletionAsync(request, context.CancellationToken)
                .ConfigureAwait(false);
        }
        catch (OperationCanceledException)
        {
            _logger.LogWarning(
                "[{Stage}] EvalItem {ItemId}: judge request cancelled",
                StageName, context.Item.Id);
            return StageResult.Failure($"[{StageName}] Request to judge endpoint was cancelled.");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex,
                "[{Stage}] EvalItem {ItemId}: unexpected exception calling judge endpoint",
                StageName, context.Item.Id);
            return StageResult.Failure($"[{StageName}] Unexpected error: {ex.Message}");
        }

        if (response.IsFailed)
        {
            var firstError = response.Errors.FirstOrDefault()?.Message ?? "unknown error";
            _logger.LogError(
                "[{Stage}] EvalItem {ItemId}: judge endpoint returned failure: {Error}",
                StageName, context.Item.Id, firstError);
            return StageResult.Failure($"[{StageName}] Judge endpoint error: {firstError}");
        }

        // ── 5. Parse the judge's response ─────────────────────────────────
        var judgeText = response.Value.Choices.Count > 0
            ? response.Value.Choices[0].Message.Content
            : string.Empty;

        _logger.LogTrace(
            "[{Stage}] EvalItem {ItemId}: raw judge response: {JudgeText}",
            StageName, context.Item.Id, judgeText);

        var parsed = _parser.Parse(judgeText, _config);

        if (!parsed.ParseSucceeded)
        {
            _logger.LogWarning(
                "[{Stage}] EvalItem {ItemId}: failed to parse judge response: {JudgeText}",
                StageName, context.Item.Id, judgeText);
            return new StageResult
            {
                Succeeded     = false,
                FailureReason = $"[{StageName}] Could not parse judge response: \"{judgeText}\"",
                Outputs = BuildOutputs(judgeText, parsed),
                Metrics = BuildMetrics(parsed),
            };
        }

        _logger.LogDebug(
            "[{Stage}] EvalItem {ItemId}: judgeScoreRatio={Score:F4} passed={Passed}",
            StageName, context.Item.Id, parsed.NormalizedScore, parsed.Passed);

        return new StageResult
        {
            Succeeded = true,
            Outputs   = BuildOutputs(judgeText, parsed),
            Metrics   = BuildMetrics(parsed),
        };
    }

    // ──────────────────────────────────────────────────────────────────────
    // Helpers
    // ──────────────────────────────────────────────────────────────────────

    private static IReadOnlyDictionary<string, object?> BuildOutputs(
        string judgeText,
        ParsedJudgeResponse parsed) =>
        new Dictionary<string, object?>
        {
            ["JudgeStage.rawResponse"] = judgeText,
            ["JudgeStage.score"]       = parsed.NormalizedScore,
            ["JudgeStage.passed"]      = parsed.Passed,
            ["JudgeStage.rationale"]   = parsed.Rationale,
        };

    private static IReadOnlyList<MetricValue> BuildMetrics(ParsedJudgeResponse parsed) =>
    [
        new MetricValue
        {
            Name        = "judgeScoreRatio",
            Value       = new MetricScalar.DoubleMetric(parsed.NormalizedScore ?? 0.0),
            SourceStage = "JudgeStage",
        },
        new MetricValue
        {
            Name        = "judgePassedBool",
            Value       = new MetricScalar.BoolMetric(parsed.Passed ?? false),
            SourceStage = "JudgeStage",
        },
    ];
}
