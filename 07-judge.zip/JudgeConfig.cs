// NOTE: Per 10-interfaces.md, JudgeConfig lives in namespace Seevalocal.Config.Models and
// is owned by Seevalocal.Config. This file is a PLACEHOLDER that will be moved to
// Seevalocal.Config when that project is implemented. It is included here so
// Seevalocal.Judge compiles as a standalone unit.
//
// When Seevalocal.Config is implemented, delete this file and add a project reference instead.

using Seevalocal.Judge;

// Use the Server.Models namespace for ServerConfig / LlamaServerSettings as stubs.
namespace Seevalocal.Config.Models;

public record JudgeConfig
{
    /// <summary>
    /// Connection to the judge LLM endpoint.
    /// May be a second local llama-server, a remote OpenAI-compatible endpoint, etc.
    /// If Manage = true, a second llama-server process is started.
    /// </summary>
    public ServerConfigStub ServerConfig { get; init; } = new();

    /// <summary>LlamaServerSettings for the judge endpoint (if managed).</summary>
    public LlamaServerSettingsStub? ServerSettings { get; init; }

    /// <summary>
    /// Jinja2-style template for the judge prompt.
    /// Available variables: {prompt}, {expectedOutput}, {actualOutput}, {metadata.*}
    /// </summary>
    public string JudgePromptTemplate { get; init; } = DefaultTemplates.Standard;

    /// <summary>How to parse the judge's response.</summary>
    public JudgeResponseFormat ResponseFormat { get; init; } = JudgeResponseFormat.StructuredJson;

    /// <summary>
    /// For NumericScore/StructuredJson format: the score range expected from the judge.
    /// The score is normalized to [0, 1] for the judgeScoreRatio metric.
    /// </summary>
    public double ScoreMinValue { get; init; } = 0.0;
    public double ScoreMaxValue { get; init; } = 10.0;

    /// <summary>System prompt for the judge LLM.</summary>
    public string? JudgeSystemPrompt { get; init; }

    /// <summary>Max tokens the judge is allowed to generate.</summary>
    public int JudgeMaxTokenCount { get; init; } = 512;

    /// <summary>Temperature for judge responses. Lower = more deterministic scoring.</summary>
    public double JudgeSamplingTemperature { get; init; } = 0.0;
}

// ──────────────────────────────────────────────────────────────────────────────
// Stubs — replaced by proper types when Seevalocal.Server / Seevalocal.Config
//          projects are wired into the solution.
// ──────────────────────────────────────────────────────────────────────────────

/// <summary>Stub for <c>Seevalocal.Server.Models.ServerConfig</c>.</summary>
public record ServerConfigStub
{
    public bool   Manage          { get; init; }
    public string Host            { get; init; } = "127.0.0.1";
    public int    Port            { get; init; } = 8080;
    public string? ApiKey         { get; init; }
    public string? BaseUrl        { get; init; }
}

/// <summary>Stub for <c>Seevalocal.Config.Models.LlamaServerSettings</c>.</summary>
public record LlamaServerSettingsStub;
