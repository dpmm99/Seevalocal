namespace Seevalocal.Judge;

/// <summary>
/// Built-in Jinja2-style judge prompt templates.
/// Variables: {prompt}, {expectedOutput}, {actualOutput}, {metadata.KEY}
/// </summary>
public static class DefaultTemplates
{
    /// <summary>
    /// Asks the judge to score the actual output on a 0–10 scale.
    /// Uses StructuredJson response format for robustness.
    /// </summary>
    public const string Standard = """
        You are an expert evaluator. You will be given a task prompt, an expected output, and an actual output produced by an AI model.

        Task Prompt:
        {prompt}

        Expected Output:
        {expectedOutput}

        Actual Output:
        {actualOutput}

        Evaluate the quality of the Actual Output. Consider:
        - Accuracy: Does it match the expected output in meaning and content?
        - Completeness: Does it address the full scope of the prompt?
        - Quality: Is it well-formed, clear, and free of errors?

        Scoring rubric:
        0  — Completely wrong, off-topic, or harmful
        1–3 — Major errors or omissions; only superficially relevant
        4–6 — Partially correct; captures some intent but with significant gaps
        7–9 — Mostly correct; minor issues only
        10 — Perfect match in meaning, completeness, and quality

        Respond ONLY with a JSON object in this exact format (rationale MUST come first):
        {"rationale": "<one sentence explaining your score>", "score": <0-10>, "passed": <true if score >= 7, else false>}
        """;

    /// <summary>
    /// Asks the judge to give a binary PASS/FAIL verdict.
    /// Uses StructuredJson response format for robustness.
    /// </summary>
    public const string PassFail = """
        You are an expert evaluator. Determine whether the Actual Output correctly answers the Task Prompt, using the Expected Output as a reference.

        Task Prompt:
        {prompt}

        Expected Output:
        {expectedOutput}

        Actual Output:
        {actualOutput}

        Criteria for PASS:
        - The actual output conveys the same essential information or meaning as the expected output.
        - Minor wording differences are acceptable; factual errors or omissions are not.

        Respond ONLY with a JSON object in this exact format (rationale MUST come first):
        {"rationale": "<one sentence explaining your verdict>", "score": <10 if passed else 0>, "passed": <true|false>}
        """;

    /// <summary>
    /// Asks the judge to respond with a fully structured JSON object.
    /// Preferred format when the pipeline needs score, rationale, and pass/fail together.
    /// </summary>
    public const string StructuredJson = """
        You are an expert evaluator. Evaluate the Actual Output and respond with a JSON object.

        Task Prompt:
        {prompt}

        Expected Output:
        {expectedOutput}

        Actual Output:
        {actualOutput}

        Scoring rubric (0–10):
        0  — Completely wrong or irrelevant
        5  — Partially correct
        10 — Perfect match in meaning and quality

        Respond ONLY with a JSON object in this exact format (no markdown, no extra text, rationale MUST come first):
        {"rationale": "<one sentence>", "score": <0-10>, "passed": <true|false>}
        """;
}
